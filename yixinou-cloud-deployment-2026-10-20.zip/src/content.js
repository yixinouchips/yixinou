// YIXINOU site content

import frPack from './locales/fr.js';
import esPack from './locales/es.js';
import dePack from './locales/de.js';
import deParts from './locales/parts/de/index.js';
import dePartsTdk from './locales/parts/de/tdk.js';
import frParts from './locales/parts/fr/index.js';
import frPartsTdk from './locales/parts/fr/tdk.js';
import arPack from './locales/ar.js';
import ruPack from './locales/ru.js';
import jaPack from './locales/ja.js';
import koPack from './locales/ko.js';
import zhPack from './locales/zh.js';
import bgPack from './locales/bg.js';
import hrPack from './locales/hr.js';
import csPack from './locales/cs.js';
import daPack from './locales/da.js';
import nlPack from './locales/nl.js';
import industryBg from './locales/industry/bg.js';
import industryHr from './locales/industry/hr.js';
import industryCs from './locales/industry/cs.js';
import industryDa from './locales/industry/da.js';
import industryNl from './locales/industry/nl.js';
import newLocaleTdk from './locales/parts/new-locale-tdk.js';
import bgParts from './locales/parts/bg/index.js';
import hrParts from './locales/parts/hr/index.js';
import csParts from './locales/parts/cs/index.js';
import daParts from './locales/parts/da/index.js';
import nlParts from './locales/parts/nl/index.js';
import arParts from './locales/parts/ar/index.js';
import arPartsTdk from './locales/parts/ar/tdk.js';
import ruParts from './locales/parts/ru/index.js';
import ruPartsTdk from './locales/parts/ru/tdk.js';
import jaParts from './locales/parts/ja/index.js';
import jaPartsTdk from './locales/parts/ja/tdk.js';
import koParts from './locales/parts/ko/index.js';
import koPartsTdk from './locales/parts/ko/tdk.js';
import zhParts from './locales/parts/zh/index.js';
import zhPartsTdk from './locales/parts/zh/tdk.js';
import { GROUPS as DEFAULT_INDUSTRY_GROUPS, INSPECT as DEFAULT_INDUSTRY_INSPECT, INDUSTRY_DETAILS as DEFAULT_INDUSTRY_DETAILS } from './industryDetails.js';
import industryDe from './locales/industry/de.js';
import industryFr from './locales/industry/fr.js';
import industryEs from './locales/industry/es.js';
import industryAr from './locales/industry/ar.js';
import industryRu from './locales/industry/ru.js';
import industryJa from './locales/industry/ja.js';
import industryKo from './locales/industry/ko.js';
import industryZh from './locales/industry/zh.js';

const frCopy = frPack.copy;
const esCopy = esPack.copy;
const arCopy = arPack.copy;
const ruCopy = ruPack.copy;
const jaCopy = jaPack.copy;
const koCopy = koPack.copy;
const zhCopy = zhPack.copy;

export const LOCALE_INDUSTRIES = {
  de: industryDe,
  fr: industryFr,
  es: industryEs,
  ar: industryAr,
  ru: industryRu,
  ja: industryJa,
  ko: industryKo,
  zh: industryZh,
  bg: industryBg,
  hr: industryHr,
  cs: industryCs,
  da: industryDa,
  nl: industryNl,
};

/*
 * Per-locale page TDK, merged over the published config by ConfigProvider.
 *
 * It ships in the bundle because public/site-config.json is only refreshed by the admin
 * workbench's "publish to site" action — a site publish does not touch it, so metadata kept
 * only there can sit stale on the CDN long after the code that renders it has been replaced.
 * Keys are locale-relative: '/' means the locale's home page.
 */
export const LOCALE_TDK = {
  de: { ...dePack.tdk, ...dePartsTdk },
  fr: { ...frPack.tdk, ...frPartsTdk },
  es: esPack.tdk,
  ar: { ...arPack.tdk, ...arPartsTdk },
  ru: { ...ruPack.tdk, ...ruPartsTdk },
  ja: { ...jaPack.tdk, ...jaPartsTdk },
  ko: { ...koPack.tdk, ...koPartsTdk },
  zh: { ...zhPack.tdk, ...zhPartsTdk },
  bg: { ...bgPack.tdk, ...newLocaleTdk.bg },
  hr: { ...hrPack.tdk, ...newLocaleTdk.hr },
  cs: { ...csPack.tdk, ...newLocaleTdk.cs },
  da: { ...daPack.tdk, ...newLocaleTdk.da },
  nl: { ...nlPack.tdk, ...newLocaleTdk.nl },
};

/*
 * Localized part records, overlaid on the English ones by ConfigProvider.
 *
 * Only the strings that differ from English live here; the overlay is applied field by field so
 * a locale that has not translated a part yet keeps serving the English record rather than
 * rendering blanks. Every record was checked for structural parity and for spec-number
 * integrity before being wired in, because a translated specification that drifts is worse
 * than one left in English.
 */
export const LOCALE_PARTS = {
  de: deParts,
  fr: frParts,
  ar: arParts,
  ru: ruParts,
  ja: jaParts,
  ko: koParts,
  zh: zhParts,
  bg: bgParts,
  hr: hrParts,
  cs: csParts,
  da: daParts,
  nl: nlParts,
};// ---------------- Industries ----------------
// The twelve industries YIXINOU supplies, matching the applications the company
// already states its components are used in. Certifications held by the
// reference site (AS9120B, AS6081, ISO/IEC 17025, ISO 14001, ISO 9001) are NOT
// reproduced here because YIXINOU's own certification status is not confirmed.
export const INDUSTRY_LIST = [
  {
    slug: 'aerospace',
    icon: 'rocket',
    title: 'Aerospace',
    href: '/industries/aerospace',
    href: '/industries/aerospace',
    desc: 'Components for avionics, flight control and ground support equipment, including discontinued and hard-to-find references.',
    items: [
      'Avionics, flight-control and instrument boards',
      'Discontinued, last-time-buy and obsolete references',
      'Connectors, relays, oscillators and passive components',
    ],
  },
  {
    slug: 'automotive',
    icon: 'car',
    title: 'Automotive',
    href: '/industries/automotive',
    href: '/industries/automotive',
    desc: 'Components for ADAS, infotainment, lighting, body control and electric-vehicle power systems.',
    items: [
      'ADAS, sensor and camera components',
      'Infotainment, display and audio parts',
      'Lighting, body control and power-management parts',
    ],
  },
  {
    slug: 'consumer-electronics',
    icon: 'monitor',
    title: 'Consumer Electronics',
    href: '/industries/consumer-electronics',
    desc: 'Components for phones, wearables, audio, smart home and small appliances, where cost and lead time decide the order.',
    items: [
      'Display, touch and camera components',
      'Power management and charging ICs',
      'Wireless, audio and passive components',
    ],
  },
  {
    slug: 'contract-manufacturing',
    icon: 'factory',
    title: 'Contract Manufacturing',
    href: '/industries/contract-manufacturing',
    desc: 'Line-down and volume support for EMS and contract manufacturers, quoted against your bill of materials.',
    items: [
      'BOM quotation and one-stop orders',
      'Line-down and shortage sourcing',
      'Second-source verification and inventory balancing',
    ],
  },
  {
    slug: 'energy',
    icon: 'zap',
    title: 'Energy',
    href: '/industries/energy',
    desc: 'Components for solar, storage, grid and power-conversion equipment.',
    items: [
      'Inverters and power-conversion parts',
      'Gate drivers, IGBTs and power modules',
      'Control, monitoring and magnetic components',
    ],
  },
  {
    slug: 'enterprise-computing',
    icon: 'server',
    title: 'Enterprise Computing & Servers',
    href: '/industries/enterprise-computing',
    desc: 'Components for servers, storage systems, networking appliances and data-centre hardware.',
    items: [
      'Server, storage and interface controllers',
      'Power supplies and voltage regulators',
      'Cooling, connectors and cabling',
    ],
  },
  {
    slug: 'gaming',
    icon: 'gamepad',
    title: 'Gaming',
    href: '/industries/gaming',
    desc: 'Components for gaming hardware, amusement, lottery and point-of-sale machines.',
    items: [
      'Display and controller parts',
      'Power, interface and lighting components',
      'Long-life replacements for legacy machines',
    ],
  },
  {
    slug: 'healthcare',
    icon: 'heart-pulse',
    title: 'Healthcare',
    href: '/industries/healthcare',
    desc: 'Components for patient monitoring, diagnostic imaging and laboratory equipment, where traceability matters.',
    items: [
      'Monitoring and diagnostic boards',
      'Sensors and signal-conditioning parts',
      'Power, isolation and discontinued references',
    ],
  },
  {
    slug: 'industrial-automation',
    icon: 'cog',
    title: 'Industrial Automation',
    href: '/industries/industrial-automation',
    desc: 'Components for robotics, drives, PLCs, sensors and power electronics on the factory floor.',
    items: [
      'PLC, drive and motion-control parts',
      'Sensors and interface ICs',
      'Power electronics, relays and terminals',
    ],
  },
  {
    slug: 'personal-computing',
    icon: 'keyboard',
    title: 'Personal Computing',
    href: '/industries/personal-computing',
    desc: 'Components for laptops, desktops, peripherals and their accessory supply chain.',
    items: [
      'Power management and charging ICs',
      'Interface, USB and display controllers',
      'Legacy references for repair and service',
    ],
  },
  {
    slug: 'semiconductor-manufacturing',
    icon: 'cpu',
    title: 'Semiconductor Manufacturing',
    href: '/industries/semiconductor-manufacturing',
    desc: 'Support components and spares for fabrication, test and packaging operations.',
    items: [
      'Test and handler interface parts',
      'Power supplies and control electronics',
      'Sensors, motion components and legacy spares',
    ],
  },
  {
    slug: 'telecom-networking',
    icon: 'network',
    title: 'Telecom & Networking',
    href: '/industries/telecom-networking',
    desc: 'Components for base stations, routers, switches, optical transport and access equipment.',
    items: [
      'RF, optical and interface components',
      'Power and circuit-protection parts',
      'Filters, connectors and line-card support',
    ],
  },
];

export const INDUSTRIES_PAGE = {
  eyebrow: 'Industries',
  title: 'Industries We Serve',
  lead:
    'We supply electronic components to manufacturers, contract manufacturers and traders across twelve industries. Every order is checked before it ships, and any part that needs internal analysis goes to our partner laboratories.',
  menuDesc:
    'We provide services and build partnerships with a multitude of companies across a broad array of industries.',
  ctaLabel: 'View all industries',
  ctaHref: '/industries',
  items: INDUSTRY_LIST,
};

export const NAV = [
  { label: 'Home', href: '/', active: true },
  { label: 'About us ', href: '/about-us' },
  {
    label: 'All products',
    href: '/all-products',
    children: [
      { label: 'Integrated Circuits（ICS）', href: '/all-products?category=Integrated Circuits (ICS)' },
      { label: 'Transistors', href: '/all-products?category=Transistors' },
      { label: 'Connector', href: '/all-products?category=Connector' },
      { label: 'Others', href: '/all-products?category=Others' },
      { label: 'Module', href: '/all-products?category=Module' },
      { label: 'Capacitors', href: '/all-products?category=Capacitors' },
      { label: 'Resistor', href: '/all-products?category=Resistor' },
      { label: 'Sensor', href: '/all-products?category=Sensor' },
      { label: 'Switch', href: '/all-products?category=Switch' },
      { label: 'LED', href: '/all-products?category=LED' },
    ],
  },
  { label: 'Industries', href: '/industries', mega: true, children: INDUSTRY_LIST },
  { label: 'Quality', href: '/quality' },
  {
    label: 'Blogs',
    href: '/blogs800',
    children: [
      // Both point at the blog index: /industry-information and /company-news were
      // never routes, so they fell through to the catch-all and behaved as 404s.
      // Split them out again once there are real per-category blog pages.
      { label: 'Industry Information', href: '/blogs800' },
      { label: 'Company News', href: '/blogs800' },
    ],
  },
  { label: 'Contact us ', href: '/Contact' },
];

export const BANNERS = [
  {
    img: '/assets/images/banner-r1-deepnavy.jpg',
    alt: 'YIXINOU electronic components and PCBA solutions banner',
    title: '',
    accent: '',
    text: '',
    cta: '',
    href: '/Contact',
  },
  {
    img: '/assets/images/banner-r2-deepnavy.jpg',
    alt: 'Reliable electronic components and PCBA solutions - from component sourcing to SMT assembly',
    title: '',
    text: '',
    cta: '',
    href: '/Contact',
  },
  {
    img: '/assets/images/banner-r3-deepnavy.jpg',
    alt: '100% new and original factory sealed electronic components guarantee',
    title: '',
    text: '',
    cta: '',
    href: '/Contact',
  },
];

export const ADVANTAGES = [
  { img: '/assets/images/adv-powerful.png', alt: 'Powerful Production', title: 'Powerful Production' },
  { img: '/assets/images/adv-premium.png', alt: 'Premium Supply', title: 'Premium Supply' },
  { img: '/assets/images/adv-price.png', alt: 'Competitive Prices', title: 'Competitive Prices' },
  { img: '/assets/images/adv-tailored.png', alt: 'Tailored Solutions', title: 'Tailored Solutions' },
  { img: '/assets/images/adv-customized.png', alt: 'Customized Services', title: 'Customized Services' },
  { img: '/assets/images/adv-expert.png', alt: 'Expert Support', title: 'Expert Support' },
  { img: '/assets/images/adv-experience.png', alt: 'Rich Industry Experience', title: 'Rich Industry Experience' },
  { img: '/assets/images/adv-quality.png', alt: 'High Quality And Strict Quality Control System', title: 'High Quality And Strict Quality Control System' },
];

export const CATEGORIES = [
  { img: '/assets/images/cat-ics.jpg', label: 'Integrated Circuits（ICS）', href: '/all-products?category=Integrated Circuits (ICS)' },
  { img: '/assets/images/cat-transistors.jpg', label: 'Transistors', href: '/all-products?category=Transistors' },
  { img: '/assets/images/cat-connector.jpg', label: 'Connector', href: '/all-products?category=Connector' },
  { img: '/assets/images/cat-others.jpg', label: 'Others', href: '/all-products?category=Others' },
];

// Curated home-page slots. Each entry is the id of a published part record; the
// component reads the part number, image and link from that record, so a featured
// slot cannot point at a page that does not exist.
export const HOT_PRODUCTS = [
  'STM32F103RCT6',
  'ESP8266EX',
  'XC6SLX9-3TQG144I',
  'TMS320F28335PGFA',
  'K4A8G085WB-BCTD',
  'MT41K256M16TW-107',
  'ATMEGA128A-AU',
  'AD780BRZ-REEL7',
];

export const FACTORY = [
  { img: '/assets/images/factory-office.jpg', alt: 'Office' },
  { img: '/assets/images/factory-warehouse.jpg', alt: 'Warehouse' },
  { img: '/assets/images/factory-smt.jpg', alt: 'SMT warehouse' },
  { img: '/assets/images/factory-storage.jpg', alt: 'Component storage' },
];

export const TEAM = [
  { img: '/assets/images/team-linda.jpg', name: 'Linda' },
  { img: '/assets/images/team-lucy.jpg', name: 'Lucy' },
  { img: '/assets/images/team-jessie.jpg', name: 'Jessie' },
  { img: '/assets/images/team-joon.jpg', name: 'Joon' },
  { img: '/assets/images/team-lisa.jpg', name: 'Lisa' },
];

export const NEWS = [
  {
    img: '/assets/images/news-ic-testing.jpg',
    title: 'Definition and fundamentals of IC testing',
    href: '/definition-and-fundamentals-of-ic-testing',
    snippet:
      'Integrated Circuit Testing refers to the process of testing the performance, functionality and reliability of integrated circuits.The purpose of IC testing is to ensure that integrated circuits can meet the design requirements and performance targets in practical applications, and to improve the reliability and stability of integrated circuits.',
    date: 'Aug, 05, 2024',
  },
  {
    img: '/assets/images/news-pcb.jpg',
    title: 'A few knowledges about PCB',
    href: '/a-few-knowledges-about-pcb',
    snippet:
      'As the mother of electronic components, PCB plays an important role in electronic applications. According to different design principles, PCB can be divided into single panel, multi-layer board, soft board, hard board, soft and hard combined board and other types.',
    date: 'Jul, 30, 2024',
  },
  {
    img: '/assets/images/news-munich.jpg',
    title: 'Visit the Munich Shanghai Electronics Fair',
    href: '/visit-the-munich-shanghai-electronics-fair',
    snippet:
      'The electronics industry in the first half of this year is not very good, but the Munich Shanghai Electronics Show on July 8 is extremely hot, including more than 1670 exhibitors, more than 75,400 professional visitors to the scene. A number of companies focused on new energy vehicles, photovoltaic, energy storage, robotics, third-generation semiconductors and other cutting-edge hot areas.',
    date: 'Jul, 25, 2024',
  },
  {
    img: '/assets/images/news-meal.jpg',
    title: 'Company summer collective meals in Shenzhen China 2024',
    href: '/company-summer-collective-meals-in-shenzhen-china-2024',
    snippet:
      'We organised a summer group dinner at the five-star hotel Grand Cloud Sky in Shenzhen. In 24th July, not only all the staffs of the company attended the activity, but also invited our domestic famous brand agent friends. We gathered together to enjoy a delicious dinner, but also reach an agreement in the supplying and selling of electronic components.',
    date: 'Jul, 15, 2024',
  },
];

export const PARTNERS = [
  { img: '/assets/images/partner-walsin.webp', name: 'Walsin' },
  { img: '/assets/images/partner-vishay.png', name: 'Vishay' },
  { img: '/assets/images/partner-toshiba.png', name: 'Toshiba' },
  { img: '/assets/images/partner-te.webp', name: 'TE Connectivity' },
  { img: '/assets/images/partner-st.png', name: 'STMicroelectronics' },
  { img: '/assets/images/partner-sanrex.webp', name: 'SanRex' },
  { img: '/assets/images/partner-rohm.png', name: 'Rohm' },
  { img: '/assets/images/partner-panasonic.webp', name: 'PANASONIC' },
  { img: '/assets/images/partner-onsemi.png', name: 'onsemi' },
  { img: '/assets/images/partner-nxp.png', name: 'NXP' },
  { img: '/assets/images/partner-molex.png', name: 'Molex' },
  { img: '/assets/images/partner-microchip.png', name: 'Microchip' },
  { img: '/assets/images/partner-kemet.jpeg', name: 'KEMET' },
  { img: '/assets/images/partner-ixys.jpg', name: 'IXYS' },
  { img: '/assets/images/partner-infineon.png', name: 'Infineon' },
  { img: '/assets/images/partner-epson.png', name: 'Epson' },
  { img: '/assets/images/partner-diodes.png', name: 'Diodes' },
  { img: '/assets/images/partner-broadcom.png', name: 'Broadcom' },
  { img: '/assets/images/partner-adi.png', name: 'Analog Devices' },
  { img: '/assets/images/partner-3m.png', name: '3M' },
];

export const RELATED_KEYWORDS = [
  { label: 'Capacitors', href: '/sadipic/capacitors' },
  { label: 'Ic Chips', href: '/sadipic/ic-chips' },
  { label: 'Integrated Circuits', href: '/sadipic/integrated-circuits' },
  { label: 'Resistor', href: '/sadipic/resistor' },
  { label: 'Transistors', href: '/sadipic/transistors' },
];

// language selector: [code, label, sprite object-position] ('' = no flag)
/*
 * Locale table: the single source of truth for the language selector and, once the
 * translated pages exist, for the /<code>/ routes and the hreflang alternates.
 *
 *   code     path prefix, and the key looked up in the UI dictionary
 *   label    shown in the selector, in the language itself
 *   flag     offset into the flag sprite; empty means no artwork, so the selector
 *            falls back to a letter chip instead of showing the wrong flag
 *   hreflang value for <link rel="alternate" hreflang>; not always the same as
 *            the code (zh-Hant, nb)
 *   live     true only where translated content actually exists. A locale that is
 *            not live is listed but not selectable, because pointing it at a route
 *            that does not exist sends the visitor to the English home page
 */
export const LOCALES = [
  { code: 'en', label: 'EN', flag: '-384px -38px', hreflang: 'en', live: true, dir: 'ltr' },
  { code: 'zh', label: '繁體中文', flag: '', hreflang: 'zh-Hant', live: true, dir: 'ltr' },
  { code: 'ar', label: 'العربية', flag: '-90px -6px', hreflang: 'ar', live: true, dir: 'rtl' },
  { code: 'bg', label: 'Български', flag: '-216px -6px', hreflang: 'bg', live: true, dir: 'ltr' },
  { code: 'hr', label: 'Hrvatski', flag: '-300px -102px', hreflang: 'hr', live: true, dir: 'ltr' },
  { code: 'cs', label: 'Čeština', flag: '-90px -38px', hreflang: 'cs', live: true, dir: 'ltr' },
  { code: 'da', label: 'Dansk', flag: '-174px -38px', hreflang: 'da', live: true, dir: 'ltr' },
  { code: 'nl', label: 'Nederlands', flag: '-342px -198px', hreflang: 'nl', live: true, dir: 'ltr' },
  { code: 'fi', label: 'Suomi', flag: '-258px -70px', hreflang: 'fi', live: false, dir: 'ltr' },
  { code: 'fr', label: 'Français', flag: '-300px -70px', hreflang: 'fr', live: true, dir: 'ltr' },
  { code: 'de', label: 'Deutsch', flag: '-216px -38px', hreflang: 'de', live: true, dir: 'ltr' },
  { code: 'el', label: 'Ελληνικά', flag: '-300px -38px', hreflang: 'el', live: false, dir: 'ltr' },
  { code: 'he', label: 'עברית', flag: '', hreflang: 'he', live: false, dir: 'rtl' },
  { code: 'hi', label: 'हिन्दी', flag: '-216px -102px', hreflang: 'hi', live: false, dir: 'ltr' },
  { code: 'it', label: 'Italiano', flag: '-132px -134px', hreflang: 'it', live: false, dir: 'ltr' },
  { code: 'ja', label: '日本語', flag: '-216px -134px', hreflang: 'ja', live: true, dir: 'ltr' },
  { code: 'ko', label: '한국어', flag: '-6px -166px', hreflang: 'ko', live: true, dir: 'ltr' },
  { code: 'no', label: 'Norsk', flag: '-384px -198px', hreflang: 'nb', live: false, dir: 'ltr' },
  { code: 'pl', label: 'Polski', flag: '-48px -230px', hreflang: 'pl', live: false, dir: 'ltr' },
  { code: 'pt', label: 'Português', flag: '-132px -230px', hreflang: 'pt', live: false, dir: 'ltr' },
  { code: 'ro', label: 'Română', flag: '-216px -230px', hreflang: 'ro', live: false, dir: 'ltr' },
  { code: 'ru', label: 'Русский', flag: '-258px -230px', hreflang: 'ru', live: true, dir: 'ltr' },
  { code: 'sr', label: 'Српски', flag: '', hreflang: 'sr', live: false, dir: 'ltr' },
  { code: 'sk', label: 'Slovenčina', flag: '-426px -230px', hreflang: 'sk', live: false, dir: 'ltr' },
  { code: 'sl', label: 'Slovenščina', flag: '', hreflang: 'sl', live: false, dir: 'ltr' },
  { code: 'es', label: 'Español', flag: '-6px -70px', hreflang: 'es', live: true, dir: 'ltr' },
  { code: 'sv', label: 'Svenska', flag: '-342px -262px', hreflang: 'sv', live: false, dir: 'ltr' },
  { code: 'th', label: 'ไทย', flag: '', hreflang: 'th', live: false, dir: 'ltr' },
  { code: 'tl', label: 'Tagalog', flag: '-132px -294px', hreflang: 'tl', live: false, dir: 'ltr' },
  { code: 'id', label: 'Indonesia', flag: '-6px -134px', hreflang: 'id', live: false, dir: 'ltr' },
  { code: 'uk', label: 'Українська', flag: '-258px -294px', hreflang: 'uk', live: false, dir: 'ltr' },
  { code: 'vi', label: 'Tiếng Việt', flag: '-216px -294px', hreflang: 'vi', live: false, dir: 'ltr' },
  { code: 'hu', label: 'Magyar', flag: '-384px -102px', hreflang: 'hu', live: false, dir: 'ltr' },
  { code: 'tr', label: 'Türkçe', flag: '-174px -294px', hreflang: 'tr', live: false, dir: 'ltr' },
  { code: 'ms', label: 'Melayu', flag: '-132px -198px', hreflang: 'ms', live: false, dir: 'ltr' },
  { code: 'ga', label: 'Gaeilge', flag: '-426px -70px', hreflang: 'ga', live: false, dir: 'ltr' },
  { code: 'hy', label: 'Հայերեն', flag: '-426px -102px', hreflang: 'hy', live: false, dir: 'ltr' },
  { code: 'ur', label: 'اردو', flag: '-300px -294px', hreflang: 'ur', live: false, dir: 'rtl' },
  { code: 'bn', label: 'বাংলা', flag: '-258px -6px', hreflang: 'bn', live: false, dir: 'ltr' },
];

export const defaultLocale = LOCALES[0];

const LOCALE_CODES = new Set(LOCALES.map((l) => l.code));

/**
 * Locale code carried by a path, or null when the path has no locale prefix. None of the 39
 * codes collides with a real route segment, so the first segment can be tested directly.
 */
export function localeOfPath(pathname) {
  const seg = String(pathname || '').split('/')[1] || '';
  return LOCALE_CODES.has(seg) ? seg : null;
}

/** The same path with any locale prefix removed, so route, TDK and breadcrumb lookups work. */
export function stripLocale(pathname) {
  const p = String(pathname || '/');
  const seg = p.split('/')[1] || '';
  if (!LOCALE_CODES.has(seg)) return p;
  const rest = p.slice(seg.length + 1);
  return rest.startsWith('/') ? rest : `/${rest}`;
}

/** Prefix a path for a locale. English is served unprefixed. */
export function withLocale(pathname, code) {
  const p = stripLocale(pathname);
  if (!code || code === defaultLocale.code) return p;
  // the root keeps its trailing slash so the canonical form is the conventional /de/ rather
  // than /de; a crawler treats those as two different URLs
  return p === '/' ? `/${code}/` : `/${code}${p}`;
}

export const COMPANY = {
  name: 'YIXINOU',
  legalName: 'Shenzhen Yixinou Electronic Co., Ltd.',
  tel: '+86 18516133798',
  telHref: 'tel:+8618516133798',
  whatsapp: 'https://wa.me/8618516133798',
  email: 'mailto:Jessie@yixinouchips.com',
  video: '/assets/videos/company.mp4',
  videoPoster: '/assets/images/about-video-poster.jpg',
  homeVideo: '/assets/videos/promo-30s.mp4',
  homeVideoPoster: '/assets/images/promo-poster.jpg',
  subscribeBg: '/assets/images/subscribe-bg.webp',
  qr: '/assets/qr-yixinou.svg',
};

// ---------------- About us ----------------
export const ABOUT_TEXT = [
  'Shenzhen Yixinou Electronic Co., Ltd. is an electronic component supplier based in Futian District, Shenzhen, China. We buy, verify and ship the parts our customers need to keep production running \u2014 from a single reel to a complete bill of materials.',
  'Most customers reach us when a line is short of a part, a bill of materials has to be quoted quickly, or a batch has to be checked before it goes into production. That is the work we are built for: confirming what is genuinely available, inspecting what arrives, and being straight with you when a part cannot be verified.',
  'We supply ICs, transistors, connectors, capacitors, resistors, sensors, switches, LEDs and modules. Our components are used in consumer electronics, IoT, new energy, communications, industrial and automotive applications, and we ship to customers across Asia, Europe, Africa and the Americas.',
];

export const ABOUT_FACTORY = [
  {
    img: '/assets/images/team-group.jpg',
    alt: 'The YIXINOU team photographed together in the Shenzhen office',
  },
  { img: '/assets/images/gallery-01.jpg', alt: 'Component reels and trays laid out for sorting' },
  { img: '/assets/images/gallery-02.jpg', alt: 'Outbound warehouse area before shipment' },
  { img: '/assets/images/gallery-03.jpg', alt: 'Warehouse aisle at the Shenzhen facility' },
  { img: '/assets/images/gallery-04.jpg', alt: 'Operators working on the surface-mount line' },
  { img: '/assets/images/gallery-05.jpg', alt: 'Precision assembly equipment on the surface-mount line' },
  { img: '/assets/images/gallery-06.jpg', alt: 'Component storage shelving in the warehouse' },
  { img: '/assets/images/gallery-07.jpg', alt: 'Packed orders labelled and ready for dispatch' },
];

export const CERTIFICATE_METADATA = [
  {
    src: '/assets/images/verpackg-registration-certificate.webp',
    title: 'YIXINOU German Packaging Act (VerpackG) registration certificate',
    alt: 'YIXINOU German Packaging Act (VerpackG) registration certificate issued by the Central Agency Packaging Register',
    width: 1658,
    height: 2339,
  },
  {
    src: '/assets/images/epr-leko-membership-certificate.webp',
    title: 'YIXINOU EPR household packaging membership certificate',
    alt: 'YIXINOU EPR household packaging membership certificate from Leko',
    width: 638,
    height: 860,
  },
  {
    src: '/assets/images/sgs-verified-supplier-assessment.webp',
    title: 'YIXINOU SGS verified supplier assessment certificate',
    alt: 'YIXINOU Alibaba.com verified supplier assessment report presented by SGS',
    width: 3173,
    height: 4490,
  },
  {
    src: '/assets/images/yixinou-class-9-trademark-registration.webp',
    title: 'YIXINOU Class 9 trademark registration certificate',
    alt: 'YIXINOU Class 9 trademark registration certificate for electronic components',
    width: 3173,
    height: 4512,
  },
];

export const CERTIFICATES = CERTIFICATE_METADATA.map(({ src }) => src);

// ---------------- All products ----------------
export const PRODUCT_CATEGORIES = [
  { label: 'Integrated Circuits（ICS）', href: '/all-products?category=Integrated Circuits (ICS)' },
  { label: 'Transistors', href: '/all-products?category=Transistors' },
  { label: 'Connector', href: '/all-products?category=Connector' },
  { label: 'Others', href: '/all-products?category=Others' },
  { label: 'Module', href: '/all-products?category=Module' },
  { label: 'Capacitors', href: '/all-products?category=Capacitors' },
  { label: 'Resistor', href: '/all-products?category=Resistor' },
  { label: 'Sensor', href: '/all-products?category=Sensor' },
  { label: 'Switch', href: '/all-products?category=Switch' },
  { label: 'LED', href: '/all-products?category=LED' },
];

// ---------------- Blogs ----------------
export const BLOG_POSTS = [
  {
    title: 'Designing a switch-mode power supply? This transistor is a top-tier option.',
    href: '/-designing-a-switch---mode-power-supply-this-transistor-is-a-top---tier-option',
    img: '/assets/images/blog-r01.jpg',
    date: '20250411',
    snippet:
      'Understanding Transistor Requirements in Modern Power Conversion — For those designing switch-mode power supplies (SMPS), it\'s like walking a tightrope. They have to balance three important things: efficiency, size, and reliability. And right at the...',
  },
  {
    title: 'Need high-speed data transmission? These integrated circuits are worth considering.',
    href: '/-need-high---speed-data-transmission-these-integrated-circuits-are-worth-considering',
    img: '/assets/images/blog-r02.jpg',
    date: '20250415',
    snippet:
      'Key Features of Modern Data Transmission Components — In today\'s digital age, where information travels at lightning speed, the components designed for high-speed data transfer are truly remarkable. These advanced integrated circuits have their eyes...',
  },
  {
    title: 'Working on advanced signal processing? Find the right IC chip here.',
    href: '/-working-on-advanced-signal-processing-find-the-right-ic-chip-here',
    img: '/assets/images/blog-r03.jpg',
    date: '20250407',
    snippet:
      'Critical Factors in Selecting IC Chips for Signal Processing — When it comes to advanced signal processing systems, the integrated circuits (ICs) we choose are like the heart and brain of the operation. These systems have high demands. They need ICs th...',
  },
  {
    title: 'Tired of electromagnetic interference? These inductors can eliminate it.',
    href: '/tired-of-electromagnetic-interference-these-inductors-can-eliminate-it',
    img: '/assets/images/blog-r04.jpg',
    date: '20250403',
    snippet:
      'The Hidden Costs of Uncontrolled EMI — In today\'s modern world, where electronic systems are everywhere, we often don\'t realize the lurking threat of electromagnetic interference (EMI). EMI shows up in various annoying ways, like those pesky unwanted v...',
  },
  {
    title: 'Looking for a connector with low-resistance connections? This one has top-notch conductivity.',
    href: '/essential-guide-to-high---performance-low---resistance-electrical-connectors',
    img: '/assets/images/blog-r05.jpg',
    date: '20250401',
    snippet:
      'Struggling with energy loss and overheating in electrical systems? Discover how low-resistance connectors improve efficiency, reliability, and ROI. Get expert selection & maintenance tips now.',
  },
  {
    title: 'Exploring the Benefits of Build in Smart IC Chip Technology',
    href: '/exploring-the-benefits-of-build-in-smart-ic-chip-technology',
    img: '/assets/images/blog-r06.jpg',
    date: '20250115',
    snippet:
      'Benefits of Smart IC Chips — With the increasing advancement in technology, there is much focus in the smart integrated chip technology. Their small size enable usage in electronics, communications, medicine, and even in automobiles. The advantages are...',
  },
  {
    title: 'The Benefits of 12W SMD Transistors in Compact Designs',
    href: '/the-benefits-of-12w-smd-transistors-in-compact-designs',
    img: '/assets/images/blog-r07.jpg',
    date: '20250124',
    snippet:
      'The evolution of electronics has led to increased emphasis on components such as circuits, microcontrollers, and sensors. This advancement also comes with challenges like miniaturization of electronics. Hence the increased use of SMDs (Surface Mount...',
  },
  {
    title: 'Definition and fundamentals of IC testing',
    href: '/definition-and-fundamentals-of-ic-testing',
    img: '/assets/images/blog-r08.jpg',
    date: '20240805',
    snippet:
      'Integrated Circuit Testing refers to the process of testing the performance, functionality and reliability of integrated circuits. The purpose of IC testing is to ensure that integrated circuits can meet the design requirements and performance targets in practical applications, and to improve the reliability and stability of integrated circuits.',
  },
  {
    title: 'A few knowledges about PCB',
    href: '/a-few-knowledges-about-pcb',
    img: '/assets/images/blog-r09.jpg',
    date: '20240730',
    snippet:
      'As the mother of electronic components, PCB plays an important role in electronic applications. According to different design principles, PCB can be divided into single panel, multi-layer board, soft board, hard board, soft and hard combined board and other types.',
  },
  {
    title: 'Visit the Munich Shanghai Electronics Fair',
    href: '/visit-the-munich-shanghai-electronics-fair',
    img: '/assets/images/blog-r10.jpg',
    date: '20240725',
    snippet:
      'The electronics industry in the first half of this year is not very good, but the Munich Shanghai Electronics Show on July 8 is extremely hot, including more than 1670 exhibitors, more than 75,400 professional visitors to the scene. A number of companies focused on new energy vehicles, photovoltaic, energy storage, robotics, third-generation semiconductors and other cutting-edge hot areas.',
  },
  {
    title: 'Company summer collective meals in Shenzhen China 2024',
    href: '/company-summer-collective-meals-in-shenzhen-china-2024',
    img: '/assets/images/blog-r11.jpg',
    date: '20240715',
    snippet:
      'We organised a summer group dinner at the five-star hotel Grand Cloud Sky in Shenzhen. In 24th July, not only all the staffs of the company attended the activity, but also invited our domestic famous brand agent friends. We gathered together to enjoy a delicious dinner, but also reach an agreement in the supplying and selling of electronic components.',
  },
  {
    title: 'Key Factors to Consider When Selecting Semiconductor IC Chips for Industrial Use',
    href: '/Key-Factors-to-Consider-When-Selecting-Semiconductor-IC-Chips-for-Industrial-Use',
    img: '/assets/images/blog-r12.jpg',
    date: '20251108',
    snippet:
      'Ensure 10+ year reliability and lower TCO with proven semiconductor selection strategies for harsh industrial environments. Discover how mature nodes, thermal design, and lifecycle planning reduce failures and costs. Get the full guide.',
  },
];

// ---------------- Contact ----------------
export const CONTACT_INFO = [
  { icon: 'building', label: 'Company Name', value: 'Shenzhen Yixinou Electronic Co., Ltd.' },
  { icon: 'pin', label: 'Address', value: 'Room 2501-2503, Tower A, New Asia Guoli Building, No. 18 Zhonghang Road, Futian District, Shenzhen City,GuangDong Provice,China.518031' },
  { icon: 'phone', label: 'Phone', value: '+86 18516133798', href: 'tel:+8618516133798' },
  { icon: 'whatsapp', label: 'WhatsApp', value: '8618516133798', href: 'https://wa.me/8618516133798' },
  { icon: 'mail', label: 'E-mail', value: 'Jessie@yixinouchips.com', href: 'mailto:Jessie@yixinouchips.com' },
  { icon: 'wechat', label: 'Wechat', value: '18516133798' },
];

export const CONTACT_LABEL_KEYS = {
  'Company Name': 'contact.companyName',
  Address: 'contact.address',
  Phone: 'contact.phone',
  WhatsApp: 'contact.whatsapp',
  'E-mail': 'contact.email',
  Wechat: 'contact.wechat',
};

export const MAP_EMBED =
  'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14739.62244575719!2d114.08631886226314!3d22.54520829010234!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3403f437b1835c39%3A0xa312c0a9f02af1ce!2sHuaqiangbei%2C%20Futian%20District%2C%20Shenzhen%2C%20Guangdong%20Province%2C%20China%2C%20518027!5e0!3m2!1sen!2sus!4v1723632347776!5m2!1sen!2sus';

// ---------------- Industries we serve (home page) ----------------
export const INDUSTRIES = [
  {
    key: 'industrial',
    img: '/assets/images/industry-industrial.jpg',
    title: 'Industrial Electronics',
    desc: 'Industrial electronics refers to the application of electronic devices, systems, and technologies in industrial settings to automate processes, monitor operations, and control machinery and equipment.',
    href: '/industries/industrial-automation',
  },
  {
    key: 'medical',
    img: '/assets/images/industry-medical.jpg',
    title: 'Medical Devices',
    desc: 'Medical devices encompass a broad category of instruments, machines, implants, and other tools used in healthcare settings for the diagnosis, treatment, monitoring, and management of medical conditions.',
    href: '/industries/healthcare',
  },
  {
    key: 'marine',
    img: '/assets/images/industry-marine.jpg',
    title: 'Marine',
    desc: 'Marine electronics is a specialized sector within the broader electronics industry that focuses on developing, manufacturing, and supplying electronic systems, devices, and equipment specifically designed for maritime applications.',
    href: '/all-products',
  },
  {
    key: 'battery',
    img: '/assets/images/industry-battery.jpg',
    title: 'Battery/Charge',
    desc: 'Battery and charging technologies are integral components of the electronics industry, powering a wide range of devices from portable electronics to electric vehicles and renewable energy systems.',
    href: '/all-products',
  },
  {
    key: 'aerospace',
    img: '/assets/images/industry-aerospace.jpg',
    title: 'Aerospace/Aviation',
    desc: 'Aerospace and aviation are sectors within the broader electronics industry that encompass the design, development, manufacturing, and operation of aircraft, spacecraft, satellites, and related systems.',
    href: '/industries/aerospace',
  },
  {
    key: 'renewable',
    img: '/assets/images/industry-renewable.jpg',
    title: 'Renewable Energy',
    desc: 'Renewable energy refers to energy derived from sources that are naturally replenished on a human timescale and can be continuously used without the risk of depletion.',
    href: '/industries/energy',
  },
  {
    key: 'automotive',
    img: '/assets/images/industry-automotive.jpg',
    title: 'Automotive',
    desc: 'Automotive electronics is a specialized branch of the electronics industry that focuses on the development, manufacturing, and integration of electronic systems and components into vehicles.',
    href: '/industries/automotive',
  },
  {
    key: 'consumer',
    img: '/assets/images/industry-consumer.jpg',
    title: 'Consumer Electronics',
    desc: 'Consumer electronics refer to electronic devices designed for everyday use by individuals in their personal and domestic environments.',
    href: '/industries/consumer-electronics',
  },
];

// ---------------- Quality ----------------
// Layout follows the reference quality-process page; wording, figures and
// imagery are YIXINOU's own. Third-party brand names, certification badges and
// supplier/engineer counts belonging to the reference site are not reproduced.
// Images: real photographs of YIXINOU's own facility and real stills from the
// company video, except where noted (steps 2, 4 and 5).
export const QUALITY = {
  banner: '/assets/images/quality-banner.jpg',
  hero: {
    eyebrow: 'Quality',
    title: 'Every order inspected before it ships',
    lead: 'YIXINOU supplies ICs, transistors, connectors, capacitors, resistors, sensors, switches, LEDs and modules to buyers who cannot afford a bad lot. Components are checked on arrival at our Shenzhen facility, and anything that needs internal analysis goes to our partner laboratories.',
    points: [
      'Incoming inspection on every order we receive',
      'External visual inspection under a digital microscope',
      'Internal analysis and electrical testing by our partner laboratories',
      'An inspection record kept for the lots we ship',
    ],
    ctaLabel: 'Contact our quality team',
    ctaHref: '/Contact',
    img: '/assets/images/quality-hero-inspection.jpg',
    alt: 'A YIXINOU inspector operating a digital inspection microscope at his work station, with the magnified component shown on the screen beside him',
  },
  checks: {
    eyebrow: 'What we check',
    title: 'Four things we do on every order',
    items: [
      {
        icon: 'sampling',
        title: 'Agreed Sampling',
        text: 'We agree the sampling plan with you before we start, and adapt it to the part, the quantity and your own acceptance criteria.',
      },
      {
        icon: 'visual',
        title: 'Visual Inspection',
        text: 'External checks under a digital microscope for damaged, re-marked or mismatched parts, plus lead, scrape, acetone and marking-permanency testing.',
      },
      {
        icon: 'records',
        title: 'Inspection Records',
        text: 'We keep the inspection result, the photographs and the lot and date codes for every shipment, so you can trace what was checked.',
      },
      {
        icon: 'reporting',
        title: 'Reporting To Your Format',
        text: 'Tell us what your report needs to contain and we will include the findings with your shipment.',
      },
    ],
  },
  process: {
    eyebrow: 'Our Process',
    title: 'Our Quality Process',
    statement:
      'Practical inspection equipment applied to every order we handle — and a partner laboratory whenever a part needs deeper analysis.',
    note: 'Steps 1 to 3 are carried out at our own facility in Shenzhen. Steps 4 and 5 are carried out by our partner laboratories — YIXINOU does not operate its own testing laboratory, and we say so plainly so you know exactly who tests your parts.',
    steps: [
      {
        title: 'Photography and Review',
        text: [
          'We count and organise your components by part and serial number, and photograph them as received.',
          'We record the quantity and country of origin, then give each lot its own lot and date code.',
        ],
        img: '/assets/images/quality-step-1-photography.jpg',
        alt: 'Electronic component reels, trays and anti-static bags laid out in labelled rows on the sorting floor at the YIXINOU facility',
        inhouse: true,
      },
      {
        title: 'Barcode Scanning and Review',
        text: [
          'A second review confirms exact quantities and specifications against your order.',
          'Labels are scanned into our records, so each part stays traceable to the lot it came from.',
        ],
        img: '/assets/images/quality-step-2-barcode.jpg',
        alt: 'Illustration: a handheld barcode scanner reading the label of a sealed anti-static bag held over a bench',
        inhouse: true,
        illustrative: true,
      },
      {
        title: 'Visual Inspection',
        text: [
          'Our inspectors examine components externally under a digital inspection microscope.',
          'We check for damaged, re-marked or mismatched parts, and run lead inspection, scrape testing, acetone testing and marking permanency testing.',
        ],
        img: '/assets/images/quality-step-3-visual.jpg',
        alt: 'A YIXINOU inspector positioning a component under a digital inspection microscope, with the magnified surface of the part displayed on the monitor behind',
        inhouse: true,
      },
      {
        title: 'Laboratory Inspection and Testing',
        text: [
          'Parts that need internal analysis are sent to our partner laboratories, where their engineers carry out advanced testing using X-ray, X-ray Fluorescence (XRF) and high-magnification microscopy.',
          'Their laboratories also perform heated and chemical decapsulation to verify that a part is genuine, together with solderability testing to confirm the leads or terminations can be reliably soldered.',
        ],
        img: '/assets/images/quality-step-4-laboratory.jpg',
        alt: 'Illustration: X-ray inspection cabinet, XRF analyser and inspection microscope on a partner laboratory bench with a tray of component samples',
        inhouse: false,
        illustrative: true,
      },
      {
        title: 'Electrical Testing',
        text: [
          "Electrical performance is measured at our partner laboratories against the part's datasheet specification.",
          'Their engineers use curve tracers, functional testing, or inductance, capacitance and resistance (LCR) measurement to characterise active and passive parts.',
        ],
        img: '/assets/images/quality-step-5-electrical.jpg',
        alt: 'Illustration: curve tracer and LCR test bench with a component held in a test fixture and measurement traces on screen',
        inhouse: false,
        illustrative: true,
      },
    ],
  },
  midCta: {
    title: 'Tell us what your parts need to pass',
    text: 'Send us your acceptance criteria — sampling level, tests required and report format — and we will confirm exactly how we will check your order before it reaches you.',
    ctaLabel: 'Send us your requirements',
    ctaHref: '/Contact',
  },
  standard: {
    eyebrow: 'Why YIXINOU',
    title: 'Excellence Is Our Standard',
    blocks: [
      {
        eyebrow: 'Qualification',
        title: 'Suppliers we can stand behind',
        text: 'We buy from suppliers we have qualified and we keep the ones that perform. Suppliers with reported quality issues are restricted or removed from our list. Where a part\u2019s history cannot be verified, we tell you rather than ship it as certain.',
        img: '/assets/images/quality-standard-vendors.jpg',
        alt: 'High-bay racking holding palletised electronic components in the YIXINOU warehouse',
      },
      {
        eyebrow: 'Traceability',
        title: 'A record for every lot',
        text: 'Every shipment is logged with its inspection result, its photographs and its lot and date codes. If you need to know what was checked on a specific lot, we can pull the record and send it to you.',
        img: '/assets/images/quality-standard-records.jpg',
        alt: 'YIXINOU staff at their work stations maintaining the inspection and shipment records',
      },
    ],
  },
  stats: {
    eyebrow: 'By the Numbers',
    title: 'The YIXINOU Advantage',
    items: [
      { value: '8+', label: 'Years in the Components Industry' },
      { value: '10', label: 'Product Categories Supplied' },
      { value: '20+', label: 'Partners Worldwide' },
      { value: '5', label: 'Continents Shipped To' },
    ],
  },
  services: {
    eyebrow: 'Quality Services',
    title: 'Setting the Standard for Quality',
    items: [
      {
        icon: 'process',
        title: 'Incoming Inspection',
        text: 'See the five checks we apply to your components, and where each one is carried out.',
        href: '/quality#quality-process',
      },
      {
        icon: 'report',
        title: 'Inspection Reporting',
        text: 'Ask for the findings, photographs and lot records for your shipment, in the format your team needs.',
        href: '/Contact',
      },
      {
        icon: 'shield',
        title: 'Supplier Qualification',
        text: 'How we screen the suppliers we buy from, and what we do when one of them underperforms.',
        href: '/quality#quality-standard',
      },
      {
        icon: 'testing',
        title: 'Component Testing',
        text: 'Arrange X-ray, XRF, decapsulation, solderability or electrical testing through our partner laboratories.',
        href: '/Contact',
      },
      {
        icon: 'team',
        title: 'Quality Control Team',
        text: 'Meet the inspectors who check your components and coordinate testing on your behalf.',
        href: '/about-us',
      },
      {
        icon: 'award',
        title: 'Certifications',
        text: 'Browse the certifications and cross-industry memberships that back our quality services.',
        href: '/about-us',
      },
    ],
  },
  faq: {
    eyebrow: 'Common Questions',
    title: 'Questions buyers ask us about quality',
    items: [
      {
        q: 'Do you test components in-house?',
        a: 'Partly. Incoming inspection, photography, barcode review and external visual inspection under a digital microscope are carried out in-house at our Shenzhen facility. Internal analysis — X-ray, XRF, decapsulation, solderability and electrical testing — is carried out by our partner laboratories.',
      },
      {
        q: 'Who performs your laboratory testing?',
        a: 'Our partner laboratories. YIXINOU does not operate its own testing laboratory, and we state that plainly so you know exactly who is testing your parts.',
      },
      {
        q: 'Can I get an inspection report with my order?',
        a: 'Yes. Tell us what your report needs to contain and we will include the findings, photographs and lot records with your shipment.',
      },
      {
        q: 'What happens if you find a problem?',
        a: 'We stop the lot and come back to you with what we found and the evidence behind it, rather than shipping it and hoping it passes your incoming check.',
      },
      {
        q: 'How much of my order do you check?',
        a: 'We agree the sampling plan with you before we start. Larger quantities, mixed lots and unverified sources are checked more heavily.',
      },
    ],
  },
  closing: {
    title: 'Quality Control',
    text: 'Every part inspected. See what\u2019s available.',
    primary: { label: 'Contact Us', href: '/Contact' },
    secondary: { label: 'Explore All Products', href: '/all-products' },
  },
};

// ---------------- About page (Our Story) ----------------
// Narrative structure follows the reference "Our Story" page. Every figure and
// statement here is YIXINOU's own; the reference site's founding year, headcount,
// offices, milestones and named executives are deliberately not reproduced.
export const ABOUT_EXTRA = {
  hero: {
    eyebrow: 'Our Story',
    title: 'Eight years sourcing the components your production depends on',
    statement:
      'Shenzhen Yixinou Electronic Co., Ltd. is an independent distributor of electronic components. We supply ICs, transistors, connectors, capacitors, resistors, sensors, switches, LEDs and modules from Shenzhen to customers on five continents.',
    ctaLabel: 'Talk to our team',
    ctaHref: '/Contact',
    img: '/assets/images/about-hero.jpg',
    alt: 'The YIXINOU team at their desks in the Shenzhen sales office',
  },
  cards: [
    {
      icon: 'sourcing',
      title: 'Component Sourcing',
      text: 'ICs, transistors, connectors, capacitors, resistors, sensors, switches, LEDs and modules, sourced against your bill of materials.',
    },
    {
      icon: 'bom',
      title: 'BOM and One-Stop Orders',
      text: 'Send us a bill of materials and we quote the whole line, rather than one part at a time.',
    },
    {
      icon: 'inspection',
      title: 'Incoming Inspection',
      text: 'Every order is checked on arrival at our Shenzhen facility before it is packed for you.',
    },
    {
      icon: 'export',
      title: 'Export and Logistics',
      text: 'Documentation, packing and shipping to customers across five continents.',
    },
  ],
  facts: {
    eyebrow: 'At a Glance',
    title: 'YIXINOU at a glance',
    items: [
      { value: '8+', label: 'Years in the components business' },
      { value: '10', label: 'Product categories supplied' },
      { value: '5', label: 'Continents shipped to' },
      { value: 'Shenzhen', label: 'Registered office and warehouse' },
    ],
  },
  values: {
    eyebrow: 'Our Values',
    title: "Here's what drives us forward.",
    items: [
      {
        title: 'Accuracy first',
        text: 'We would rather tell you a part cannot be verified than ship it and let you find out at your incoming inspection.',
      },
      {
        title: 'Traceability',
        text: 'Lots, date codes and inspection records are kept, so when you ask what was checked, we can answer.',
      },
      {
        title: 'Straight answers',
        text: 'That includes who tests your parts: laboratory analysis is carried out by our partner laboratories, and we say so plainly.',
      },
      {
        title: 'Responsiveness',
        text: 'Quotations and stock checks come back as fast as we can turn them around.',
      },
      {
        title: 'Relationships over orders',
        text: 'We would rather keep a customer for years than win a single order.',
      },
      {
        title: 'Continuous improvement',
        text: 'Every claim is logged and reviewed, and it changes how we source and inspect.',
      },
    ],
  },
  team: {
    eyebrow: 'Our Team',
    title: 'The people you will deal with',
    lead: 'One team handles your enquiry, your quotation and your inspection records, so you are not passed from desk to desk.',
  },
  video: {
    eyebrow: 'A closer look',
    title: 'Inside our Shenzhen operation',
    text: 'Filmed at our facility \u2014 the work stations, the inspection bench and the components we handle every day.',
  },
  related: {
    eyebrow: 'About Us',
    title: 'Learn more about us.',
    items: [
      {
        title: 'Quality Process',
        text: 'The five checks we apply to your components, and where each one is carried out.',
        href: '/quality',
      },
      {
        title: 'All Products',
        text: 'ICs, transistors, connectors, capacitors, resistors, sensors, switches, LEDs and modules.',
        href: '/all-products',
      },
      {
        title: 'Blogs',
        text: 'Industry information and company news from the components market.',
        href: '/blogs800',
      },
      {
        title: 'Contact Us',
        text: 'Send us your bill of materials or your enquiry and we will come back to you.',
        href: '/Contact',
      },
    ],
  },
};

// ---------------- Sub-banner marketing copy ----------------
// Every figure quoted here is taken from the site's own content:
//   8+ years       -> ABOUT_EXTRA.facts
//   12 industries  -> INDUSTRY_LIST / INDUSTRIES_PAGE.items length
//   10 categories  -> PRODUCT_CATEGORIES length
//   5 continents   -> ABOUT_EXTRA.facts
export const PAGE_BANNERS = {
  '/about-us': {
    title: 'Eight years sourcing electronic components from Shenzhen',
    sub:
      'Shenzhen Yixinou Electronic Co., Ltd. supplies ICs, transistors, connectors, capacitors '
      + 'and modules to customers on five continents — every order inspected before it ships.',
    cta: { label: 'Talk to our team', href: '/Contact' },
    micro: 'Incoming inspection on every order · Laboratory testing through our partner laboratories',
  },
  '/industries': {
    title: 'One components supplier for twelve industries',
    sub:
      'Aerospace to automotive, healthcare to telecom — we source the parts your sector runs on, '
      + 'verify them on arrival, and quote against your bill of materials.',
    cta: { label: 'Ask about your industry', href: '/Contact' },
    micro: '12 industries · 10 product categories · Customers on five continents',
  },
  '/all-products': {
    title: 'ICs, transistors, connectors, capacitors and more',
    sub:
      'Send us your bill of materials and we quote the whole line — not one part at a time. '
      + 'Incoming inspection is included on every order.',
    cta: { label: 'Get a Free Quote', href: '/Contact' },
    micro: 'BOM and one-stop orders · Line-down sourcing · Export to five continents',
  },
};

// ---------------- Product parts ----------------
// Per-part content for the /product/:mpn detail template. Every specification
// below is taken from the part's own data sheet in the product material folder
// (产品素材/<mpn>/<mpn>产品信息.md) — nothing here is inferred.
export const PRODUCT_PARTS = {

  'H5CGD8MGBDX021N': {
    mpn: 'H5CGD8MGBDX021N',
    brand: 'SK hynix',
    title: 'DDR5 SDRAM 24Gb x8 die',
    category: 'Integrated Circuits (ICS) / Memory / DRAM (DDR5)',
    categoryHref: '/all-products',
    summary:
      'DDR5 SDRAM 24Gb x8 die with an 8-bit data bus, supplied in a 96-ball BGA package '
      + 'from the H5CGD series. It runs at a 2800 MHz operating frequency from a 1.1 V '
      + 'nominal supply with a 1.045 V to 1.155 V tolerance band, and is specified from '
      + '0 \u00b0C to +95 \u00b0C.',
    img: '/assets/images/h5cgd8mgbdx021n-bga-96-package.jpg',
    alt: 'A 96-ball BGA package, the package type used for the DDR5 SDRAM die H5CGD8MGBDX021N',
    imageNote:
      'Illustrative package image. A photograph of the actual lot is available on request.',
    specs: [
      ['Density', '24 Gb'],
      ['Data bus width', 'x8 (8 bit)'],
      ['Memory technology', 'DDR5 SDRAM'],
      ['Frequency', '2800 MHz'],
      ['Supply voltage', '1.1 V nominal (1.045 V \u2013 1.155 V)'],
      ['Package', '96-ball BGA (BGA-96)'],
      ['Mount', 'Surface mount'],
      ['Operating temperature', '0 \u00b0C to +95 \u00b0C'],
      ['Series', 'H5CGD'],
      ['Industry classification', 'IC / Memory / DRAM (DDR5 die)'],
    ],
    about:
      'The H5CGD8MGBDX021N is a 24 Gb DDR5 SDRAM die with an 8-bit data bus, supplied in a '
      + '96-ball BGA package from the H5CGD series. It runs at a 2800 MHz operating frequency '
      + 'from a 1.1 V nominal supply with a 1.045 V to 1.155 V tolerance band, and is specified '
      + 'across a 0 \u00b0C to +95 \u00b0C operating temperature range. The 24 Gb density is a '
      + 'non-binary DDR5 die size, which lets module makers reach capacities such as 48 GB and '
      + '96 GB that were not available from 8 Gb and 16 Gb dies alone. As a die-level part it is '
      + 'surface mounted, so it is intended for module assembly and board-down designs rather '
      + 'than as a plug-in module.',
    standards: ['JEDEC JESD79-5 (DDR5 SDRAM)', '96-ball BGA package outline'],
    features: [
      '24 Gb density with an x8 data bus width',
      'DDR5 SDRAM, JEDEC JESD79-5',
      '2800 MHz operating frequency',
      '1.1 V supply with a 1.045 V to 1.155 V range',
      '96-ball BGA package, surface mount',
      '0 \u00b0C to +95 \u00b0C operating temperature range',
      'H5CGD series',
    ],
    applications: [
      '48 GB and 96 GB RDIMM and UDIMM module builds',
      'Servers and data-centre platforms',
      'The host memory tier of AI and GPU compute nodes',
      'High-end workstations',
    ],
    faq: [
      {
        q: 'What is the H5CGD8MGBDX021N used for?',
        a: 'Non-binary 24 Gb DDR5 dies are bought mainly by module manufacturers building the 48 GB and 96 GB RDIMM and UDIMM capacities used in current-generation servers and workstations, and for the host memory tier of AI and GPU compute nodes, where capacity per memory channel is the limiting resource. Buying at the component level rather than as finished modules is typical for module houses, board-down embedded designs, and buyers securing DRAM die supply while allocation is tight. The 0 \u00b0C to +95 \u00b0C range is standard commercial DRAM, so enclosure airflow has to keep the device inside that band. Tell us the module capacity you are building and we will confirm what we can evidence for the specific lot we are quoting.',
      },
      {
        q: 'What do buyers check before ordering an H5CGD8MGBDX021N?',
        a: 'The questions we are asked most often on DDR5 dies are: whether the parts are original dies or downgraded / eTT white-label material, which carries a high risk at this generation; whether a 2800 MHz part will run at a lower speed on the platform already in the design; whether the non-binary 24 Gb density is supported by the module controller and firmware in use, and whether the 96-ball footprint and x8 organisation match the intended module layout; lot consistency and whether the original factory packaging and anti-counterfeit marks are intact; and how price and lead time are locked given how sharply DDR5 pricing moves. Tell us which of these matter for your build and we will confirm what we can evidence for the specific lot we are quoting.',
      },
      {
        q: 'How does YIXINOU check an H5CGD8MGBDX021N before it ships?',
        a: 'Every order is checked on arrival at our Shenzhen facility. We count and photograph the parts as received, record the quantity and country of origin, and assign lot and date codes. Labels are scanned into our records, and the parts are inspected externally under a digital inspection microscope for re-marking, physical damage or mismatched material. Where you need internal analysis \u2014 X-ray, XRF, heated or chemical decapsulation, solderability, or electrical testing such as curve tracing and LCR measurement \u2014 we send the parts to our partner laboratories and share the findings. YIXINOU does not operate its own testing laboratory, and we say so plainly so you know exactly who is testing your parts.',
      },
    ],
  },
  'AD5544ARSZ-REEL7': {
    mpn: 'AD5544ARSZ-REEL7',
    brand: 'Analog Devices',
    title: 'Quad 16-bit current-output DAC',
    category: 'Integrated Circuits (ICS) / Data Converters / Digital to Analog Converters (DAC)',
    categoryHref: '/all-products',
    summary:
      'The AD5544ARSZ-REEL7 is a quad, 16-bit, current-output digital-to-analogue converter '
      + 'from Analog Devices, supplied in a 28-lead SSOP package on tape and reel. It carries '
      + 'four independent DAC channels behind a 3-wire SPI-compatible serial interface and '
      + 'settles to +/-1 LSB in 900 ns typical. Because the output is a current rather than a '
      + 'voltage, a precision op-amp is needed to make the current-to-voltage conversion. It '
      + 'runs from a 3 V to 5.5 V supply and is specified from -40 \u00b0C to +125 \u00b0C.',
    img: '/assets/images/ad5544arsz-reel7-ssop-28.jpg',
    alt: 'A 28-lead SSOP package, the package used for the AD5544ARSZ-REEL7 quad 16-bit DAC',
    imageNote: 'Illustrative package image. Ask us for a photograph of the actual lot.',
    specs: [
      ['Resolution', '16 bit'],
      ['DAC channels', '4'],
      ['Output type', 'Current output (external I-V amplifier required)'],
      ['Interface', 'SPI, 3-wire serial'],
      ['Settling time', '900 ns typical'],
      ['Integral nonlinearity', '+/-2 LSB max'],
      ['Supply voltage', '3 V to 5.5 V'],
      ['Package', '28-lead SSOP (ARSZ)'],
      ['Operating temperature', '-40 \u00b0C to +125 \u00b0C'],
      ['Packaging', 'Tape and reel (REEL7)'],
    ],
    about:
      'The AD5544 family is built for systems that need several tightly matched 16-bit '
      + 'channels in one package rather than a separate converter per channel. Each of the four '
      + 'DACs is current-output, so the design pairs the part with a precision op-amp for the '
      + 'current-to-voltage stage and a stable voltage reference for the +/-10 V reference '
      + 'input. It also works in four-quadrant multiplying mode, which lets a varying reference '
      + 'scale the output. Typical homes are precision instruments, automated test equipment, '
      + 'industrial process control and medical imaging, where the per-channel cost and the '
      + 'matched channel-to-channel behaviour matter more than raw speed.',
    standards: [
      'Analog Devices AD5544/AD5554 datasheet Rev. F',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Four independent 16-bit DAC channels in one package',
      'Current output, converted to voltage with an external op-amp',
      '3-wire SPI-compatible serial interface',
      '900 ns typical settling time',
      'Four-quadrant multiplying mode',
      '+/-10 V reference voltage input range',
      '+/-2 LSB max integral nonlinearity',
      '3 V to 5.5 V single supply',
    ],
    applications: [
      'Precision instrumentation',
      'Automated test equipment (ATE)',
      'Industrial process control',
      'Medical imaging',
      'Programmable power supplies and bias circuits',
    ],
    faq: [
      {
        q: 'What is the AD5544ARSZ-REEL7 used for?',
        a: 'It is used where a design needs four matched 16-bit analogue outputs in a small '
          + 'footprint: precision instruments, automated test equipment, industrial process '
          + 'control loops, medical imaging front ends, and programmable bias or supply rails. '
          + 'Because the output is a current, it suits designs that already need a precision '
          + 'op-amp stage, and the +/-10 V reference input lets the output span be scaled by an '
          + 'external reference in multiplying applications.',
      },
      {
        q: 'What do buyers check before ordering an AD5544ARSZ-REEL7?',
        a: 'The first question is whether the design can take a current-output DAC at all, '
          + 'because that decision adds a precision op-amp and a reference to the bill of '
          + 'materials. After that buyers compare INL and DNL against the accuracy budget, check '
          + 'whether the 16-bit resolution of this part is needed over the 14-bit AD5543/AD5545 '
          + 'siblings, confirm the reference source and its temperature drift, and satisfy '
          + 'themselves that the parts are original Analog Devices material in factory packaging '
          + 'rather than reworked or downgraded stock.',
      },
      {
        q: 'How does YIXINOU check an AD5544ARSZ-REEL7 before it ships?',
        a: 'Incoming inspection at our Shenzhen facility checks the SSOP-28 body and lead '
          + 'coplanarity, the laser marking against the expected Analog Devices format, and the '
          + 'factory packaging and labelling. Laboratory analysis \u2014 X-ray, XRF, '
          + 'decapsulation, solderability and electrical testing \u2014 is carried out by our '
          + 'partner laboratories; YIXINOU does not operate its own testing laboratory. Tell us '
          + 'what your design needs proven and we will say plainly which checks were done and '
          + 'who performed them.',
      },
    ],
  },
  'AD633JRZ-RL': {
    mpn: 'AD633JRZ-RL',
    brand: 'Analog Devices',
    title: 'Four-quadrant analogue multiplier',
    category: 'Integrated Circuits (ICS) / Linear ICs / Analog Multipliers',
    categoryHref: '/all-products',
    summary:
      'The AD633JRZ-RL is a four-quadrant analogue multiplier from Analog Devices in an 8-lead '
      + 'SOIC package, supplied on tape and reel. It computes W = (X1 - X2)(Y1 - Y2) / 10 V + Z '
      + 'using laser-trimmed internal resistors, so it needs no external trimming components. '
      + 'Inputs accept +/-10 V and the small-signal output bandwidth is 1 MHz. The J grade used '
      + 'here is specified from 0 \u00b0C to +70 \u00b0C and runs from a +/-8 V to +/-18 V dual '
      + 'supply.',
    img: '/assets/images/ad633jrz-rl-soic-8.jpg',
    alt: 'An 8-lead SOIC AD633J analogue multiplier with its date code visible on the package',
    imageNote:
      'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a '
      + 'photograph of the actual lot.',
    specs: [
      ['Function', 'Four-quadrant analogue multiplier'],
      ['Transfer function', 'W = (X1 - X2)(Y1 - Y2) / 10 V + Z'],
      ['Input voltage range', '+/-10 V'],
      ['Output bandwidth', '1 MHz (small signal)'],
      ['Total error', '2 % typical (laser-trimmed)'],
      ['Supply voltage', '+/-8 V to +/-18 V (dual)'],
      ['External components', 'None required'],
      ['Package', '8-lead SOIC (JRZ)'],
      ['Operating temperature', '0 \u00b0C to +70 \u00b0C (J grade)'],
      ['Packaging', 'Tape and reel (RL)'],
    ],
    about:
      'The AD633 is the low-cost multiplier in the Analog Devices analogue-function line: it '
      + 'multiplies two analogue signals and sums an optional Z input, which is what makes it '
      + 'useful for gain control, modulation and power measurement rather than for arithmetic '
      + 'alone. On-chip laser trimming removes the external trim network that older multipliers '
      + 'required. The J grade in this part number is the commercial temperature grade, so it '
      + 'fits benchtop instruments, teaching and consumer-grade signal processing; designs that '
      + 'have to hold accuracy over a wider temperature range should look at the A, B or S '
      + 'grades instead.',
    standards: [
      'Analog Devices AD633 datasheet Rev. K',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Four-quadrant multiplication',
      'Transfer function W = (X1 - X2)(Y1 - Y2) / 10 V + Z',
      'Laser-trimmed for accuracy, no external trim network',
      '+/-10 V input range',
      '1 MHz small-signal output bandwidth',
      '+/-8 V to +/-18 V dual supply',
      '8-lead SOIC package',
      'Commercial J grade, 0 \u00b0C to +70 \u00b0C',
    ],
    applications: [
      'Analogue signal processing',
      'Instantaneous active power measurement',
      'Modulation and mixing',
      'Automatic gain control (AGC)',
      'Laboratory and teaching circuits',
    ],
    faq: [
      {
        q: 'What is the AD633JRZ-RL used for?',
        a: 'It multiplies two analogue signals in hardware, which is how designers build '
          + 'instantaneous power measurement, voltage-controlled gain and amplitude modulation '
          + 'without moving the signal into the digital domain. It also works as a divider by '
          + 'placing it inside an op-amp feedback loop. Typical users are instrument designers, '
          + 'power-metering engineers, AGC stages and university laboratories.',
      },
      {
        q: 'What do buyers check before ordering an AD633JRZ-RL?',
        a: 'The grade is the first thing to confirm, because the J suffix is the commercial '
          + '0 \u00b0C to +70 \u00b0C part and an industrial design needs the A, B or S grade '
          + 'instead. Buyers then check the roughly 2 % total error against their accuracy '
          + 'budget and its drift over temperature, confirm the board can supply a bipolar rail, '
          + 'and compare against the AD834 and AD835 multipliers, which differ in bandwidth and '
          + 'output configuration.',
      },
      {
        q: 'How does YIXINOU check an AD633JRZ-RL before it ships?',
        a: 'Incoming inspection at our Shenzhen facility checks the SOIC-8 lead coplanarity and '
          + 'body finish, verifies the laser marking and date code format against what Analog '
          + 'Devices prints on this family, and confirms the reel and factory labelling. '
          + 'Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical '
          + 'testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate '
          + 'its own testing laboratory. Ask us and we will state which checks were performed on '
          + 'your lot.',
      },
    ],
  },
  'AD780BRZ-REEL7': {
    mpn: 'AD780BRZ-REEL7',
    brand: 'Analog Devices',
    title: '2.5 V / 3.0 V high-precision voltage reference',
    category: 'Integrated Circuits (ICS) / Power Management ICs / Voltage References',
    categoryHref: '/all-products',
    summary:
      'The AD780BRZ-REEL7 is a high-precision series voltage reference from Analog Devices, '
      + 'supplied in an 8-lead SOIC package on tape and reel. It delivers either 2.5 V or 3.0 V '
      + 'from a pin-selectable output, with initial accuracy of +/-1 mV maximum and 3 ppm/\u00b0C '
      + 'temperature drift in the B grade. Input range is 4 V to 36 V and the output can source '
      + 'or sink up to +/-10 mA. Low-frequency noise is 4 uV p-p from 0.1 Hz to 10 Hz, and the '
      + 'part is specified from -40 \u00b0C to +85 \u00b0C.',
    img: '/assets/images/ad780brz-reel7-soic-8.jpg',
    alt: 'An 8-lead SOIC AD780B voltage reference with its lot and date code visible',
    imageNote:
      'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a '
      + 'photograph of the actual lot.',
    specs: [
      ['Output voltage', '2.5 V or 3.0 V (pin-selectable)'],
      ['Initial accuracy', '+/-1 mV max'],
      ['Temperature drift', '3 ppm/\u00b0C (B grade)'],
      ['Input voltage', '4 V to 36 V'],
      ['Output current', '+/-10 mA'],
      ['Low-frequency noise', '4 uV p-p (0.1 Hz to 10 Hz)'],
      ['Supply current', 'Low power, series mode'],
      ['Package', '8-lead SOIC (R-8)'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C'],
      ['Packaging', 'Tape and reel (REEL7)'],
    ],
    about:
      'The AD780 is one of the reference benchmarks designers reach for when an ADC or DAC '
      + 'budget has to hold over temperature. The B grade used in this part number is the '
      + 'tight-drift option: 3 ppm/\u00b0C with a +/-1 mV initial error, which is what lets a '
      + '16-bit converter keep its last bits meaningful. The output is pin-programmable between '
      + '2.5 V and 3.0 V, so one part number covers both common system rails, and the wide 4 V '
      + 'to 36 V input means it can run directly from an unregulated rail. It is normally '
      + 'specified alongside precision data acquisition, instrumentation and calibration '
      + 'hardware rather than in general-purpose power design.',
    standards: [
      'Analog Devices AD780 datasheet Rev. K',
      'RoHS and REACH compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Pin-selectable 2.5 V or 3.0 V output',
      '+/-1 mV maximum initial accuracy',
      '3 ppm/\u00b0C temperature drift (B grade)',
      '4 uV p-p low-frequency noise',
      '+/-10 mA output drive',
      '4 V to 36 V input range',
      '8-lead SOIC package',
      '-40 \u00b0C to +85 \u00b0C operation',
    ],
    applications: [
      'Reference for precision ADC and DAC systems',
      'Test and measurement instruments',
      'Medical equipment',
      'Data acquisition systems',
      'Industrial measurement and calibration',
    ],
    faq: [
      {
        q: 'What is the AD780BRZ-REEL7 used for?',
        a: 'It supplies the stable reference voltage that a precision converter measures '
          + 'against, which makes it a direct contributor to system accuracy. It appears in '
          + 'instrumentation, medical devices, data acquisition front ends and calibration '
          + 'equipment where the last few bits of a 14- or 16-bit converter have to stay '
          + 'meaningful over temperature.',
      },
      {
        q: 'What do buyers check before ordering an AD780BRZ-REEL7?',
        a: 'Grade and drift come first: the B grade in this part number carries 3 ppm/\u00b0C, '
          + 'while the A and C grades trade accuracy for cost, so buying the wrong suffix is the '
          + 'usual mistake. Buyers then check how the 2.5 V / 3.0 V selection pin is wired on '
          + 'their board, the load regulation and decoupling requirements, and whether the '
          + 'reference drift still leaves headroom once the converter error budget is combined '
          + 'with it.',
      },
      {
        q: 'How does YIXINOU check an AD780BRZ-REEL7 before it ships?',
        a: 'Incoming inspection at our Shenzhen facility checks lead coplanarity and body '
          + 'marking on the SOIC-8 package, verifies the lot and date code format, and confirms '
          + 'that the reel and factory labels match the part number ordered. Laboratory '
          + 'analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing '
          + '\u2014 is carried out by our partner laboratories; YIXINOU does not operate its own '
          + 'testing laboratory. Ask us and we will tell you which checks were run on your lot.',
      },
    ],
  },
  'AD7928BRUZ-REEL7': {
    mpn: 'AD7928BRUZ-REEL7',
    brand: 'Analog Devices',
    title: '8-channel 12-bit 1 MSPS SAR ADC',
    category: 'Integrated Circuits (ICS) / Data Converters / Analog to Digital Converters (ADC)',
    categoryHref: '/all-products',
    summary:
      'The AD7928BRUZ-REEL7 is an 8-channel, 12-bit successive-approximation ADC from Analog '
      + 'Devices in a 20-lead TSSOP package on tape and reel. It converts at up to 1 MSPS with '
      + 'a 70 dB minimum signal-to-noise ratio and talks over a serial interface compatible '
      + 'with SPI, QSPI, MICROWIRE and DSP ports. Each input spans 0 V to the reference, and '
      + 'the part offers an internal 2.5 V reference option or accepts an external one. Supply '
      + 'range is 2.7 V to 5.25 V and it is specified from -40 \u00b0C to +85 \u00b0C.',
    img: '/assets/images/ad7928bruz-reel7-tssop-20.jpg',
    alt: 'A 20-lead TSSOP AD7928 8-channel 12-bit ADC with its date code visible',
    imageNote:
      'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a '
      + 'photograph of the actual lot.',
    specs: [
      ['Resolution', '12 bit'],
      ['Analog input channels', '8'],
      ['Throughput rate', '1 MSPS'],
      ['Signal-to-noise ratio', '70 dB min'],
      ['Interface', 'SPI / QSPI / MICROWIRE / DSP compatible serial'],
      ['Reference', 'Internal 2.5 V option or external'],
      ['Analog input range', '0 V to VREF'],
      ['Supply voltage', '2.7 V to 5.25 V'],
      ['Package', '20-lead TSSOP (BRUZ)'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C'],
    ],
    about:
      'The AD7928 packs eight analogue inputs and an on-chip sequencer into a 20-lead TSSOP, '
      + 'which is the point of the part: a design that would otherwise need a multiplexer plus a '
      + 'single-channel converter gets one device and one serial interface. The sequencer walks '
      + 'the channels without host intervention, so a slow microcontroller can still scan eight '
      + 'sensors at 1 MSPS aggregate. The internal 2.5 V reference suits compact designs, while '
      + 'an external reference is the way to go when the accuracy budget demands better drift '
      + 'than the internal one offers. It is common in industrial control, multi-channel data '
      + 'acquisition and power monitoring.',
    standards: [
      'Analog Devices AD7908/AD7918/AD7928 datasheet Rev. E',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '8 analogue input channels with on-chip sequencer',
      '12-bit resolution at 1 MSPS',
      '70 dB minimum SNR',
      'Serial interface compatible with SPI, QSPI, MICROWIRE and DSP',
      'Internal 2.5 V reference option, external reference supported',
      '0 V to VREF analogue input span',
      '2.7 V to 5.25 V single supply',
      '20-lead TSSOP package',
    ],
    applications: [
      'Industrial process control',
      'Multi-channel data acquisition',
      'Test and measurement instruments',
      'Power monitoring',
      'Medical and portable equipment',
    ],
    faq: [
      {
        q: 'What is the AD7928BRUZ-REEL7 used for?',
        a: 'It reads eight analogue signals at once and hands them to a processor over a serial '
          + 'bus, which is why it shows up in industrial control racks, multi-channel data '
          + 'acquisition cards, power monitoring and portable instruments. It is the right '
          + 'choice when the channel count, not raw resolution, is what the design is short of.',
      },
      {
        q: 'What do buyers check before ordering an AD7928BRUZ-REEL7?',
        a: 'Channel count is the first filter, because the AD7927 and AD7908 in the same family '
          + 'have different numbers of inputs and a buyer who needs six channels should not pay '
          + 'for eight. After that the checks are the SPI clock rate against the 1 MSPS '
          + 'throughput, the input range and the protection circuitry in front of it, whether '
          + 'the internal reference is accurate enough or an external one is required, and how '
          + 'much crosstalk the layout allows between adjacent channels.',
      },
      {
        q: 'How does YIXINOU check an AD7928BRUZ-REEL7 before it ships?',
        a: 'Incoming inspection at our Shenzhen facility checks the TSSOP-20 lead coplanarity '
          + 'and body condition, verifies the laser marking and date code against the expected '
          + 'Analog Devices format, and confirms the reel and factory labelling. Laboratory '
          + 'analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing '
          + '\u2014 is carried out by our partner laboratories; YIXINOU does not operate its own '
          + 'testing laboratory. Tell us what needs proving and we will report exactly which '
          + 'checks were done.',
      },
    ],
  },
  'AD8009ARZ-REEL7': {
    mpn: 'AD8009ARZ-REEL7',
    brand: 'Analog Devices',
    title: '1 GHz current-feedback operational amplifier',
    category: 'Integrated Circuits (ICS) / Linear ICs / High-Speed Operational Amplifiers',
    categoryHref: '/all-products',
    summary:
      'The AD8009ARZ-REEL7 is a current-feedback operational amplifier from Analog Devices in '
      + 'an 8-lead SOIC package on tape and reel. It delivers 1 GHz bandwidth at unity gain, a '
      + '5500 V/us slew rate and 545 ps rise time, with -78 dBc distortion at 5 MHz and 110 mA '
      + 'output drive. It runs from a +/-5 V supply and is specified from -40 \u00b0C to '
      + '+85 \u00b0C. Because it is a current-feedback topology, the feedback resistor value '
      + 'sets the bandwidth and has to follow the datasheet recommendation.',
    img: '/assets/images/ad8009arz-reel7-soic-8.jpg',
    alt: 'An 8-lead SOIC package, the package used for the AD8009ARZ-REEL7 high-speed amplifier',
    imageNote: 'Illustrative package image. Ask us for a photograph of the actual lot.',
    specs: [
      ['Amplifier type', 'Current feedback'],
      ['Bandwidth', '1 GHz (G = +1)'],
      ['Slew rate', '5500 V/us'],
      ['Rise time', '545 ps'],
      ['Distortion', '-78 dBc at 5 MHz'],
      ['Output current', '110 mA'],
      ['Supply voltage', '+/-5 V'],
      ['Package', '8-lead SOIC (ARZ)'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C'],
      ['Packaging', 'Tape and reel (REEL7)'],
    ],
    about:
      'The AD8009 is a current-feedback amplifier built for the analogue front end of fast '
      + 'systems: driving high-speed ADCs, buffering video and pulse signals, and shaping the '
      + 'return path in instruments. Current feedback gives it a bandwidth that stays wide as '
      + 'gain rises, at the cost of a design constraint that catches people out \u2014 the '
      + 'feedback resistor sets the bandwidth and stability, so it must follow the datasheet '
      + 'value rather than the arbitrary resistor a voltage-feedback design would use. It also '
      + 'asks for a tightly laid-out board with controlled impedance, since at 1 GHz the '
      + 'layout is part of the circuit.',
    standards: [
      'Analog Devices AD8009 datasheet Rev. F',
      'RoHS compliant, lead-free (GREEN) construction',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '1 GHz bandwidth at unity gain',
      '5500 V/us slew rate and 545 ps rise time',
      '-78 dBc distortion at 5 MHz',
      '110 mA output current drive',
      'Current-feedback topology with gain-independent bandwidth',
      '+/-5 V supply',
      '8-lead SOIC package',
      '-40 \u00b0C to +85 \u00b0C operation',
    ],
    applications: [
      'Video signal chains',
      'High-speed ADC drivers',
      'Pulse and laser diode drivers',
      'Oscilloscope front ends',
      'Radar and ultrasound front ends',
    ],
    faq: [
      {
        q: 'What is the AD8009ARZ-REEL7 used for?',
        a: 'It drives and buffers fast analogue signals: feeding high-speed ADCs, handling video '
          + 'and pulse paths, and acting as the front end in oscilloscopes, radar and ultrasound '
          + 'designs. It is selected when bandwidth and slew rate matter more than the '
          + 'convenience of a voltage-feedback part.',
      },
      {
        q: 'What do buyers check before ordering an AD8009ARZ-REEL7?',
        a: 'The critical check is that the board was designed for current feedback, because the '
          + 'feedback resistor value fixes the bandwidth and using a voltage-feedback layout '
          + 'will produce an unstable or slow circuit. Buyers also weigh the PCB layout and '
          + 'impedance control the 1 GHz bandwidth demands, the power dissipation and thermal '
          + 'path, and how the part compares with the AD8001 and AD8003 for channel count and '
          + 'supply.',
      },
      {
        q: 'How does YIXINOU check an AD8009ARZ-REEL7 before it ships?',
        a: 'Incoming inspection at our Shenzhen facility checks SOIC-8 lead coplanarity and body '
          + 'marking, verifies the date code format, and confirms the reel and factory labels. '
          + 'Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical '
          + 'testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate '
          + 'its own testing laboratory. Ask us and we will state plainly what was checked on '
          + 'your lot.',
      },
    ],
  },
  'AD8170ARZ': {
    mpn: 'AD8170ARZ',
    brand: 'Analog Devices',
    title: '250 MHz 2:1 video multiplexer with output amplifier',
    category: 'Integrated Circuits (ICS) / Analog Switches and Multiplexers / Video Multiplexers',
    categoryHref: '/all-products',
    summary:
      'The AD8170ARZ is a 2:1 analogue multiplexer with a built-in output amplifier from Analog '
      + 'Devices, supplied in an 8-lead SOIC package. It switches between two inputs in 10 ns '
      + 'and provides 250 MHz bandwidth at a gain of +2, with 1000 V/us slew rate, -78 dB '
      + 'crosstalk at 5 MHz and 0.01 % differential gain and 0.01 degree differential phase. '
      + 'It runs from a +/-5 V supply, drives a back-terminated video load directly, and the '
      + 'ARZ grade is the commercial temperature version.',
    img: '/assets/images/ad8170arz-soic-8.jpg',
    alt: 'An 8-lead SOIC AD8170 2:1 video multiplexer with its marking visible',
    imageNote:
      'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a '
      + 'photograph of the actual lot.',
    specs: [
      ['Function', '2:1 analogue multiplexer with output amplifier'],
      ['Bandwidth', '250 MHz (G = +2)'],
      ['Switching time', '10 ns'],
      ['Slew rate', '1000 V/us'],
      ['Crosstalk', '-78 dB at 5 MHz'],
      ['Differential gain / phase', '0.01 % / 0.01 degree'],
      ['Supply voltage', '+/-5 V'],
      ['Package', '8-lead SOIC (ARZ)'],
      ['Operating temperature', '0 \u00b0C to +70 \u00b0C (commercial grade)'],
      ['Output drive', 'Drives back-terminated video loads directly'],
    ],
    about:
      'The AD8170 puts the switch and the cable driver in one package, which removes the usual '
      + 'discrete multiplexer-plus-buffer pair from a video signal path. That matters because '
      + 'the buffered output can drive a back-terminated 75 ohm video load directly, and the '
      + '0.01 % differential gain and 0.01 degree differential phase figures are what keep '
      + 'composite and RGB video clean through the switch. The ARZ grade in this part number is '
      + 'the commercial temperature version, so benchtop and indoor equipment is the natural '
      + 'fit; designs that must hold specification across a wider range need a different grade.',
    standards: [
      'Analog Devices AD8170/AD8174 datasheet Rev. 0',
      'RoHS compliant, green package construction',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '2:1 multiplexer with integrated output amplifier',
      '250 MHz bandwidth at gain of +2',
      '10 ns switching time',
      '1000 V/us slew rate',
      '-78 dB crosstalk at 5 MHz',
      '0.01 % differential gain, 0.01 degree differential phase',
      'Drives back-terminated video loads directly',
      '8-lead SOIC package',
    ],
    applications: [
      'Composite and RGB video signal switching',
      'Broadcast and surveillance equipment',
      'Image capture systems',
      'Industrial camera input selection',
    ],
    faq: [
      {
        q: 'What is the AD8170ARZ used for?',
        a: 'It selects between two video or analogue signal sources and drives the result down '
          + 'a cable, so it appears in surveillance and broadcast equipment, image capture '
          + 'boards and industrial cameras where an input has to be routed without degrading '
          + 'the picture.',
      },
      {
        q: 'What do buyers check before ordering an AD8170ARZ?',
        a: 'The first check is whether 250 MHz is enough for the resolution and format being '
          + 'routed, since high-definition paths can need more. Buyers then confirm the input '
          + 'impedance and 75 ohm termination arrangement, note that this ARZ part is the '
          + 'commercial temperature grade, and compare against the AD8174 and AD8180, which '
          + 'offer different numbers of inputs.',
      },
      {
        q: 'How does YIXINOU check an AD8170ARZ before it ships?',
        a: 'Incoming inspection at our Shenzhen facility checks the SOIC-8 lead coplanarity and '
          + 'marking, verifies the date code, and confirms the original factory packaging. '
          + 'Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical '
          + 'testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate '
          + 'its own testing laboratory. Tell us what your build needs verified and we will '
          + 'report which checks were performed.',
      },
    ],
  },
  'AD8304ARUZ-RL7': {
    mpn: 'AD8304ARUZ-RL7',
    brand: 'Analog Devices',
    title: '160 dB logarithmic amplifier with photodiode interface',
    category: 'Integrated Circuits (ICS) / Linear ICs / Logarithmic Amplifiers',
    categoryHref: '/all-products',
    summary:
      'The AD8304ARUZ-RL7 is a 160 dB logarithmic amplifier from Analog Devices in a 14-lead '
      + 'TSSOP package on tape and reel. It converts an input current from 100 pA to 10 mA '
      + '\u2014 eight decades \u2014 into a logged voltage at a 10 mV/dB slope, with 10 MHz '
      + 'bandwidth and 15 V/us slew rate. A 10-bit on-chip monitor interface reports the '
      + 'measured level digitally. It runs from a 3.0 V to 5.5 V supply and is specified from '
      + '-40 \u00b0C to +85 \u00b0C.',
    img: '/assets/images/ad8304aruz-rl7-tssop-14.jpg',
    alt: 'A 14-lead TSSOP AD8304 logarithmic amplifier with its date code visible',
    imageNote:
      'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a '
      + 'photograph of the actual lot.',
    specs: [
      ['Dynamic range', '160 dB'],
      ['Input current range', '100 pA to 10 mA (8 decades)'],
      ['Logarithmic slope', '10 mV/dB'],
      ['Bandwidth', '10 MHz'],
      ['Slew rate', '15 V/us'],
      ['On-chip monitor', '10-bit ADC interface'],
      ['Supply voltage', '3.0 V to 5.5 V'],
      ['Package', '14-lead TSSOP (ARUZ)'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C'],
      ['Packaging', 'Tape and reel (RL7)'],
    ],
    about:
      'The AD8304 exists because optical power spans too many decades for a linear amplifier '
      + 'to cover. It takes the current from a photodiode and produces a voltage proportional '
      + 'to the logarithm of that current, so a single part reads from 100 pA to 10 mA without '
      + 'range switching. That is the measurement behind received-signal-strength indication in '
      + 'fibre receivers, optical power meters and OTDR instruments. Because the input is a '
      + 'current, the design has to confirm the photodiode current range and the bias '
      + 'arrangement, then calibrate log slope and intercept for the specific diode.',
    standards: [
      'Analog Devices AD8304 datasheet Rev. A',
      'RoHS and REACH compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '160 dB dynamic range',
      'Input current 100 pA to 10 mA across eight decades',
      '10 mV/dB logarithmic slope',
      '10 MHz bandwidth, 15 V/us slew rate',
      '10-bit on-chip monitor ADC interface',
      'Designed for direct photodiode current input',
      '3.0 V to 5.5 V supply',
      '14-lead TSSOP package',
    ],
    applications: [
      'Fibre-optic receiver signal strength indication (RSSI)',
      'Optical power meters',
      'Optical time-domain reflectometers (OTDR)',
      'Photodiode detection and laser control loops',
    ],
    faq: [
      {
        q: 'What is the AD8304ARUZ-RL7 used for?',
        a: 'It measures optical or photodiode current over eight decades and turns it into a '
          + 'logged voltage, which is what optical receivers use for received-signal-strength '
          + 'indication. The same measurement appears in optical power meters, OTDR instruments '
          + 'and laser control loops that have to hold power constant as the diode ages.',
      },
      {
        q: 'What do buyers check before ordering an AD8304ARUZ-RL7?',
        a: 'Because the input is a current, the first check is that the photodiode current '
          + 'range sits inside 100 pA to 10 mA for the application. Buyers then work through the '
          + 'log slope and intercept calibration for their specific diode, the reference and '
          + 'temperature drift compensation the accuracy budget allows, and how the part '
          + 'compares with the AD8305 and ADL5303, which differ in bandwidth, package and cost.',
      },
      {
        q: 'How does YIXINOU check an AD8304ARUZ-RL7 before it ships?',
        a: 'Incoming inspection at our Shenzhen facility checks the TSSOP-14 lead coplanarity '
          + 'and body marking, verifies the lot and date code, and confirms the reel and factory '
          + 'labelling. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and '
          + 'electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does '
          + 'not operate its own testing laboratory. Ask us and we will tell you which checks '
          + 'were run.',
      },
    ],
  },
  'AD9365BBCZ': {
    mpn: 'AD9365BBCZ',
    brand: 'Analog Devices',
    title: '1 x 1 RF agile transceiver, 75 MHz to 6.0 GHz',
    category: 'Integrated Circuits (ICS) / RF and Microwave / RF Agile Transceivers',
    categoryHref: '/all-products',
    summary:
      'The AD9365BBCZ is a single-channel RF agile transceiver from Analog Devices: one '
      + 'transmit and one receive channel covering 75 MHz to 6.0 GHz with channel bandwidth '
      + 'from 200 kHz to 56 MHz. It comes in a 144-ball CSP_BGA measuring 10 mm by 10 mm and is '
      + 'specified from -40 \u00b0C to +85 \u00b0C. It is the 1T1R member of the AD936x family, '
      + 'so a design that needs more channels steps up to the AD9361, AD9363 or AD9364 instead.',
    img: '/assets/images/ad9365bbcz-csp-bga-144.jpg',
    alt: 'A 144-ball CSP_BGA package, the package used for the AD9365BBCZ RF transceiver',
    imageNote: 'Illustrative package image. Ask us for a photograph of the actual lot.',
    specs: [
      ['Function', '1 x 1 RF agile transceiver'],
      ['Transmit channels', '1'],
      ['Receive channels', '1'],
      ['Frequency range', '75 MHz to 6.0 GHz'],
      ['Channel bandwidth', '200 kHz to 56 MHz'],
      ['Package', '144-ball CSP_BGA, 10 mm x 10 mm'],
      ['Mount', 'Surface mount'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C'],
      ['Series', 'AD936x'],
      ['RoHS', 'Compliant'],
    ],
    about:
      'The AD9365 puts a complete RF front end on one die: transmitter, receiver, mixers, '
      + 'filters and data converters, with the frequency and bandwidth set in software. That '
      + 'software-defined agility is why the family underpins software-defined radio, private '
      + 'and trunked radio systems, UAV data links, small cells and industrial wireless. The '
      + 'trade-off is integration effort: the digital interface is normally driven by an FPGA, '
      + 'the multiple supply rails have a defined power-up sequence, and the RF front-end '
      + 'module and filtering are still the designer responsibility.',
    standards: [
      'Analog Devices AD936x family documentation',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Single transmit and single receive channel (1T1R)',
      '75 MHz to 6.0 GHz tuning range',
      '200 kHz to 56 MHz channel bandwidth',
      'Integrated RF front end with data converters',
      'Software-configurable frequency and bandwidth',
      '144-ball CSP_BGA, 10 mm x 10 mm',
      '-40 \u00b0C to +85 \u00b0C operation',
      'Digital baseband interface for FPGA connection',
    ],
    applications: [
      'Software-defined radio (SDR)',
      'Private and trunked radio systems',
      'UAV data links',
      'Small cells',
      'Test and measurement',
      'Industrial wireless',
    ],
    faq: [
      {
        q: 'What is the AD9365BBCZ used for?',
        a: 'It is the RF engine in software-defined radios: software sets the frequency and '
          + 'bandwidth, so one hardware design can serve private and trunked radio, UAV data '
          + 'links, small cells and industrial wireless. Designers pick it when they need '
          + 'agility across a wide tuning range rather than a fixed-band transceiver.',
      },
      {
        q: 'What do buyers check before ordering an AD9365BBCZ?',
        a: 'The family position matters first, because the AD9365 is the 1T1R part and the '
          + 'AD9361, AD9363 and AD9364 differ in channel count and frequency coverage. Buyers '
          + 'then confirm the RF front-end module and filter design is in place, that an FPGA '
          + 'or equivalent is available to drive the digital interface, and that the board '
          + 'sequence the multiple supply rails correctly. Because RF parts attract '
          + 'counterfeits, buyers also ask for evidence the material is original and check what '
          + 'lead time and price exposure to expect.',
      },
      {
        q: 'How does YIXINOU check an AD9365BBCZ before it ships?',
        a: 'Incoming inspection at our Shenzhen facility checks the 144-ball BGA for ball '
          + 'coplanarity and body condition, verifies the laser marking and date code, and '
          + 'confirms the factory packaging and dry-pack condition that a BGA requires. '
          + 'Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical '
          + 'testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate '
          + 'its own testing laboratory. RF parts attract counterfeits, so ask us and we will '
          + 'state exactly what was verified on your lot.',
      },
    ],
  },
  'AD9524BCPZ': {
    mpn: 'AD9524BCPZ',
    brand: 'Analog Devices',
    title: 'Low-jitter clock generator with on-chip PLL and VCO',
    category: 'Integrated Circuits (ICS) / Clock and Timing / Clock Generators',
    categoryHref: '/all-products',
    summary:
      'The AD9524BCPZ is a low-jitter clock generator from Analog Devices in a 48-lead LFCSP '
      + 'package measuring 7 mm by 7 mm. It integrates a PLL and a 3.6 GHz to 4.0 GHz VCO, '
      + 'produces outputs from below 1 MHz up to 1 GHz across up to 14 outputs with LVPECL, '
      + 'LVDS or CMOS levels, and holds RMS jitter below 200 fs. On-chip EEPROM stores the '
      + 'configuration, supply range is 1.71 V to 3.465 V, and it is specified from -40 \u00b0C '
      + 'to +85 \u00b0C.',
    img: '/assets/images/ad9524bcpz-lfcsp-48.jpg',
    alt: 'A 48-lead LFCSP package with exposed pad, the package used for the AD9524BCPZ clock generator',
    imageNote: 'Illustrative package image. Ask us for a photograph of the actual lot.',
    specs: [
      ['Function', 'Clock generator with on-chip PLL and VCO'],
      ['Output frequency', 'Below 1 MHz to 1 GHz'],
      ['On-chip VCO', '3.6 GHz to 4.0 GHz'],
      ['Number of outputs', 'Up to 14 (LVPECL / LVDS / CMOS selectable)'],
      ['RMS jitter', 'Below 200 fs'],
      ['Configuration storage', 'On-chip EEPROM'],
      ['Supply voltage', '1.71 V to 3.465 V'],
      ['Package', '48-lead LFCSP, 7 mm x 7 mm (BCPZ)'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C'],
      ['Control interface', 'Serial and parallel control ports'],
    ],
    about:
      'Clock quality sets the ceiling on a converter or serialiser: the AD9524 exists to '
      + 'produce several low-jitter outputs from one reference so an entire board locks to the '
      + 'same time base. With RMS jitter below 200 fs and up to 14 outputs it is used to clock '
      + 'high-speed ADC and DAC arrays, drive SerDes reference clocks in data centres, and '
      + 'provide the timing spine of base stations and test instruments. Two practical cautions '
      + 'belong in any design review: the output and frequency plan normally needs the '
      + 'manufacturer evaluation software rather than guesswork, and a clock part is only as '
      + 'quiet as its supply, so the LFCSP thermal pad and supply filtering are part of the '
      + 'circuit, not layout detail.',
    standards: [
      'Analog Devices AD9524 datasheet Rev. D',
      'JEDEC package and thermal-characterisation requirements (JESD51)',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Integrated PLL with 3.6 GHz to 4.0 GHz on-chip VCO',
      'Outputs from below 1 MHz to 1 GHz',
      'Up to 14 outputs in LVPECL, LVDS or CMOS',
      'RMS jitter below 200 fs',
      'On-chip EEPROM for stored configuration',
      '1.71 V to 3.465 V supply',
      '48-lead LFCSP with exposed thermal pad',
      '-40 \u00b0C to +85 \u00b0C operation',
    ],
    applications: [
      'Communications base stations',
      'Software-defined radio',
      'High-speed ADC and DAC sampling clocks',
      'Test and measurement instruments',
      'Data centre and high-speed SerDes reference clocks',
    ],
    faq: [
      {
        q: 'What is the AD9524BCPZ used for?',
        a: 'It generates the low-jitter clock tree for a board: several synchronised outputs '
          + 'from one reference, at jitter low enough for high-speed converters and serialisers. '
          + 'It clocks ADC and DAC arrays in instruments and radio hardware, drives SerDes '
          + 'reference clocks in data centres, and forms the timing spine of base stations.',
      },
      {
        q: 'What do buyers check before ordering an AD9524BCPZ?',
        a: 'The output count and frequency plan come first, and in practice that means using '
          + 'the manufacturer evaluation software rather than working it out by hand. Buyers '
          + 'then verify the phase noise and jitter figures against their own measurements, '
          + 'confirm whether SYSREF and deterministic delay are needed for a JESD204B link, and '
          + 'review LFCSP thermal relief and supply filtering, because a clock part is only as '
          + 'quiet as the rail feeding it.',
      },
      {
        q: 'How does YIXINOU check an AD9524BCPZ before it ships?',
        a: 'Incoming inspection at our Shenzhen facility checks the 48-lead LFCSP for terminal '
          + 'coplanarity and exposed-pad condition, verifies the laser marking and date code, '
          + 'and confirms the tray or factory packaging. Laboratory analysis \u2014 X-ray, XRF, '
          + 'decapsulation, solderability and electrical testing \u2014 is carried out by our '
          + 'partner laboratories; YIXINOU does not operate its own testing laboratory. Ask us '
          + 'and we will say precisely which checks your lot received.',
      },
    ],
  },
  'ADL5303ACPZ-R7': {
    mpn: 'ADL5303ACPZ-R7',
    brand: 'Analog Devices',
    title: '160 dB logarithmic converter, 100 pA to 10 mA',
    category: 'Integrated Circuits (ICS) / Linear ICs / Logarithmic Amplifiers',
    categoryHref: '/all-products',
    summary:
      'The ADL5303ACPZ-R7 is a 160 dB logarithmic converter from Analog Devices in a 16-lead '
      + 'LFCSP package measuring 3 mm by 3 mm, supplied on tape and reel. It accepts input '
      + 'current from 100 pA to 10 mA and produces a logged output at a 10 mV/dB slope, holding '
      + 'log conformance to within +/-0.25 dB between 100 nA and 1 mA. Bandwidth is 10 MHz with '
      + 'a 15 V/us slew rate, the photodiode bias is programmable, and it runs from a 3.0 V to '
      + '5.5 V supply over -40 \u00b0C to +85 \u00b0C.',
    img: '/assets/images/adl5303acpz-r7-lfcsp-16.jpg',
    alt: 'A 16-lead LFCSP ADL5303 logarithmic converter with its marking visible',
    imageNote:
      'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a '
      + 'photograph of the actual lot.',
    specs: [
      ['Dynamic range', '160 dB'],
      ['Input current range', '100 pA to 10 mA'],
      ['Logarithmic slope', '10 mV/dB'],
      ['Log conformance error', '+/-0.25 dB (100 nA to 1 mA)'],
      ['Bandwidth', '10 MHz'],
      ['Slew rate', '15 V/us'],
      ['Photodiode bias', 'Programmable'],
      ['Supply voltage', '3.0 V to 5.5 V'],
      ['Package', '16-lead LFCSP, 3 mm x 3 mm (ACPZ)'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C'],
    ],
    about:
      'The ADL5303 is the compact member of the Analog Devices logarithmic converter family: '
      + 'a 3 mm by 3 mm part that turns eight decades of input current into a logged voltage. It '
      + 'is used wherever optical or photodiode current has to be measured over a wide range '
      + 'without range switching \u2014 received-signal-strength indication in fibre receivers, '
      + 'optical power meters, photodiode signal conditioning, laser control loops and general '
      + 'instrumentation. Compared with the AD8304 it trades package size and bandwidth for '
      + 'cost, which is the selection decision most buyers are actually making.',
    standards: [
      'Analog Devices ADL5303 datasheet Rev. 0',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '160 dB dynamic range',
      'Input current 100 pA to 10 mA',
      '+/-0.25 dB log conformance from 100 nA to 1 mA',
      '10 mV/dB logarithmic slope',
      '10 MHz bandwidth, 15 V/us slew rate',
      'Programmable photodiode bias',
      '3.0 V to 5.5 V supply',
      '16-lead LFCSP, 3 mm x 3 mm',
    ],
    applications: [
      'Fibre-optic receiver RSSI',
      'Optical power meters',
      'Photodiode signal conditioning',
      'Laser control loops',
      'Test and measurement instruments',
    ],
    faq: [
      {
        q: 'What is the ADL5303ACPZ-R7 used for?',
        a: 'It converts photodiode or optical current spanning eight decades into a logged '
          + 'voltage, which is how fibre receivers report received signal strength and how '
          + 'optical power meters and laser control loops measure light without switching '
          + 'ranges.',
      },
      {
        q: 'What do buyers check before ordering an ADL5303ACPZ-R7?',
        a: 'The usual first question is whether to use this part or the AD8304, since the '
          + 'ADL5303 is smaller and lower cost while the AD8304 differs in bandwidth and '
          + 'package. Buyers then confirm the photodiode dark current and bias requirements, '
          + 'the log calibration and temperature compensation the accuracy budget needs, and '
          + 'that the board can provide the LFCSP thermal pad and the low-noise rail the '
          + 'measurement depends on.',
      },
      {
        q: 'How does YIXINOU check an ADL5303ACPZ-R7 before it ships?',
        a: 'Incoming inspection at our Shenzhen facility checks the 16-lead LFCSP terminal '
          + 'coplanarity and body marking, verifies the date code and lot, and confirms the '
          + 'reel and factory labelling. Laboratory analysis \u2014 X-ray, XRF, decapsulation, '
          + 'solderability and electrical testing \u2014 is carried out by our partner '
          + 'laboratories; YIXINOU does not operate its own testing laboratory. Ask us and we '
          + 'will tell you exactly which checks were performed.',
      },
    ],
  },
  'ADM1278-1ACPZ-RL': {
    mpn: 'ADM1278-1ACPZ-RL',
    brand: 'Analog Devices',
    title: 'Hot swap controller with PMBus digital power and energy monitoring in a 32-lead LFCSP',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Power Management ICs / Hot Swap Controllers',
    categoryHref: '/all-products',
    summary: 'The ADM1278-1ACPZ-RL is a hot swap controller from Analog Devices that adds PMBus digital power and energy monitoring on the same die. It accepts a wide input of up to 20 V and uses a built-in 12-bit ADC to report current, voltage, power and energy at 1% accuracy. The PMBus 1.2 compatible interface lets a host controller configure the device and read telemetry. It is supplied in a 32-lead LFCSP measuring 5 x 5 x 0.75 mm (ACPZ). Typical uses are hot swap power in servers, storage systems, blade servers and communications equipment, and the Analog Devices lifecycle status is EOL / NRND, so availability must be confirmed before design-in.',
    img: '/assets/images/adm1278-1acpz-rl-lfcsp-32.jpg',
    alt: 'A 32-lead LFCSP package, the package used for the ADM1278-1ACPZ-RL',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'LFCSP, 32-lead, 5 x 5 x 0.75 mm (ACPZ)'],
      ['Number of pins', '32'],
      ['Mounting type', 'Surface mount'],
      ['Number of channels', '1'],
      ['Supply voltage range', '4.5 V to 20 V'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C'],
      ['Interface', 'PMBus 1.2 compatible'],
      ['Monitoring accuracy', '1% for current, voltage, power and energy, 12-bit ADC'],
      ['Packaging', 'Tape and reel'],
      ['Lifecycle status', 'EOL / NRND \u2014 confirm availability before ordering'],
    ],
    about: 'The ADM1278-1ACPZ-RL is a single-channel hot swap controller from Analog Devices with an integrated digital power and energy monitor. A built-in 12-bit ADC samples current, voltage, power and energy and reports them over a PMBus 1.2 compatible interface, while the controller manages the external MOSFET. Input voltage can reach 20 V and the part operates from -40 \u00b0C to +85 \u00b0C. It is supplied as a 32-lead LFCSP measuring 5 x 5 x 0.75 mm (ACPZ). It is used for hot swap and power monitoring in servers, storage systems, communications equipment and data centre racks.',
    standards: [
      'Analog Devices ADM1278 datasheet Rev. C',
      'RoHS compliant',
      'JEDEC package and ESD standards',
      'REACH compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Single-channel hot swap controller with an integrated PMBus interface',
      'Wide input voltage of up to 20 V',
      'Built-in 12-bit ADC for current, voltage, power and energy',
      '1% monitoring accuracy across current, voltage, power and energy',
      'PMBus 1.2 compatible digital interface',
      '32-lead LFCSP measuring 5 x 5 x 0.75 mm (ACPZ)',
      'Operating range of -40 \u00b0C to +85 \u00b0C',
      'Supplied on tape and reel for automated assembly',
    ],
    applications: [
      'Server hot swap power rails',
      'Storage system hot swap supplies',
      'Communications equipment',
      'Blade servers',
      'Data centre power management',
    ],
    faq: [
      {
        q: 'What is the ADM1278-1ACPZ-RL used for?',
        a: 'It is used as a hot swap controller with digital power and energy monitoring. Typical end equipment includes server and storage hot swap power supplies, communications equipment, blade servers and data centre power management, where a board is inserted into a live backplane while current, voltage, power and energy are reported over PMBus.',
      },
      {
        q: 'What do buyers check before ordering an ADM1278-1ACPZ-RL?',
        a: 'Buyers compare it with the ADM1281 for selection, confirm the current limit and short circuit protection thresholds, and check that the external sense resistor and MOSFET match the design. PMBus address and firmware support are reviewed as well, together with genuine factory origin, price and lead time.',
      },
      {
        q: 'How does YIXINOU check an ADM1278-1ACPZ-RL before it ships?',
        a: 'Every 32-lead LFCSP lot is inspected on receipt and checked against the order. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Documentation and packing are verified before dispatch.',
      },
    ],
  },
  'ADM1281-1ACPZ-RL': {
    mpn: 'ADM1281-1ACPZ-RL',
    brand: 'Analog Devices',
    title: 'Hot swap controller and digital power and energy monitor with a PMBus interface in a 32-lead LFCSP',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Power Management ICs / Hot Swap Controllers',
    categoryHref: '/all-products',
    summary: 'The ADM1281-1ACPZ-RL is a hot swap controller from Analog Devices that combines digital power and energy monitoring with a PMBus interface. It supports a wide input voltage of up to 20 V and includes a built-in 12-bit ADC for current, voltage, power and energy monitoring. Soft start and current limit control are driven by the digital power monitoring path. The device comes in a 32-lead LFCSP measuring 5 x 5 mm (ACPZ). Analog Devices lists the lifecycle status as production, so the part remains available for new designs.',
    img: '/assets/images/adm1281-1acpz-rl-package.jpg',
    alt: 'A 32-lead LFCSP package, the package used for the ADM1281-1ACPZ-RL',
    imageNote: 'Illustrative package image. Ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'LFCSP, 32-lead, 5 x 5 mm (ACPZ)'],
      ['Number of pins', '32'],
      ['Input voltage', 'Wide input of up to 20 V'],
      ['Interface', 'PMBus'],
      ['ADC resolution', '12 bit, built in'],
      ['Monitoring', 'Current, voltage, power and energy'],
      ['Control', 'Soft start and current limit control based on digital power monitoring'],
      ['Device family', 'Hot swap controller and digital power and energy monitor with PMBus interface'],
      ['Lifecycle status', 'Production'],
      ['Manufacturer lifecycle status', 'Production'],
    ],
    about: 'The ADM1281-1ACPZ-RL is a hot swap controller with an integrated PMBus digital power and energy monitor from Analog Devices. It works from a wide input of up to 20 V and uses a built-in 12-bit ADC to monitor current, voltage, power and energy. Soft start and current limit control are based on the digital power monitoring path, and configuration and telemetry use the PMBus interface. It comes in a 32-lead LFCSP measuring 5 x 5 mm (ACPZ). It is used in hot swap boards for servers and storage arrays, communications power, blade servers and data centre power monitoring.',
    standards: [
      'Analog Devices ADM1281 datasheet Rev. A',
      'RoHS compliant',
      'REACH compliant',
      'Analog Devices general specification for hot swap devices',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Hot swap controller with digital power and energy monitoring',
      'PMBus interface for configuration and telemetry',
      'Built-in 12-bit ADC',
      'Wide input voltage of up to 20 V',
      'Monitors current, voltage, power and energy',
      'Soft start and current limit control driven by digital power monitoring',
      '32-lead LFCSP measuring 5 x 5 mm (ACPZ)',
      'Production lifecycle status from Analog Devices',
    ],
    applications: [
      'Server and storage array hot swap boards',
      'Communications equipment power',
      'ATCA and blade servers',
      'Data centre power monitoring',
    ],
    faq: [
      {
        q: 'What is the ADM1281-1ACPZ-RL used for?',
        a: 'It is used for hot swap control with digital power and energy monitoring. It appears in server and storage array hot swap boards, communications equipment power, ATCA and blade servers and data centre power monitoring, reporting current, voltage, power and energy over PMBus while controlling soft start and the current limit.',
      },
      {
        q: 'What do buyers check before ordering an ADM1281-1ACPZ-RL?',
        a: 'Buyers check the selection difference against the ADM1278 in terms of function and package, and confirm PMBus firmware and host tool support. They also review the current limit point and matching MOSFET, the thermal pad design required by the LFCSP package, genuine factory supply and price.',
      },
      {
        q: 'How does YIXINOU check an ADM1281-1ACPZ-RL before it ships?',
        a: 'Each 32-lead LFCSP lot is checked against the order when it arrives. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Labels, packing and documents are verified before dispatch.',
      },
    ],
  },
  'ADR01BRZ': {
    mpn: 'ADR01BRZ',
    brand: 'Analog Devices',
    title: 'Precision 10.0 V series voltage reference in an 8-lead SOIC',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Power Management ICs / Voltage References',
    categoryHref: '/all-products',
    summary: 'The ADR01BRZ is a precision 10.0 V series voltage reference from Analog Devices, supplied in an 8-lead SOIC. It accepts an input of 12.0 V to 36.0 V and holds a 10.0 V fixed output with 0.05% initial accuracy. Typical temperature coefficient is 3 ppm/\u00b0C and the output can source or sink 10 mA. The part is rated from -40 \u00b0C to +125 \u00b0C and its lifecycle status is production.',
    img: '/assets/images/adr01brz-soic-8.jpg',
    alt: 'An 8-lead SOIC package, the package used for the ADR01BRZ',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'SOIC, 8-lead (BRZ)'],
      ['Number of pins', '8'],
      ['Output voltage', '10.0 V, fixed'],
      ['Input voltage range', '12.0 V to 36.0 V'],
      ['Initial accuracy', '0.05%'],
      ['Temperature coefficient', '3 ppm/\u00b0C typical'],
      ['Output current', '10 mA'],
      ['Operating temperature', '-40 \u00b0C to +125 \u00b0C'],
      ['Packaging', 'Bulk'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The ADR01BRZ is a precision series voltage reference from Analog Devices that provides a fixed 10.0 V output. It runs from an input of 12.0 V to 36.0 V, holds 0.05% initial accuracy and a typical temperature coefficient of 3 ppm/\u00b0C, and delivers 10 mA of output current. It is housed in an 8-lead SOIC rated from -40 \u00b0C to +125 \u00b0C. The SOIC A grade of the ADR01/02/03/06 family carries automotive qualification. It is intended as a stable reference for high precision ADC and DAC circuits, instrumentation, industrial measurement, medical equipment and calibration equipment.',
    standards: [
      'Analog Devices ADR01 / ADR02 / ADR03 / ADR06 datasheet Rev. S',
      'RoHS compliant',
      'SOIC A grade is automotive qualified',
      'JEDEC package and ESD standards',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Fixed 10.0 V series reference output',
      'Initial accuracy of 0.05%',
      'Typical temperature coefficient of 3 ppm/\u00b0C',
      'Input range of 12.0 V to 36.0 V',
      'Output current of 10 mA',
      'Wide operating range of -40 \u00b0C to +125 \u00b0C',
      '8-lead SOIC package',
      'SOIC A grade of the family is automotive qualified',
    ],
    applications: [
      'Precision instrumentation',
      'High accuracy ADC and DAC references',
      'Industrial measurement',
      'Medical equipment',
      'Calibration equipment',
    ],
    faq: [
      {
        q: 'What is the ADR01BRZ used for?',
        a: 'It is used as a stable 10.0 V reference in circuits that need low drift. Typical end equipment is precision instrumentation, high accuracy ADC and DAC reference circuits, industrial measurement, medical equipment and calibration equipment, where the 3 ppm/\u00b0C typical temperature coefficient and 0.05% initial accuracy support accurate conversion.',
      },
      {
        q: 'What do buyers check before ordering an ADR01BRZ?',
        a: 'Buyers check that the system supply has enough headroom, because a 10 V output needs an input of at least 12.0 V. They also compare B grade and A grade accuracy against price, review load and line regulation, and confirm the decoupling and output capacitor requirements, plus genuine factory origin, price and lead time.',
      },
      {
        q: 'How does YIXINOU check an ADR01BRZ before it ships?',
        a: 'Every 8-lead SOIC lot is inspected against the order on receipt. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Documentation, marking and packing are verified before dispatch.',
      },
    ],
  },
  'ADUM2401CRWZ-RL': {
    mpn: 'ADUM2401CRWZ-RL',
    brand: 'Analog Devices',
    title: 'Four-channel digital isolator with 5000 V rms isolation in a 16-lead wide body SOIC',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Interface ICs / Digital Isolators',
    categoryHref: '/all-products',
    summary: 'The ADUM2401CRWZ-RL is a four-channel digital isolator from Analog Devices in a 16-lead wide body SOIC. Its channels are arranged in a 3/1 direction configuration and it provides 5000 V rms isolation for one minute. The part runs from 2.7 V to 5.5 V on either side and supports 3 V to 5 V level translation, with a 90 Mbps data rate and 32 ns propagation delay. It is rated from -40 \u00b0C to +105 \u00b0C and the Analog Devices lifecycle status is production.',
    img: '/assets/images/adum2401crwz-rl-soic-16.jpg',
    alt: 'A 16-lead SOIC wide body package, the package used for the ADUM2401CRWZ-RL',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'SOIC wide body, 16-lead (RW-16)'],
      ['Number of pins', '16'],
      ['Mounting type', 'Surface mount'],
      ['Number of channels', '4, in a 3/1 channel direction configuration'],
      ['Isolation voltage', '5000 V rms for 1 minute'],
      ['Data rate', '90 Mbps'],
      ['Propagation delay', '32 ns'],
      ['Supply voltage range', '2.7 V to 5.5 V'],
      ['Operating temperature', '-40 \u00b0C to +105 \u00b0C'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The ADUM2401CRWZ-RL is a four-channel digital isolator from Analog Devices, arranged as 3/1 channels. Isolation is rated at 5000 V rms for one minute with common mode transient immunity above 25 kV/us. It runs from 3 V and 5 V supplies with 3 V to 5 V level translation and reaches 90 Mbps at 32 ns propagation delay. It comes in a 16-lead wide body SOIC (RW-16) rated from -40 \u00b0C to +105 \u00b0C. It is used in industrial control and PLC systems, motor drive isolation, medical equipment and isolated CAN or RS-485 interfaces.',
    standards: [
      'Analog Devices ADuM2400 / ADuM2401 / ADuM2402 datasheet Rev. H',
      'RoHS compliant',
      'IEC 60747-5-2 / -17 digital isolator device standards',
      'IEC 62368-1, IEC 60601-1, IEC 60664-1 and IEC 61000-4-x',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Four channels in a 3/1 direction configuration',
      'Isolation withstand voltage of 5000 V rms for 1 minute',
      'Common mode transient immunity above 25 kV/us',
      '3 V and 5 V dual supply with 3 V/5 V level translation',
      'Data rate of 90 Mbps with 32 ns propagation delay',
      'Certified isolation per UL 1577, CSA and VDE 0884-10',
      '16-lead wide body SOIC (RW-16) for creepage distance',
      'Operating range of -40 \u00b0C to +105 \u00b0C',
    ],
    applications: [
      'Industrial control and PLC systems',
      'Motor drive isolation',
      'Medical equipment',
      'Isolated power supply communication',
      'Isolated CAN and RS-485 interfaces',
    ],
    faq: [
      {
        q: 'What is the ADUM2401CRWZ-RL used for?',
        a: 'It is used to pass digital signals across an isolation barrier in industrial control and PLC systems, motor drive isolation, medical equipment, isolated power supply communication and isolated CAN or RS-485 interfaces, where 5000 V rms isolation and a 90 Mbps data rate are needed.',
      },
      {
        q: 'What do buyers check before ordering an ADUM2401CRWZ-RL?',
        a: 'Buyers confirm the isolation withstand level, since 2.5 kV and 5 kV versions serve different safety certification requirements, and they verify the channel direction configuration of 3/1 or 4/0. They also check whether the data rate is enough for the link, the creepage distance of the wide body package, the cost and service life compared with optocoupler solutions, and price and lead time.',
      },
      {
        q: 'How does YIXINOU check an ADUM2401CRWZ-RL before it ships?',
        a: 'Every 16-lead wide body SOIC lot is counted and inspected on receipt against the purchase order. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Marking, packing and documents are checked before dispatch.',
      },
    ],
  },
  'AS5600-ASOT': {
    mpn: 'AS5600-ASOT',
    brand: 'ams OSRAM',
    title: '12-bit non-contact magnetic rotary position sensor with I2C, PWM and analog outputs in an 8-pin SOIC',
    category: 'Sensor',
    categoryHref: '/all-products',
    summary: 'The AS5600-ASOT is a 12-bit high resolution programmable non-contact magnetic angle position sensor, used as a magnetic encoder. It offers I2C, PWM and analog output options and is supplied in an 8-pin SOIC. The operating range is -40 \u00b0C to +125 \u00b0C, so the part suits designs that must work at high ambient temperature. It is qualified to AEC-Q100 and is RoHS compliant.',
    img: '/assets/images/as5600-asot-package.jpg',
    alt: 'An 8-pin SOIC package, the package used for the AS5600-ASOT',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Function', 'Non-contact magnetic rotary position sensor (magnetic encoder)'],
      ['Resolution', '12 bit, high resolution'],
      ['Output interfaces', 'I2C, PWM and analog'],
      ['Package / case', '8-pin SOIC'],
      ['Operating temperature', '-40 \u00b0C to +125 \u00b0C'],
      ['Sensing type', 'Non-contact magnetic angle measurement'],
      ['Configuration', 'Programmable'],
      ['Magnet requirement', 'Radially magnetised magnet with a defined air gap'],
      ['Automotive qualification', 'AEC-Q100'],
      ['Environmental compliance', 'RoHS'],
    ],
    about: 'The AS5600-ASOT is a 12-bit high resolution programmable non-contact magnetic angle position sensor from ams OSRAM, commonly used as a magnetic encoder. It measures the angle of a rotating magnetic field without contact and makes the result available through I2C, PWM or analog output. The device is supplied in an 8-pin SOIC and is rated from -40 \u00b0C to +125 \u00b0C, and it is qualified to AEC-Q100 and RoHS compliant. It is used for motor rotor position detection, as a replacement for knobs and potentiometers, in gimbals and robot joints, for valve position feedback and in drone servos.',
    standards: [
      'AEC-Q100',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '12-bit high resolution angle measurement',
      'Non-contact magnetic sensing without wear parts',
      'I2C, PWM and analog output options',
      'Programmable configuration',
      '8-pin SOIC package',
      'Operating range of -40 \u00b0C to +125 \u00b0C',
      'AEC-Q100 qualification',
      'RoHS compliant',
    ],
    applications: [
      'Motor rotor position detection',
      'Replacement for knobs and potentiometers',
      'Gimbals and robot joints',
      'Valve position feedback',
      'Drone servos',
    ],
    faq: [
      {
        q: 'What is the AS5600-ASOT used for?',
        a: 'It is used to measure rotary position without contact in motor rotor position detection, as a replacement for knobs and potentiometers, in gimbals and robot joints, for valve position feedback and in drone servos, reporting 12-bit angle data over I2C, PWM or an analog output.',
      },
      {
        q: 'What do buyers check before ordering an AS5600-ASOT?',
        a: 'Buyers check that a radially magnetised magnet and the air gap design match the mounting tolerance, because the measurement is sensitive to installation. They also review the I2C pull-up and filter values, the maximum rotation speed allowed by the sampling rate, the 125 \u00b0C high temperature rating, the selection difference against the AS5048 and the incremental output AS5601, and price and lead time.',
      },
      {
        q: 'How does YIXINOU check an AS5600-ASOT before it ships?',
        a: 'Each 8-pin SOIC lot is inspected and counted against the order when it is received. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Marking, packing and documentation are verified before dispatch.',
      },
    ],
  },
  'ATMEGA128A-AU': {
    mpn: 'ATMEGA128A-AU',
    brand: 'Microchip Technology',
    title: 'ATmega128A 8-bit AVR low power microcontroller in a 64-lead TQFP',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The ATMEGA128A-AU is an 8-bit AVR microcontroller from Microchip Technology in a 64-lead TQFP. It runs an enhanced RISC core at 16 MHz with 128 KB of Flash, 4 KB of SRAM and 4 KB of EEPROM. The device offers 53 programmable I/O lines plus two USARTs, SPI, I2C and JTAG, and includes an 8-channel 10-bit ADC. It operates from 2.7 V to 5.5 V over -40 \u00b0C to +85 \u00b0C and is listed as production.',
    img: '/assets/images/atmega128a-au-tqfp-64.jpg',
    alt: 'A 64-lead TQFP package, the package used for the ATMEGA128A-AU',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'TQFP, 64-lead (AU)'],
      ['Number of pins', '64'],
      ['Mounting type', 'Surface mount'],
      ['Core', '8-bit AVR enhanced RISC at 16 MHz'],
      ['Program memory', '128 KB Flash'],
      ['Data memory', '4 KB SRAM and 4 KB EEPROM'],
      ['Supply voltage range', '2.7 V to 5.5 V'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C'],
      ['Interfaces / I/O', '53 programmable I/O, 2 USART, SPI, I2C, JTAG, 8-channel 10-bit ADC, 8 PWM channels'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The ATMEGA128A-AU is an 8-bit AVR microcontroller from Microchip Technology in a 64-lead TQFP. It uses an enhanced RISC core running at 16 MHz with 128 KB of Flash, 4 KB of SRAM and 4 KB of EEPROM, and it offers 53 programmable I/O lines, two USARTs, SPI, I2C and JTAG. An 8-channel 10-bit ADC is included and the supply range is 2.7 V to 5.5 V over -40 \u00b0C to +85 \u00b0C. Flash endurance is 10,000 cycles and EEPROM endurance is 100,000 cycles. It is used in industrial control, instrumentation, communications equipment and legacy upgrades.',
    standards: [
      'Atmel ATmega128A datasheet summary, Atmel-8151S Rev. U',
      'RoHS compliant',
      'Lead-free (Pb-free) package, RoHS and REACH compliant',
      'Green process, JEDEC package and ESD standards',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'AVR enhanced RISC core running at 16 MHz',
      '128 KB Flash, 4 KB SRAM and 4 KB EEPROM',
      '53 programmable I/O lines',
      'Two USARTs plus SPI, I2C and JTAG interfaces',
      '8-channel 10-bit ADC and 8 PWM channels',
      'Wide supply range of 2.7 V to 5.5 V',
      'Flash endurance 10,000 cycles, EEPROM endurance 100,000 cycles',
      'Data retention of 20 years at 85 \u00b0C',
    ],
    applications: [
      'Industrial control',
      'Instrumentation',
      'Communications equipment',
      'Legacy product maintenance and upgrade',
    ],
    faq: [
      {
        q: 'What is the ATMEGA128A-AU used for?',
        a: 'It is used as the main controller in industrial control, instrumentation and communications equipment, and it is widely used to maintain or upgrade older boards. Its 128 KB Flash, 53 I/O lines, dual USART and 5 V operation suit legacy designs that are being kept in production.',
      },
      {
        q: 'What do buyers check before ordering an ATMEGA128A-AU?',
        a: 'Buyers check the difference between the ATmega128A and the earlier ATmega128, because the A version corrects defects and firmware should be confirmed before substitution. They also check the product lifecycle and stock year, that parts are genuine, the 5 V logic level, the upgrade path to a larger device, and price and minimum order quantity.',
      },
      {
        q: 'How does YIXINOU check an ATMEGA128A-AU before it ships?',
        a: 'Every 64-lead TQFP lot is inspected on receipt and matched to the order. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Marking, dry packing and documents are verified before dispatch.',
      },
    ],
  },
  'ATMEGA2561-16AU': {
    mpn: 'ATMEGA2561-16AU',
    brand: 'Microchip Technology',
    title: 'ATmega2561 8-bit AVR microcontroller in a 64-lead TQFP',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The ATMEGA2561-16AU is an 8-bit AVR microcontroller from Microchip Technology in a 64-lead TQFP. It runs an enhanced RISC core at 16 MHz with 256 KB of Flash, 8 KB of SRAM and 4 KB of EEPROM. The part has 54 programmable I/O lines, two USARTs, SPI, I2C and JTAG boundary scan, plus an 8-channel 10-bit ADC. It operates from 4.5 V to 5.5 V over -40 \u00b0C to +85 \u00b0C and is listed as production.',
    img: '/assets/images/atmega2561-16au-tqfp-64.jpg',
    alt: 'A 64-lead TQFP package, the package used for the ATMEGA2561-16AU',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'TQFP, 64-lead (AU)'],
      ['Number of pins', '64'],
      ['Mounting type', 'Surface mount'],
      ['Core', '8-bit AVR enhanced RISC at 16 MHz'],
      ['Program memory', '256 KB Flash'],
      ['Data memory', '8 KB SRAM and 4 KB EEPROM'],
      ['Supply voltage range', '4.5 V to 5.5 V'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C'],
      ['Interfaces / I/O', '54 programmable I/O, 2 USART, SPI, I2C, JTAG boundary scan, 8-channel 10-bit ADC'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The ATMEGA2561-16AU is an 8-bit AVR microcontroller from Microchip Technology in a 64-lead TQFP. Its enhanced RISC core runs at 16 MHz with 256 KB of Flash, 8 KB of SRAM and 4 KB of EEPROM, plus 54 programmable I/O lines, two USARTs, SPI, I2C and JTAG boundary scan. The supply range is 4.5 V to 5.5 V over -40 \u00b0C to +85 \u00b0C. Flash endurance is 10,000 cycles and EEPROM endurance is 100,000 cycles. It is used in industrial control, data acquisition, appliance control, motor drive, communication gateways and legacy product maintenance.',
    standards: [
      'Microchip datasheet DS40002211A for the ATmega640/1280/1281/2560/2561 family',
      'RoHS compliant',
      'Lead-free (Pb-free) package, RoHS and REACH compliant',
      'Green process, JEDEC package and ESD standards',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'AVR enhanced RISC core running at 16 MHz',
      '256 KB Flash, 8 KB SRAM and 4 KB EEPROM',
      '54 programmable I/O lines',
      'Two USARTs plus SPI, I2C and JTAG boundary scan',
      '8-channel 10-bit ADC and 10 PWM channels',
      'Supply range of 4.5 V to 5.5 V',
      'Flash endurance 10,000 cycles, EEPROM endurance 100,000 cycles',
      'Data retention of 20 years at 85 \u00b0C',
    ],
    applications: [
      'Industrial control',
      'Data acquisition',
      'Appliance control',
      'Motor drive',
      'Communication gateways',
      'Legacy product maintenance',
    ],
    faq: [
      {
        q: 'What is the ATMEGA2561-16AU used for?',
        a: 'It is used as the main controller in industrial control, data acquisition, appliance control, motor drive and communication gateways, and for keeping older boards in production. Its 256 KB Flash, 54 I/O lines and two USARTs suit designs that need more program space than a smaller AVR can offer.',
      },
      {
        q: 'What do buyers check before ordering an ATMEGA2561-16AU?',
        a: 'Buyers confirm that parts are genuine, because part markings changed after Microchip acquired Atmel, and they review the difference from the ATmega2560, which has no parallel port and a different pinout, so a substitution requires a board change. They also check 5 V and 3.3 V level matching, programmer and fuse settings, obsolescence risk and stock year, and price and minimum order quantity.',
      },
      {
        q: 'How does YIXINOU check an ATMEGA2561-16AU before it ships?',
        a: 'Each 64-lead TQFP lot is counted and inspected against the order on receipt. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Marking, packing and documentation are verified before dispatch.',
      },
    ],
  },
  'ATTINY24A-SSU': {
    mpn: 'ATTINY24A-SSU',
    brand: 'Microchip Technology',
    title: 'ATtiny24A 8-bit AVR low power microcontroller in a 14-lead SOIC',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The ATTINY24A-SSU is an 8-bit AVR microcontroller from Microchip Technology in a 14-lead SOIC. It uses an enhanced RISC core at 20 MHz with 2 KB of Flash, 128 B of SRAM and 128 B of EEPROM. The device provides 12 programmable I/O lines, a USI serial interface, timers and an 8-channel 10-bit ADC. It operates from 1.8 V to 5.5 V over -40 \u00b0C to +85 \u00b0C and is listed as production.',
    img: '/assets/images/attiny24a-ssu-soic-14.jpg',
    alt: 'A 14-lead SOIC package, the package used for the ATTINY24A-SSU',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'SOIC, 14-lead (SSU)'],
      ['Number of pins', '14'],
      ['Mounting type', 'Surface mount'],
      ['Core', '8-bit AVR enhanced RISC at 20 MHz'],
      ['Program memory', '2 KB Flash'],
      ['Data memory', '128 B SRAM and 128 B EEPROM'],
      ['Supply voltage range', '1.8 V to 5.5 V'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C'],
      ['Interfaces / I/O', '12 programmable I/O, USI serial interface, 8-channel 10-bit ADC, timers'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The ATTINY24A-SSU is a small 8-bit AVR microcontroller from Microchip Technology in a 14-lead SOIC. It uses an enhanced RISC core running at 20 MHz with 2 KB of Flash, 128 B of SRAM and 128 B of EEPROM, and it offers 12 programmable I/O lines, a USI serial interface, timers and an 8-channel 10-bit ADC. The supply range is 1.8 V to 5.5 V over -40 \u00b0C to +85 \u00b0C. Flash endurance is 10,000 cycles and EEPROM endurance is 100,000 cycles. It is used in small sensor nodes, battery powered devices, toys, LED control and simple switch control.',
    standards: [
      'Atmel / Microchip datasheet Atmel-8183S for the ATtiny24A/44A/84A family',
      'RoHS compliant',
      'Lead-free (Pb-free) package',
      'Green process, JEDEC package and ESD standards',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'AVR enhanced RISC core running at 20 MHz',
      '2 KB Flash, 128 B SRAM and 128 B EEPROM',
      '12 programmable I/O lines',
      'USI serial interface and timers',
      '8-channel 10-bit ADC',
      'Wide supply range of 1.8 V to 5.5 V',
      'Flash endurance 10,000 cycles, EEPROM endurance 100,000 cycles',
      'Data retention of 20 years at 85 \u00b0C',
    ],
    applications: [
      'Small sensor nodes',
      'Battery powered devices',
      'Toys',
      'LED control',
      'Simple timing and switch control',
    ],
    faq: [
      {
        q: 'What is the ATTINY24A-SSU used for?',
        a: 'It is used where a very small, low cost controller is enough, such as small sensor nodes, battery powered devices, toys, LED control and simple timing or switch control, using its 12 I/O lines, USI interface and 8-channel 10-bit ADC.',
      },
      {
        q: 'What do buyers check before ordering an ATTINY24A-SSU?',
        a: 'Buyers evaluate program size carefully, because only 2 KB of Flash is available, and they confirm genuine parts, programming interface and programmer compatibility for ISP or TPI, and measured low power mode behaviour. Alternative devices such as the ATtiny84 or ATtiny25, price and minimum order quantity are also reviewed.',
      },
      {
        q: 'How does YIXINOU check an ATTINY24A-SSU before it ships?',
        a: 'Every 14-lead SOIC lot is inspected when it arrives and checked against the order. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Marking, packing and documents are verified before dispatch.',
      },
    ],
  },
  'ATTINY84A-PU': {
    mpn: 'ATTINY84A-PU',
    brand: 'Microchip Technology',
    title: 'ATtiny84A 8-bit AVR low power microcontroller in a 14-lead PDIP',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The ATTINY84A-PU is an 8-bit AVR microcontroller from Microchip Technology in a 14-lead PDIP. It runs an enhanced RISC core at 20 MHz with 8 KB of Flash, 512 B of SRAM and 512 B of EEPROM. The device offers 12 programmable I/O lines, a USI serial interface, two timers and an 8-channel 10-bit ADC. It operates from 1.8 V to 5.5 V over -40 \u00b0C to +85 \u00b0C and is listed as production.',
    img: '/assets/images/attiny84a-pu-dip-14.jpg',
    alt: 'A 14-pin PDIP package, the package used for the ATTINY84A-PU',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'PDIP, 14-lead (PU)'],
      ['Number of pins', '14'],
      ['Mounting type', 'Through hole'],
      ['Core', '8-bit AVR enhanced RISC at 20 MHz'],
      ['Program memory', '8 KB Flash'],
      ['Data memory', '512 B SRAM and 512 B EEPROM'],
      ['Supply voltage range', '1.8 V to 5.5 V'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C'],
      ['Interfaces / I/O', '12 programmable I/O, USI serial interface, 8-channel 10-bit ADC, 2 timers'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The ATTINY84A-PU is an 8-bit AVR microcontroller from Microchip Technology in a through hole 14-lead PDIP. Its enhanced RISC core runs at 20 MHz with 8 KB of Flash, 512 B of SRAM and 512 B of EEPROM, with 12 programmable I/O lines, a USI serial interface, two timers and an 8-channel 10-bit ADC. The supply range is 1.8 V to 5.5 V over -40 \u00b0C to +85 \u00b0C. Flash endurance is 10,000 cycles and EEPROM endurance is 100,000 cycles. It is used in small control boards, teaching experiments, handheld devices, sensor acquisition and prototype validation.',
    standards: [
      'Atmel / Microchip datasheet Atmel-8183S for the ATtiny24A/44A/84A family',
      'RoHS compliant',
      'Lead-free (Pb-free) package',
      'Green process, JEDEC package and ESD standards',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'AVR enhanced RISC core running at 20 MHz',
      '8 KB Flash, 512 B SRAM and 512 B EEPROM',
      '12 programmable I/O lines',
      'USI serial interface and two timers',
      '8-channel 10-bit ADC',
      'Wide supply range of 1.8 V to 5.5 V',
      'Through hole 14-lead PDIP package for easy prototyping',
      'Flash endurance 10,000 cycles, EEPROM endurance 100,000 cycles',
    ],
    applications: [
      'Small control boards',
      'Teaching and laboratory experiments',
      'Handheld devices',
      'Sensor acquisition',
      'DIY and prototype validation',
    ],
    faq: [
      {
        q: 'What is the ATTINY84A-PU used for?',
        a: 'It is used in small control boards, teaching and laboratory experiments, handheld devices, sensor acquisition and DIY or prototype validation, where its 8 KB Flash, 12 I/O lines and 8-channel 10-bit ADC are enough for the task.',
      },
      {
        q: 'What do buyers check before ordering an ATTINY84A-PU?',
        a: 'Buyers choose the PDIP package when they need easy handling for prototyping and small batches, and they compare the pinout and resources with the ATtiny24A. They also confirm genuine parts, programmer compatibility and low power behaviour, and note that a surface mount package is normally used for volume production.',
      },
      {
        q: 'How does YIXINOU check an ATTINY84A-PU before it ships?',
        a: 'Each 14-lead PDIP lot is counted and inspected against the order on receipt. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Marking, packing and documents are verified before dispatch.',
      },
    ],
  },
  'ATmega2560-16AU': {
    mpn: 'ATmega2560-16AU',
    brand: 'Microchip Technology',
    title: 'ATmega2560 8-bit AVR microcontroller with 86 I/O lines in a 100-lead TQFP',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The ATmega2560-16AU is an 8-bit AVR microcontroller from Microchip Technology in a 100-lead TQFP. It runs an enhanced RISC core at 16 MHz with 256 KB of Flash, 8 KB of SRAM and 4 KB of EEPROM. The device provides 86 programmable I/O lines, four USARTs, SPI, I2C and JTAG boundary scan, together with a 16-channel 10-bit ADC. It operates from 4.5 V to 5.5 V over -40 \u00b0C to +85 \u00b0C and is listed as production.',
    img: '/assets/images/atmega2560-16au-tqfp-100.jpg',
    alt: 'A 100-lead TQFP package, the package used for the ATmega2560-16AU',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'TQFP, 100-lead (AU)'],
      ['Number of pins', '100'],
      ['Mounting type', 'Surface mount'],
      ['Core', '8-bit AVR enhanced RISC at 16 MHz'],
      ['Program memory', '256 KB Flash'],
      ['Data memory', '8 KB SRAM and 4 KB EEPROM'],
      ['Supply voltage range', '4.5 V to 5.5 V'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C'],
      ['Interfaces / I/O', '86 programmable I/O, 4 USART, SPI, I2C, JTAG boundary scan, 16-channel 10-bit ADC'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The ATmega2560-16AU is an 8-bit AVR microcontroller from Microchip Technology in a 100-lead TQFP. Its enhanced RISC core runs at 16 MHz and offers 256 KB of Flash, 8 KB of SRAM and 4 KB of EEPROM, with 86 programmable I/O lines, four USARTs, SPI, I2C and JTAG boundary scan, plus a 16-channel 10-bit ADC. The supply range is 4.5 V to 5.5 V over -40 \u00b0C to +85 \u00b0C. Flash endurance is 10,000 cycles and EEPROM endurance is 100,000 cycles. It is used on Arduino Mega class boards, in 3D printer mainboards, CNC control, robotics and industrial data acquisition.',
    standards: [
      'Microchip datasheet DS40002211A for the ATmega640/1280/1281/2560/2561 family',
      'RoHS compliant',
      'Lead-free (Pb-free) package, RoHS and REACH compliant',
      'Green process, JEDEC package and ESD standards',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'AVR enhanced RISC core running at 16 MHz',
      '256 KB Flash, 8 KB SRAM and 4 KB EEPROM',
      '86 programmable I/O lines',
      'Four USARTs plus SPI, I2C and JTAG boundary scan',
      '16-channel 10-bit ADC and 20 PWM channels',
      'Supply range of 4.5 V to 5.5 V',
      'Flash endurance 10,000 cycles, EEPROM endurance 100,000 cycles',
      'Data retention of 20 years at 85 \u00b0C',
    ],
    applications: [
      'Arduino Mega class core chip',
      '3D printer mainboards',
      'CNC control',
      'Multi-axis robotics',
      'Industrial data acquisition',
    ],
    faq: [
      {
        q: 'What is the ATmega2560-16AU used for?',
        a: 'It is used as the main controller where a large number of inputs and outputs are needed, including Arduino Mega class boards, 3D printer mainboards, CNC control, multi-axis robotics and industrial data acquisition, supported by 86 I/O lines, four USARTs and a 16-channel 10-bit ADC.',
      },
      {
        q: 'What do buyers check before ordering an ATmega2560-16AU?',
        a: 'Buyers confirm the pin count they need, since the 86 I/O lines are the main value of this device, and they verify that parts are genuine because counterfeits of this part are common. They also check 5 V supply and external device level matching, the difference from the ATmega2561, programming and bootloader requirements, and price and supply.',
      },
      {
        q: 'How does YIXINOU check an ATmega2560-16AU before it ships?',
        a: 'Every 100-lead TQFP lot is inspected on receipt and matched to the order. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Marking, packing and documents are verified before dispatch.',
      },
    ],
  },
  'ATmega328P-AU': {
    mpn: 'ATmega328P-AU',
    brand: 'Microchip Technology',
    title: 'ATmega328P 8-bit AVR microcontroller in a 32-lead TQFP for volume production',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The ATmega328P-AU is an 8-bit AVR microcontroller from Microchip Technology in a surface mount 32-lead TQFP. It runs an enhanced RISC core at 20 MHz with 32 KB of Flash, 2 KB of SRAM and 1 KB of EEPROM. The part provides 23 programmable I/O lines, a USART, SPI, I2C and three timers, plus an 8-channel 10-bit ADC. It operates from 1.8 V to 5.5 V over -40 \u00b0C to +85 \u00b0C, and its lifecycle status is NRND, so availability should be confirmed before design-in.',
    img: '/assets/images/atmega328p-au-tqfp-32.jpg',
    alt: 'A 32-lead TQFP package, the package used for the ATmega328P-AU',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'TQFP, 32-lead (AU)'],
      ['Number of pins', '32'],
      ['Mounting type', 'Surface mount'],
      ['Core', '8-bit AVR enhanced RISC at 20 MHz'],
      ['Program memory', '32 KB Flash'],
      ['Data memory', '2 KB SRAM and 1 KB EEPROM'],
      ['Supply voltage range', '1.8 V to 5.5 V (1.8 V applies up to 4 MHz)'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C'],
      ['Interfaces / I/O', '23 programmable I/O, USART, SPI, I2C, 8-channel 10-bit ADC, 3 timers'],
      ['Lifecycle status', 'NRND \u2014 confirm availability before ordering'],
    ],
    about: 'The ATmega328P-AU is an 8-bit AVR microcontroller from Microchip Technology in a 32-lead TQFP. Its enhanced RISC core runs at 20 MHz with 32 KB of Flash, 2 KB of SRAM and 1 KB of EEPROM, and it provides 23 programmable I/O lines, a USART, SPI, I2C, three timers and an 8-channel 10-bit ADC. The supply range is 1.8 V to 5.5 V over -40 \u00b0C to +85 \u00b0C. Flash endurance is 10,000 cycles and EEPROM endurance is 100,000 cycles, and both ISP and TPI programming are supported. It is used on Arduino compatible boards, consumer electronics, small appliances and volume production control boards.',
    standards: [
      'Microchip datasheet DS40002061B for the ATmega48A/88A/168A/328/P family',
      'RoHS compliant',
      'Lead-free (Pb-free) package, RoHS and REACH compliant',
      'Green process, JEDEC package and ESD standards',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'AVR enhanced RISC core running at 20 MHz',
      '32 KB Flash, 2 KB SRAM and 1 KB EEPROM',
      '23 programmable I/O lines',
      'USART, SPI and I2C interfaces with three timers',
      '8-channel 10-bit ADC',
      'Supply range of 1.8 V to 5.5 V, 1.8 V applies up to 4 MHz',
      'Surface mount 32-lead TQFP for volume production',
      'ISP (SPI) and TPI programming support',
    ],
    applications: [
      'Arduino compatible boards',
      'Consumer electronics',
      'Small appliances',
      'Sensor modules',
      'Volume production control boards',
    ],
    faq: [
      {
        q: 'What is the ATmega328P-AU used for?',
        a: 'It is used as the controller on Arduino compatible boards, consumer electronics, small appliances, sensor modules and volume production control boards, where a surface mount package and firmware compatibility with the through hole version are both wanted.',
      },
      {
        q: 'What do buyers check before ordering an ATmega328P-AU?',
        a: 'Buyers confirm that the surface mount package suits volume production and review the MSL rating and reflow profile. They also verify that parts are genuine, note that firmware is fully compatible with the PU through hole version, choose a volume programming method such as ISP or pre-programmed parts, and check the difference from the ATmega328PB along with price and lead time.',
      },
      {
        q: 'How does YIXINOU check an ATmega328P-AU before it ships?',
        a: 'Each 32-lead TQFP lot is counted and inspected against the order when it arrives. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Marking, dry packing and documentation are verified before dispatch.',
      },
    ],
  },
  'ATmega328P-PU': {
    mpn: 'ATmega328P-PU',
    brand: 'Microchip Technology',
    title: 'ATmega328P 8-bit AVR microcontroller in a 28-pin PDIP for prototyping and education',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The ATmega328P-PU is an 8-bit AVR microcontroller from Microchip Technology in a through hole 28-pin PDIP. It runs an enhanced RISC core at 20 MHz with 32 KB of Flash, 2 KB of SRAM and 1 KB of EEPROM. The part provides 23 programmable I/O lines, a USART, SPI, I2C and three timers, plus a 6-channel 10-bit ADC. It operates from 1.8 V to 5.5 V over -40 \u00b0C to +85 \u00b0C and is listed as production.',
    img: '/assets/images/atmega328p-pu-pdip-28.jpg',
    alt: 'A 28-pin PDIP package, the package used for the ATmega328P-PU',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'PDIP, 28-lead, narrow body (PU)'],
      ['Number of pins', '28'],
      ['Mounting type', 'Through hole'],
      ['Core', '8-bit AVR enhanced RISC at 20 MHz'],
      ['Program memory', '32 KB Flash'],
      ['Data memory', '2 KB SRAM and 1 KB EEPROM'],
      ['Supply voltage range', '1.8 V to 5.5 V (1.8 V applies up to 4 MHz)'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C'],
      ['Interfaces / I/O', '23 programmable I/O, USART, SPI, I2C, 6-channel 10-bit ADC, 3 timers'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The ATmega328P-PU is an 8-bit AVR microcontroller from Microchip Technology in a through hole 28-pin PDIP. Its enhanced RISC core runs at 20 MHz with 32 KB of Flash, 2 KB of SRAM and 1 KB of EEPROM, with 23 programmable I/O lines, a USART, SPI, I2C, three timers and a 6-channel 10-bit ADC. The supply range is 1.8 V to 5.5 V over -40 \u00b0C to +85 \u00b0C. Flash endurance is 10,000 cycles and EEPROM endurance is 100,000 cycles, with ISP and high voltage parallel programming support. It is used on Arduino Uno class boards, in teaching laboratories, DIY electronics and small appliances.',
    standards: [
      'Microchip datasheet DS40002061B for the ATmega48A/88A/168A/328/P family',
      'RoHS compliant',
      'Lead-free (Pb-free) package, RoHS and REACH compliant',
      'Green process, JEDEC package and ESD standards',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'AVR enhanced RISC core running at 20 MHz',
      '32 KB Flash, 2 KB SRAM and 1 KB EEPROM',
      '23 programmable I/O lines',
      'USART, SPI and I2C interfaces with three timers',
      '6-channel 10-bit ADC',
      'Supply range of 1.8 V to 5.5 V, 1.8 V applies up to 4 MHz',
      'Through hole 28-pin PDIP package',
      'ISP (SPI) and high voltage parallel programming support',
    ],
    applications: [
      'Arduino Uno class core chip',
      'Teaching and laboratory experiments',
      'DIY electronics',
      'Small appliances',
      'Simple industrial control',
    ],
    faq: [
      {
        q: 'What is the ATmega328P-PU used for?',
        a: 'It is used as the core chip on Arduino Uno class boards and in teaching laboratory experiments, DIY electronics, small appliances and simple industrial control, where the through hole 28-pin package makes assembly and replacement easy.',
      },
      {
        q: 'What do buyers check before ordering an ATmega328P-PU?',
        a: 'Buyers compare the price and use case of the DIP through hole version against the AU surface mount version, and they check that parts are genuine because counterfeits of this part are very common. They also review fuse bit and external crystal configuration, 5 V level matching with 3.3 V peripherals, bootloader and programmer requirements, and price and supply.',
      },
      {
        q: 'How does YIXINOU check an ATmega328P-PU before it ships?',
        a: 'Every 28-pin PDIP lot is inspected on receipt and checked against the order. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Marking, packing and documentation are verified before dispatch.',
      },
    ],
  },
  'ATmega328PB-AU': {
    mpn: 'ATmega328PB-AU',
    brand: 'Microchip Technology',
    title: '8-bit AVR picoPower microcontroller with 32KB flash in TQFP-32',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The ATmega328PB-AU is a Microchip Technology 8-bit AVR picoPower microcontroller in a 32-pin TQFP surface-mount package. It runs at up to 20MHz and combines 32kB of flash, 2kB SRAM and 1kB EEPROM over a 1.8V to 5.5V supply. Compared with the ATmega328P it adds two extra 16-bit timers, two extra USARTs, TWI (I2C) and a peripheral touch controller, for five timers/counters and 27 programmable I/O. Peripherals include a 10-bit ADC, SPI, USART, brown-out detect/reset, POR, PWM and a watchdog timer, and the part is rated from -40 to +85\u00b0C.',
    img: '/assets/images/atmega328pb-au-tqfp-32.jpg',
    alt: 'A 32-lead TQFP package, the package used for the ATmega328PB-AU',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package', 'TQFP-32'],
      ['Number of pins', '32'],
      ['Mounting type', 'Surface Mount'],
      ['Core architecture', 'AVR'],
      ['Maximum frequency', '20MHz'],
      ['Flash memory', '32kB'],
      ['SRAM', '2kB'],
      ['EEPROM', '1KB'],
      ['Supply voltage', '1.8V to 5.5V'],
      ['Operating temperature', '-40\u00b0C to +85\u00b0C'],
    ],
    about: 'The ATmega328PB-AU is an enhanced Microchip AVR picoPower microcontroller in the TQFP-32 surface-mount package. It provides 32KB flash, 2KB SRAM, 1KB EEPROM, 27 programmable I/O, a 10-bit ADC, SPI, USART, TWI and a peripheral touch controller, and runs from 1.8V to 5.5V at up to 20MHz. Typical uses include Arduino-compatible enhanced boards, capacitive touch keys, multi-serial communication equipment, small home appliances and industrial control. Its peripheral set differs from the ATmega328P, so existing code usually needs register or library updates.',
    standards: [
      'Microchip ATmega328PB Summary Datasheet',
      'RoHS compliant',
      'Pb-free (lead-free), Green package',
      'Flash endurance 10,000 cycles and EEPROM endurance 100,000 cycles',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '8-bit AVR enhanced RISC core running at up to 20MHz',
      '32KB flash, 2KB SRAM and 1KB EEPROM on chip',
      '1.8V to 5.5V supply range with picoPower low-power technology',
      'Two extra 16-bit timers, two extra USARTs, TWI (I2C) and a peripheral touch controller versus the ATmega328P',
      '27 programmable I/O and five timers/counters',
      '10-bit ADC plus SPI, USART, brown-out detect/reset, POR, PWM and watchdog timer',
      'Internal oscillator and -40 to +85\u00b0C rating',
    ],
    applications: [
      'Arduino-compatible enhanced boards',
      'Capacitive touch keypads',
      'Multi-serial communication equipment',
      'Small home appliances',
      'Industrial control',
    ],
    faq: [
      {
        q: 'What is the ATmega328PB-AU used for?',
        a: 'It is used on Arduino-compatible enhanced boards, capacitive touch key panels, multi-serial communication equipment, small home appliances and industrial control boards. The 32KB flash, 2KB SRAM, 27 programmable I/O pins and peripheral touch controller make it a fit for designs that need more timers, more USARTs and touch sensing than the earlier ATmega328P offers.',
      },
      {
        q: 'What do buyers check before ordering an ATmega328PB-AU?',
        a: 'Buyers first confirm that the design can be ported from the ATmega328P, because the 328PB peripheral set differs and existing code usually needs register or library changes. They then verify that QTouch capacitive touch meets the requirement, check flashing and toolchain compatibility, confirm that the parts are genuine Microchip product rather than refurbished stock, and review price and supply, since the 328PB normally costs slightly more than the 328P.',
      },
      {
        q: 'How does YIXINOU check an ATmega328PB-AU before it ships?',
        a: 'TQFP-32 lots are checked before dispatch by comparing lot markings and date codes with the order and by verifying the package body and pin count against the datasheet. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Parts are then packed with the documented results of those checks.',
      },
    ],
  },
  'BCM54908EA1IFFBG': {
    mpn: 'BCM54908EA1IFFBG',
    brand: 'Broadcom',
    title: '25Gb Ethernet octal copper PHY in a BGA package',
    category: 'Module',
    categoryHref: '/all-products',
    summary: 'The BCM54908EA1IFFBG is a Broadcom octal Ethernet physical layer transceiver (PHY) for copper cabling, covering 1000BASE-T, 100BASE-TX and 10BASE-T operation. It is a 25Gb Ethernet PHY supplied in a BGA package and rated from -40 to +85\u00b0C. The device is aimed at data centre switches, 25G server network adapters, enterprise switching equipment and cloud infrastructure. It is listed against IEEE 802.3 and RoHS, and Broadcom documentation for the family is released only under NDA.',
    img: '/assets/images/bcm54908ea1iffbg-package.jpg',
    alt: 'A BGA package, the package used for the BCM54908EA1IFFBG',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Device type', 'Ethernet physical layer transceiver (PHY)'],
      ['Ports', 'Octal, eight channels'],
      ['Target line rate', '25Gb Ethernet'],
      ['Supported copper standards', '1000BASE-T / 100BASE-TX / 10BASE-T'],
      ['Media', 'Copper twisted-pair cabling'],
      ['Package', 'BGA'],
      ['Operating temperature', '-40\u00b0C to +85\u00b0C'],
      ['Standards compliance', 'IEEE 802.3'],
      ['RoHS', 'Compliant as listed in the manufacturer standard data'],
      ['Documentation', 'Not public; released by Broadcom under NDA'],
    ],
    about: 'The BCM54908EA1IFFBG is a Broadcom Ethernet physical layer transceiver for copper media, supporting 1000BASE-T, 100BASE-TX and 10BASE-T across eight channels in one device. It comes in a BGA package rated for -40 to +85\u00b0C operation and is aimed at the 25Gb Ethernet class of networking hardware. Target equipment includes data centre switches, 25G server network cards, enterprise switching and cloud infrastructure. Broadcom releases full documentation for this family only under NDA.',
    standards: [
      'IEEE 802.3',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Octal (eight-channel) copper Ethernet PHY',
      'Supports 1000BASE-T, 100BASE-TX and 10BASE-T',
      '25Gb Ethernet class device for high-density switch designs',
      'BGA package',
      'Industrial temperature range of -40 to +85\u00b0C',
      'Designed around IEEE 802.3',
      'Reference material available from Broadcom under NDA',
    ],
    applications: [
      'Data centre switches',
      '25G server network adapters',
      'Enterprise switching equipment',
      'Cloud infrastructure',
    ],
    faq: [
      {
        q: 'What is the BCM54908EA1IFFBG used for?',
        a: 'It is designed into data centre switches, 25G server network adapters, enterprise switching equipment and cloud infrastructure. Each device carries eight copper Ethernet channels for 1000BASE-T, 100BASE-TX and 10BASE-T, so it is used where a high port count is needed on a single line card or mainboard.',
      },
      {
        q: 'What do buyers check before ordering a BCM54908EA1IFFBG?',
        a: 'Buyers start with the companion switch chip, because the PHY and switch pairing has to match a Broadcom reference design. They also confirm whether the design uses copper or optical interfaces, check that the board can meet the impedance and signal integrity requirements of 25G routing, verify that documentation and technical support can be obtained through an NDA channel, and review supply, lead time and price, since the part is normally quoted through authorised distribution.',
      },
      {
        q: 'How does YIXINOU check a BCM54908EA1IFFBG before it ships?',
        a: 'BGA lots are documented before dispatch, with ball count, package body and markings compared against the order. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Results are kept on file for the shipped lot and can be shared on request.',
      },
    ],
  },
  'BCM6303KMLG': {
    mpn: 'BCM6303KMLG',
    brand: 'Broadcom',
    title: 'xDSL CPE line driver with on-chip regulator in SOIC',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Logic ICs / Buffers, Drivers and Transceivers',
    categoryHref: '/all-products',
    summary: 'The BCM6303KMLG is a Broadcom line driver for xDSL customer premises equipment that integrates an ultra-low-power ADSL2+/VDSL2 analog front end, a line driver and an on-chip regulator. The peer record confirms a SOIC package supplied in trays of 3,430 pieces. It is specified for 0 to +70\u00b0C operation and follows the ITU-T G.992/G.993 xDSL standards. The same record lists this part as RoHS non-compliant, so the exact ordering variant should be confirmed before purchase.',
    img: '/assets/images/bcm6303kmlg-soic.jpg',
    alt: 'A SOIC package, the package used for the BCM6303KMLG',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Device type', 'xDSL CPE line driver with on-chip regulator'],
      ['On-chip blocks', 'ADSL2+/VDSL2 analog front end and line driver'],
      ['Package', 'SOIC'],
      ['Number of receivers', '8'],
      ['Packaging', 'Tray'],
      ['Package quantity', '3,430'],
      ['Operating temperature', '0\u00b0C to +70\u00b0C'],
      ['Standards', 'ITU-T G.992 / G.993'],
      ['RoHS', 'Non-compliant as listed in the referenced data'],
      ['Documentation', 'Released by Broadcom under NDA'],
    ],
    about: 'The BCM6303KMLG is a Broadcom line driver for xDSL customer premises equipment. It combines an ultra-low-power ADSL2+/VDSL2 analog front end, the line driver stage and an on-chip regulator in one SOIC package supplied in trays. The part is specified from 0 to +70\u00b0C and follows the ITU-T G.992 and G.993 xDSL standards. Typical equipment includes xDSL modems, home gateways, VDSL2 access devices and optical network terminal voice lines.',
    standards: ['ITU-T G.992 / G.993', 'ESD-sensitive device \u2014 handle under ESD-protected conditions'],
    features: [
      'Integrated ADSL2+/VDSL2 analog front end and line driver',
      'On-chip regulator reduces the external component count',
      'Ultra-low-power design for always-on customer premises equipment',
      'SOIC package supplied in trays of 3,430',
      'Built around ITU-T G.992 and G.993 xDSL standards',
      'Rated 0 to +70\u00b0C',
      'Referenced data lists RoHS as non-compliant; confirm the ordering variant',
    ],
    applications: [
      'xDSL modems (CPE)',
      'Home gateways',
      'VDSL2 access equipment',
      'Voice line section of optical network terminals',
    ],
    faq: [
      {
        q: 'What is the BCM6303KMLG used for?',
        a: 'It is used in xDSL customer premises equipment, including ADSL2+/VDSL2 modems, home gateways, VDSL2 access devices and the voice line section of optical network terminals. The integrated analog front end and line driver handle the xDSL signal path while the on-chip regulator simplifies the surrounding bill of materials.',
      },
      {
        q: 'What do buyers check before ordering a BCM6303KMLG?',
        a: 'Buyers check that the line driver matches the chosen xDSL SoC and its reference design, because the companion chip determines whether the circuit can be built as intended. They also confirm how far the on-chip regulator reduces the peripheral parts count, review the thermal path of the package since the line driver dissipates power, confirm the RoHS status of the specific ordering variant, and ask about Broadcom documentation under NDA, supply, end-of-life risk and price.',
      },
      {
        q: 'How does YIXINOU check a BCM6303KMLG before it ships?',
        a: 'SOIC lots are checked before dispatch, with the package body and lead count verified against the order and the markings compared with the documentation held on file. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Test results and lot photographs are available on request.',
      },
    ],
  },
  'BGU6104': {
    mpn: 'BGU6104',
    brand: 'NXP Semiconductors',
    title: 'Wideband MMIC RF amplifier with integrated bias and enable in HXSON6',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The BGU6104 is a wideband MMIC RF amplifier from NXP Semiconductors with an integrated bias circuit and an enable function. Operating frequency extends to several GHz and the device accepts a wide supply voltage range, which simplifies biasing in multi-stage RF chains. It is supplied in a 6-pin HXSON6 (SOT1209) package. The BGU6104 is one of the BGU6101/61xx family of three related devices, is listed as RoHS and REACH compliant, and is an ESD-sensitive MMIC.',
    img: '/assets/images/bgu6104-package.jpg',
    alt: 'A 6-pin HXSON6 package, the package used for the BGU6104',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Device type', 'Wideband MMIC RF amplifier'],
      ['On-chip functions', 'Bias circuit and enable control'],
      ['Package', 'HXSON6 / SOT1209, 6 pins'],
      ['Supply voltage', 'Wide range; confirm exact limits in the NXP datasheet'],
      ['Operating frequency', 'Up to several GHz'],
      ['Product family', 'BGU6101 / 61xx family member'],
      ['Reference standards', 'IEC 60134 and JEDEC package standards'],
      ['RoHS', 'Compliant'],
      ['REACH', 'Compliant'],
      ['ESD classification', 'ESD-sensitive device (MMIC)'],
    ],
    about: 'The BGU6104 is a wideband MMIC RF amplifier from NXP Semiconductors that integrates its bias circuitry and an enable control on chip. It covers operating frequencies up to several GHz and works over a wide supply voltage range, which keeps external biasing components to a minimum in receiver and gain-stage designs. It is supplied in a 6-pin HXSON6 (SOT1209) package and belongs to the BGU6101/61xx family. Typical uses include communication receive front ends, CATV amplifiers, general RF gain stages and instrumentation RF links.',
    standards: [
      'NXP BGU6104 datasheet Rev. 2',
      'RoHS compliant',
      'IEC 60134 and JEDEC package standards',
      'REACH compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Wideband MMIC RF amplifier covering frequencies up to several GHz',
      'On-chip bias circuit',
      'Enable control for power-down and gain switching',
      'Wide supply voltage range',
      '6-pin HXSON6 (SOT1209) package',
      'One of the BGU6101/61xx family of three parts',
      'RoHS compliant and REACH compliant',
      'ESD-sensitive MMIC; handle under ESD-protected conditions',
    ],
    applications: [
      'Communication receive front ends',
      'CATV and cable television amplifiers',
      'General-purpose RF gain stages',
      'RF signal chains in instrumentation',
    ],
    faq: [
      {
        q: 'What is the BGU6104 used for?',
        a: 'It is used as a gain block in communication receive front ends, CATV and cable television amplifier stages, general-purpose RF gain paths and instrumentation RF chains. Because the bias circuit and the enable control are on chip, it can be placed into a multi-stage chain with few external parts.',
      },
      {
        q: 'What do buyers check before ordering a BGU6104?',
        a: 'Buyers confirm the exact frequency band, gain and output compression point against the original NXP datasheet, because those values decide whether the part fits the link budget. They also ask whether the internal matching is 50 ohm, which sets how many external components are needed, review linearity and noise figure, check the soldering and grounding of the small 6-pin package, confirm that parts are genuine NXP product that is still active, and look at drop-in alternatives and end-of-life status.',
      },
      {
        q: 'How does YIXINOU check a BGU6104 before it ships?',
        a: 'HXSON6 (SOT1209) lots are verified before dispatch, with package marking, pin count and lot code inspected against the order. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Photographs of the actual lot are available on request.',
      },
    ],
  },
  'CS4344-CZZ': {
    mpn: 'CS4344-CZZ',
    brand: 'Cirrus Logic',
    title: '10-pin, 24-bit, 192kHz stereo audio D/A converter',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Data Converter ICs / Digital to Analog Converters (DACs)',
    categoryHref: '/all-products',
    summary: 'The CS4344-CZZ is a Cirrus Logic stereo digital-to-analog converter in a 10-pin TSSOP surface-mount package. It delivers 24-bit resolution at sampling rates up to 192kHz through a multibit delta-sigma modulator with two channels of voltage output. The device automatically detects the incoming sample rate and includes digital de-emphasis and soft volume control. It runs from a 3V to 5.25V supply over -10 to +70\u00b0C and is supplied in lead-free, RoHS compliant form.',
    img: '/assets/images/cs4344-czz-tssop-10.jpg',
    alt: 'A 10-lead TSSOP package, the package used for the CS4344-CZZ',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package', 'TSSOP-10'],
      ['Number of pins', '10'],
      ['Mounting type', 'Surface Mount'],
      ['Resolution', '24-bit'],
      ['Number of channels', '2 (stereo)'],
      ['Sampling rate', 'Up to 192ksps'],
      ['Interface', 'SPI, Serial'],
      ['Supply voltage', '3V to 5.25V'],
      ['Operating temperature', '-10\u00b0C to +70\u00b0C'],
      ['RoHS', 'Compliant'],
    ],
    about: 'The CS4344-CZZ is a 24-bit stereo digital-to-analog converter from Cirrus Logic, packaged in a 10-lead TSSOP and marked CZZ for the specific package and temperature grade. It uses a multibit delta-sigma modulator, converts at rates up to 192kHz, detects the input sample rate automatically, and provides digital de-emphasis and soft volume control. Output is voltage-mode, so the analog stage normally needs an external low-pass filter and operational amplifier. It is used in audio players, set-top boxes, digital televisions, car audio, USB sound cards and smart speakers.',
    standards: [
      'Cirrus Logic CS4344/45/48 datasheet (CS4344-45-48_F2)',
      'RoHS compliant',
      'JEDEC package standards',
      'Pb-free (lead-free) package',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '24-bit stereo delta-sigma digital-to-analog converter',
      'Sampling rates up to 192kHz',
      'Automatic detection of the input sample rate',
      'Digital de-emphasis and soft volume control',
      'Voltage output with a 3V to 5.25V supply',
      'SPI and serial control interface',
      '10-pin TSSOP package, lead-free and RoHS compliant',
      'Rated -10 to +70\u00b0C',
    ],
    applications: [
      'Audio playback devices',
      'Set-top boxes',
      'Digital televisions',
      'Car audio systems',
      'USB sound cards',
      'Smart speakers',
    ],
    faq: [
      {
        q: 'What is the CS4344-CZZ used for?',
        a: 'It converts digital audio to stereo analog output in audio players, set-top boxes, digital televisions, car audio systems, USB sound cards and smart speakers. It handles 24-bit data at up to 192kHz, detects the incoming sample rate automatically, and performs de-emphasis and volume control in the digital domain before the analog output stage.',
      },
      {
        q: 'What do buyers check before ordering a CS4344-CZZ?',
        a: 'Buyers check the difference between the CZZ version and other CS4344 ordering codes, because the suffix identifies a specific package and temperature grade that must be confirmed with the supplier. They also compare the part against related devices such as the CS4345 and CS4354, plan the external low-pass filter and operational amplifier required by the voltage output, and verify that the master clock matches the intended sample rate. Price and supply are reviewed last.',
      },
      {
        q: 'How does YIXINOU check a CS4344-CZZ before it ships?',
        a: 'TSSOP-10 lots are inspected before dispatch, with package marking and pin count checked against the order and the CZZ suffix confirmed against the manufacturer documentation. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Lot photographs and check results are available on request.',
      },
    ],
  },
  'EG91AUXGA-128-SGNS': {
    mpn: 'EG91AUXGA-128-SGNS',
    brand: 'Quectel',
    title: 'LTE Cat 1 M2M and IoT module, Australian band variant, LGA',
    category: 'Module',
    categoryHref: '/all-products',
    summary: 'The EG91AUXGA-128-SGNS is a Quectel EG91 series LTE Cat 1 wireless module built on 3GPP Release 11 LTE technology. It supports LTE-FDD, WCDMA and GSM multimode operation with a maximum downlink of 10 Mbps and a maximum uplink of 5 Mbps. The AUXGA version covers the Australian frequency band combination, and 128-SGNS is the memory configuration and supply version code. It is supplied in an LGA package with an AT command set compatible with the Quectel general command set, and it targets M2M and IoT applications.',
    img: '/assets/images/eg91auxga-128-sgns-package.jpg',
    alt: 'An LGA package, the package used for the EG91AUXGA-128-SGNS',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Module type', 'LTE Cat 1 wireless communication module'],
      ['Cellular technology', '3GPP Release 11 LTE'],
      ['Maximum downlink', '10 Mbps'],
      ['Maximum uplink', '5 Mbps'],
      ['Supported modes', 'LTE-FDD / WCDMA / GSM multimode'],
      ['Region variant', 'AUXGA, Australian frequency band combination'],
      ['Ordering code', '128-SGNS, memory configuration and supply version code'],
      ['Package', 'LGA'],
      ['Command set', 'AT commands compatible with the Quectel general command set'],
      ['Target use', 'M2M and IoT applications'],
    ],
    about: 'The EG91AUXGA-128-SGNS is an LTE Cat 1 module from the Quectel EG91 series. It uses 3GPP Release 11 LTE technology and works in LTE-FDD, WCDMA and GSM multimode, with peak rates of 10 Mbps downlink and 5 Mbps uplink. The AUXGA code marks the Australian band combination and 128-SGNS the memory configuration and supply version, so the module is intended for Australia and New Zealand IoT terminals. It comes in an LGA package with a Quectel-compatible AT command set and is built for M2M and IoT applications.',
    standards: [
      'Quectel_EG91_Series_LTE_Standard_Specification V2.8',
      '3GPP Release 11',
      'RoHS compliant',
      'GCF/PTCRB and major operator approvals (AUX version for Australian bands)',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'LTE Cat 1 module based on 3GPP Release 11',
      'Up to 10 Mbps downlink and 5 Mbps uplink',
      'LTE-FDD, WCDMA and GSM multimode support',
      'AUXGA variant for Australian band combinations',
      '128-SGNS memory configuration and supply version code',
      'AT command set compatible with the Quectel general command set',
      'LGA package for compact M2M and IoT designs',
    ],
    applications: [
      'Shared equipment',
      'POS terminals',
      'Smart meters',
      'Vehicle trackers',
      'Industrial gateways',
      'IoT terminals for the Australian and New Zealand markets',
    ],
    faq: [
      {
        q: 'What is the EG91AUXGA-128-SGNS used for?',
        a: 'It is used in shared equipment, POS terminals, smart meters, vehicle trackers, industrial gateways and other IoT terminals for the Australian and New Zealand markets. The Cat 1 radio provides 10 Mbps downlink and 5 Mbps uplink, which matches the data volumes of metering, payment and tracking applications.',
      },
      {
        q: 'What do buyers check before ordering an EG91AUXGA-128-SGNS?',
        a: 'Buyers first confirm the band variant, because AU marks the Australian band combination and a version for the wrong market will not register on the target network. They also check operator certification and network access approvals, review the PCB and soldering requirements of the LGA package, plan the antenna and RF layout, confirm firmware and AT command compatibility with the existing design, and review supply, price and long-term supply commitments.',
      },
      {
        q: 'How does YIXINOU check an EG91AUXGA-128-SGNS before it ships?',
        a: 'LGA modules are checked before dispatch, with the module label, ordering code, band variant and firmware version compared against the order, and the package and solder pads inspected. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Labelled photographs of the shipped lot are kept on file.',
      },
    ],
  },
  'EPM240T100C5N': {
    mpn: 'EPM240T100C5N',
    brand: 'Intel',
    title: 'MAX II CPLD with 240 logic elements in TQFP-100',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Programming Logic Devices (PLDs)',
    categoryHref: '/all-products',
    summary: 'The EPM240T100C5N is an Intel MAX II CPLD with 240 logic elements and 192 macro cells in a 100-pin TQFP surface-mount package. It provides 80 user I/O and runs at up to 201.1MHz from a 2.375V to 3.6V supply. The commercial temperature range is 0 to +85\u00b0C and the -5 speed grade applies to this ordering code. Configuration is stored in on-chip flash. Lifecycle status is NRND, so new designs usually move to MAX 10 or another CPLD family.',
    img: '/assets/images/epm240t100c5n-tqfp-100.jpg',
    alt: 'A 100-pin TQFP package, the package used for the EPM240T100C5N',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package', 'TQFP-100'],
      ['Number of pins', '100'],
      ['Mounting type', 'Surface Mount'],
      ['Series', 'MAX II'],
      ['Logic elements', '240 logic elements, 192 macro cells'],
      ['Number of I/Os', '80'],
      ['Maximum frequency', '201.1MHz'],
      ['Supply voltage', '2.375V to 3.6V'],
      ['Operating temperature', '0\u00b0C to +85\u00b0C'],
      ['Lifecycle status', 'NRND'],
    ],
    about: 'The EPM240T100C5N is a MAX II family CPLD from Intel with 240 logic elements and 192 macro cells, supplied in a 100-pin TQFP package with 80 user I/O pins. It runs at up to 201.1MHz from a 2.375V to 3.6V supply and is rated for the commercial range of 0 to +85\u00b0C. The N suffix marks the lead-free version, which distinguishes it from older ordering codes. It is commonly used for interface conversion and bridging, power-up sequencing, bus glue logic, legacy equipment maintenance and industrial control.',
    standards: [
      'RoHS compliant',
      'Lead-free (N suffix) package',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'MAX II CPLD with 240 logic elements and 192 macro cells',
      '80 user I/O in a 100-pin TQFP package',
      'Operation up to 201.1MHz',
      '2.375V to 3.6V supply',
      'On-chip flash configuration memory',
      'Commercial temperature range of 0 to +85\u00b0C',
      'N suffix denotes the lead-free version',
      'Lifecycle status NRND; plan a MAX 10 or other CPLD migration for new designs',
    ],
    applications: [
      'Interface conversion and bridging',
      'Power-up sequencing',
      'Bus glue logic',
      'Legacy equipment maintenance',
      'Industrial control',
    ],
    faq: [
      {
        q: 'What is the EPM240T100C5N used for?',
        a: 'It is used for interface conversion and bridging, power-up sequencing, bus glue logic, legacy equipment maintenance and industrial control. The 80 user I/O and 240 logic elements in a TQFP-100 package suit boards that need fixed glue logic rather than a full FPGA.',
      },
      {
        q: 'What do buyers check before ordering an EPM240T100C5N?',
        a: 'Buyers confirm the I/O count available in the TQFP-100 package and whether the commercial 0 to +85\u00b0C range is enough for the target enclosure. Because the MAX II family has reached end of life, they also plan a migration path to MAX 10 or another CPLD family, which requires a redesign, distinguish the lead-free N suffix from older codes, and check that stock is genuine Intel product rather than refurbished old CPLD material, along with price and inventory age.',
      },
      {
        q: 'How does YIXINOU check an EPM240T100C5N before it ships?',
        a: 'TQFP-100 lots are checked before dispatch, with package marking, pin count and date codes reviewed against the order, because older CPLD stock is often refurbished. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Lot photographs and inspection notes are held for each shipment.',
      },
    ],
  },
  'ESP32-S3R8': {
    mpn: 'ESP32-S3R8',
    brand: 'Espressif',
    title: 'Dual-core Xtensa LX7 Wi-Fi and Bluetooth SoC with 8MB PSRAM, QFN-56',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The ESP32-S3R8 is an Espressif SoC that pairs a dual-core 32-bit Xtensa LX7 processor running at up to 240MHz with 2.4GHz Wi-Fi (IEEE 802.11 b/g/n) and Bluetooth 5 (LE). The R8 suffix marks 8MB of PSRAM integrated on chip alongside 512KB of SRAM. It provides 45 GPIO and interfaces for USB OTG, TWAI (CAN) and LCD panels, and it supports either 1.8V or 3.3V flash and PSRAM. The part is supplied in a QFN-56 package measuring 7x7mm.',
    img: '/assets/images/esp32-s3r8-package.jpg',
    alt: 'A 56-pin QFN package, the package used for the ESP32-S3R8',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Device type', 'Wi-Fi and Bluetooth SoC with integrated MCU'],
      ['Processor core', 'Dual-core Xtensa 32-bit LX7'],
      ['Maximum clock', '240MHz'],
      ['On-chip memory', '512KB SRAM plus 8MB PSRAM (R8 suffix)'],
      ['Wireless', '2.4GHz Wi-Fi (IEEE 802.11 b/g/n) and Bluetooth 5 (LE)'],
      ['GPIO count', '45'],
      ['Package', 'QFN-56, 7x7mm'],
      ['Flash and PSRAM voltage', '1.8V or 3.3V'],
      ['Interfaces', 'USB OTG, TWAI (CAN) controller, LCD interface'],
      ['CAN standard', 'ISO 11898 via the TWAI controller'],
    ],
    about: 'The ESP32-S3R8 is a wireless system on chip from Espressif built around a dual-core 32-bit Xtensa LX7 processor that runs at up to 240MHz. It integrates 2.4GHz Wi-Fi to IEEE 802.11 b/g/n, Bluetooth 5 (LE) and 8MB of PSRAM in the R8 variant, together with 512KB of SRAM, 45 GPIO, USB OTG, a TWAI (CAN) controller and an LCD interface. Typical uses are AI voice interaction devices, smart home hubs, image recognition terminals, HMI screens and edge AI inference nodes.',
    standards: [
      'Espressif ESP32-S3 Series Datasheet Version 2.2',
      'RoHS compliant',
      'JEDEC JESD22 packaging and ESD standards',
      'JESD47 reliability qualification and JESD78 latch-up testing',
      'REACH compliant',
      'IEEE 802.11 b/g/n and Bluetooth 5 (LE) radio specifications',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Dual-core 32-bit Xtensa LX7 running at up to 240MHz',
      '8MB PSRAM on chip (R8 suffix) plus 512KB SRAM',
      '2.4GHz Wi-Fi (IEEE 802.11 b/g/n) and Bluetooth 5 (LE)',
      '45 GPIO available',
      'USB OTG, TWAI (CAN) controller and LCD interface',
      'Supports 1.8V or 3.3V flash and PSRAM',
      'QFN-56 package measuring 7x7mm',
      'Supports AI vector instructions and the ESP-DL framework',
    ],
    applications: [
      'AI voice interaction devices',
      'Smart home control hubs',
      'Image recognition terminals',
      'HMI screens',
      'Edge AI inference nodes',
    ],
    faq: [
      {
        q: 'What is the ESP32-S3R8 used for?',
        a: 'It is used in AI voice interaction devices, smart home control hubs, image recognition terminals, HMI panels and edge AI inference nodes. The dual-core LX7 processor, 8MB of PSRAM and the image and LCD interfaces let one chip handle wireless connectivity, a user interface and light on-device inference.',
      },
      {
        q: 'What do buyers check before ordering an ESP32-S3R8?',
        a: 'Buyers confirm that the R8 suffix, which means 8MB of on-chip PSRAM, is the version the design needs, because the price difference against parts without PSRAM is significant. They also check AI vector instruction and ESP-DL framework support, plan the antenna design and RF certification, decide between the bare SoC and an ESP32-S3-WROOM module, and review the thermal and power behaviour of a design with large PSRAM, along with price and supply.',
      },
      {
        q: 'How does YIXINOU check an ESP32-S3R8 before it ships?',
        a: 'QFN-56 (7x7mm) lots are checked before dispatch, with the package body, pin count and marking compared against the order, and the R8 suffix confirmed. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Lot photographs are available with the shipment documentation.',
      },
    ],
  },
  'ESP8266EX': {
    mpn: 'ESP8266EX',
    brand: 'Espressif',
    title: 'High-integration Wi-Fi SoC with Tensilica L106 core in QFN-32',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The ESP8266EX is an Espressif Wi-Fi system on chip built on a Tensilica L106 32-bit RISC core running at up to 160MHz, with integrated 2.4GHz Wi-Fi to IEEE 802.11 b/g/n. It comes in a QFN-32 package measuring 5x5mm, operates from 2.5V to 3.6V, and is rated for -40 to +85\u00b0C, with some ordering variants listed to 125\u00b0C. The chip includes SRAM and an SPI flash interface and supports external SPI flash up to 16MB. The datasheet notes that the VDDPST power domain range was updated from 1.8 to 3.3V to 1.8 to 3.6V, and the device is marked not recommended for new designs, with ESP8684 suggested instead.',
    img: '/assets/images/esp8266ex-package.jpg',
    alt: 'A 32-pin QFN package, the package used for the ESP8266EX',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Device type', 'Wi-Fi SoC with integrated MCU'],
      ['Processor core', 'Tensilica L106 32-bit RISC'],
      ['Maximum clock', '160MHz'],
      ['Wireless', '2.4GHz Wi-Fi (IEEE 802.11 b/g/n)'],
      ['On-chip memory', 'SRAM plus SPI flash interface'],
      ['External flash support', 'SPI flash up to 16MB (external)'],
      ['Package', 'QFN-32, 5x5mm'],
      ['Supply voltage', '2.5V to 3.6V'],
      ['Operating temperature', '-40\u00b0C to +85\u00b0C, with some variants listed to +125\u00b0C'],
      ['Lifecycle status', 'Not recommended for new designs; ESP8684 suggested'],
    ],
    about: 'The ESP8266EX is a highly integrated Espressif Wi-Fi SoC that embeds a Tensilica L106 32-bit RISC core running at up to 160MHz together with 2.4GHz Wi-Fi to IEEE 802.11 b/g/n. It comes in a QFN-32 package measuring 5x5mm, works from a 2.5V to 3.6V supply and is rated for -40 to +85\u00b0C on the standard versions. The chip provides SRAM and an SPI flash interface and can drive external SPI flash of up to 16MB. Typical uses are smart home devices, smart sockets, sensor gateways, Wi-Fi modules such as ESP-01 and ESP-12, and industrial IoT nodes.',
    standards: [
      'Espressif ESP8266EX Datasheet Version 7.1',
      'RoHS compliant',
      'JEDEC packaging and ESD standards',
      'REACH compliant',
      'IEEE 802.11 b/g/n and Wi-Fi Alliance certification framework',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Tensilica L106 32-bit RISC core at up to 160MHz',
      'Integrated 2.4GHz Wi-Fi to IEEE 802.11 b/g/n',
      'SRAM on chip plus an SPI flash interface',
      'Supports external SPI flash up to 16MB',
      '2.5V to 3.6V supply',
      'Rated -40 to +85\u00b0C, with some variants listed to +125\u00b0C',
      'QFN-32 package measuring 5x5mm',
      'Datasheet note: VDDPST power domain updated from 1.8 to 3.3V to 1.8 to 3.6V',
    ],
    applications: [
      'Smart home devices',
      'Smart sockets',
      'Sensor gateways',
      'Wi-Fi modules such as ESP-01 and ESP-12',
      'Industrial IoT nodes',
    ],
    faq: [
      {
        q: 'What is the ESP8266EX used for?',
        a: 'It is used in smart home products, smart sockets, sensor gateways, Wi-Fi modules such as ESP-01 and ESP-12, and industrial IoT nodes. The L106 core and integrated Wi-Fi radio handle both the application code and the network connection, while external SPI flash of up to 16MB stores the firmware.',
      },
      {
        q: 'What do buyers check before ordering an ESP8266EX?',
        a: 'Buyers confirm which external SPI flash capacity is needed, because the ESP8266EX has no internal flash and must be paired with a flash device. They also check RF certification such as CE, FCC and SRRC together with the module plan, verify that parts are genuine Espressif product rather than cloned module material, choose between the bare chip and an ESP-WROOM module, and confirm whether the design should move to the ESP32-C series instead. Price and minimum order quantity are reviewed last.',
      },
      {
        q: 'How does YIXINOU check an ESP8266EX before it ships?',
        a: 'QFN-32 (5x5mm) lots are verified before dispatch through marking, pin count and package inspection against the order. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Inspection records are kept for the shipped lot and shared on request.',
      },
    ],
  },
  'FS100R12KT4G': {
    mpn: 'FS100R12KT4G',
    brand: 'Infineon',
    title: '1200V, 100A IGBT module in EconoPACK 2, six-pack topology',
    category: 'Module',
    categoryHref: '/all-products',
    summary: 'The FS100R12KT4G is an Infineon IGBT power module rated at 1200V and 100A in a six-pack three-phase full bridge topology, with a PIM three-unit form also referenced for this ordering code. It uses Trench/Fieldstop IGBT4 technology in an EconoPACK 2 package and is specified for -40 to +150\u00b0C operation. The module is designed to IEC 60747 and is RoHS compliant. It suits industrial inverters, motor drives, photovoltaic inverters, UPS systems, servo drives and elevator and hoisting equipment.',
    img: '/assets/images/fs100r12kt4g-package.jpg',
    alt: 'An EconoPACK 2 package, the package used for the FS100R12KT4G',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Device type', 'IGBT power module'],
      ['Collector-emitter voltage', '1200V'],
      ['Current rating', '100A'],
      ['Circuit topology', 'Six-pack three-phase full bridge; PIM three-unit topology also referenced'],
      ['IGBT technology', 'Trench/Fieldstop IGBT4'],
      ['Switches per module', 'Six'],
      ['Package', 'EconoPACK 2'],
      ['Operating temperature', '-40\u00b0C to +150\u00b0C'],
      ['Standards', 'IEC 60747'],
      ['RoHS', 'Compliant'],
    ],
    about: 'The FS100R12KT4G is a 1200V, 100A IGBT module from Infineon built on Trench/Fieldstop IGBT4 technology and supplied in the EconoPACK 2 package. It is offered in a six-pack three-phase full bridge configuration, with a PIM three-unit topology also listed for this ordering code, and it is specified for operation from -40 to +150\u00b0C. The module follows IEC 60747 and is RoHS compliant. Typical applications are industrial frequency converters, motor drives, photovoltaic inverters, UPS systems, servo drives and elevator and hoisting equipment.',
    standards: [
      'IEC 60747',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '1200V collector-emitter rating with 100A current capability',
      'Trench/Fieldstop IGBT4 technology',
      'Six-pack three-phase full bridge topology',
      'EconoPACK 2 package',
      'Operating range of -40 to +150\u00b0C',
      'Designed to IEC 60747 and RoHS compliant',
      'Suited to high-power motor drive and inverter designs',
    ],
    applications: [
      'Industrial frequency converters',
      'Motor drives',
      'Photovoltaic inverters',
      'UPS systems',
      'Servo drives',
      'Elevator and hoisting equipment',
    ],
    faq: [
      {
        q: 'What is the FS100R12KT4G used for?',
        a: 'It is used in industrial frequency converters, motor drives, photovoltaic inverters, UPS systems, servo drives and elevator and hoisting equipment. The six-pack topology builds a complete three-phase inverter stage, and the 1200V / 100A rating covers medium-power industrial drives.',
      },
      {
        q: 'What do buyers check before ordering an FS100R12KT4G?',
        a: 'Buyers first match the circuit topology, because a PIM, six-pack or half-bridge module is not interchangeable with a different circuit design. They also review the thermal design, including the baseplate, thermal grease and heatsink thermal resistance, which determine module lifetime, and check switching losses against the gate drive resistor selection and current sharing when modules are paralleled. Because refurbished and salvaged Infineon IGBT modules are common, they also verify that parts are genuine, and they weigh the high price and long lead times.',
      },
      {
        q: 'How does YIXINOU check an FS100R12KT4G before it ships?',
        a: 'EconoPACK 2 modules are checked before dispatch, with terminal condition, baseplate, mounting holes and markings verified against the order. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Photographs of the actual module are provided with the shipment records.',
      },
    ],
  },
  'H54G68CYRBX248': {
    mpn: 'H54G68CYRBX248',
    brand: 'SK hynix',
    title: 'LPDDR4X SDRAM 64Gb (8GB) die with a 32-bit bus in BGA-200',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / LPDDR',
    categoryHref: '/all-products',
    summary: 'The H54G68CYRBX248 is an SK hynix LPDDR4X SDRAM device with a 64Gb (8GB) density in a 2Gx32 organisation and a 32-bit wide data bus. It runs at 4266Mbps with VDD1 at 1.8V, VDD2 at 1.1V and VDDQ at 0.6V, and is supplied in a 200-ball BGA package. The referenced data gives an operating temperature range of 0 to +85\u00b0C. It is used in flagship phones, tablets, Chromebooks, automotive cockpit domain controllers and edge AI and AR/VR devices.',
    img: '/assets/images/h54g68cyrbx248-bga-200.jpg',
    alt: 'A 200-ball BGA package, the package used for the H54G68CYRBX248',
    imageNote: 'Illustrative package image. Ask us for a photograph of the actual lot.',
    specs: [
      ['Device type', 'LPDDR4X SDRAM'],
      ['Density', '64Gb (8GB), 2Gx32 organisation'],
      ['Data rate', '4266Mbps'],
      ['Bus width', '32-bit (x32)'],
      ['Package', 'BGA-200'],
      ['Mounting type', 'Surface Mount'],
      ['Supply voltage', 'VDD1 1.8V, VDD2 1.1V, VDDQ 0.6V'],
      ['Series', 'H54G'],
      ['Operating temperature', '0\u00b0C to +85\u00b0C'],
      ['Reference standard', 'JESD209-4'],
    ],
    about: 'The H54G68CYRBX248 is a 64Gb (8GB) LPDDR4X SDRAM die from SK hynix organised as 2Gx32 with a 32-bit data bus. It operates at 4266Mbps with VDD1 at 1.8V, VDD2 at 1.1V and VDDQ at 0.6V, follows the JESD209-4 LPDDR4X reference standard, and comes in a 200-ball BGA package rated from 0 to +85\u00b0C. Typical uses include flagship smartphones, tablets, Chromebooks, automotive cockpit domain controllers and edge AI or AR/VR devices.',
    standards: ['JESD209-4', 'ESD-sensitive device \u2014 handle under ESD-protected conditions'],
    features: [
      'LPDDR4X SDRAM with a 64Gb (8GB) density',
      '2Gx32 organisation on a 32-bit data bus',
      '4266Mbps data rate',
      'VDD1 1.8V, VDD2 1.1V and VDDQ 0.6V rails',
      '200-ball BGA package',
      '0 to +85\u00b0C operating range',
      'Built to the JESD209-4 LPDDR4X reference standard',
    ],
    applications: [
      'Flagship smartphones',
      'Tablets',
      'Chromebooks',
      'Automotive cockpit domain controllers',
      'Edge AI and AR/VR devices',
    ],
    faq: [
      {
        q: 'What is the H54G68CYRBX248 used for?',
        a: 'It is used in flagship smartphones, tablets, Chromebooks, automotive cockpit domain controllers and edge AI or AR/VR devices. A single 64Gb (8GB) die gives a large capacity in one package, and the 4266Mbps LPDDR4X interface provides the memory bandwidth those platforms expect.',
      },
      {
        q: 'What do buyers check before ordering an H54G68CYRBX248?',
        a: 'Buyers confirm that the host SoC supports the capacity of a single 8GB die, because large single-package capacity depends on the memory controller limit. They check the platform qualified vendor list for Chromebook and phone designs, verify that parts are original die rather than downgraded material, since this part number has been seen in white-label form, and review the thermal and reliability behaviour of the stacked package, batch consistency and long-term supply.',
      },
      {
        q: 'How does YIXINOU check an H54G68CYRBX248 before it ships?',
        a: 'BGA-200 lots are verified before dispatch, with ball count, package dimensions, marking and date code compared against the order. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Results are filed against the lot and supplied with the shipment on request.',
      },
    ],
  },
  'H5CG46MEBDX015N': {
    mpn: 'H5CG46MEBDX015N',
    brand: 'SK hynix',
    title: 'DDR5 SDRAM 16Gb die at 4800Mbps in FCBGA-106',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / DDR',
    categoryHref: '/all-products',
    summary: 'The H5CG46MEBDX015N is an SK hynix DDR5 SDRAM device with a 16Gb density and a 4800Mbps data rate. It operates from a 1.045V to 1.155V supply with a 1.8V VPP rail and is supplied in a 106-ball FCBGA package that mounts on the surface of the board. It uses a synchronous interface and is rated from 0 to +95\u00b0C. The part is built to the JESD79-5 DDR5 reference standard and is used in server and workstation memory modules, industrial computers, edge servers and data centre equipment.',
    img: '/assets/images/h5cg46mebdx015n-fcbga-106.jpg',
    alt: 'A 106-ball FCBGA package, the package used for the H5CG46MEBDX015N',
    imageNote: 'Illustrative package image. Ask us for a photograph of the actual lot.',
    specs: [
      ['Device type', 'DDR5 SDRAM, synchronous'],
      ['Density', '16Gb'],
      ['Data rate', '4800Mbps'],
      ['Package', 'FCBGA-106'],
      ['Number of pins', '106'],
      ['Mounting type', 'Surface Mount'],
      ['Supply voltage', '1.045V to 1.155V; VPP 1.8V'],
      ['Series', 'H5CG'],
      ['Operating temperature', '0\u00b0C to +95\u00b0C'],
      ['Reference standard', 'JESD79-5'],
    ],
    about: 'The H5CG46MEBDX015N is a 16Gb DDR5 SDRAM die from SK hynix in a 106-ball FCBGA package. It runs at 4800Mbps, uses a synchronous interface with a 1.045V to 1.155V supply and a 1.8V VPP rail, and is specified over 0 to +95\u00b0C. The device is built to the JESD79-5 DDR5 reference standard. Typical applications are DDR5 memory modules for servers and workstations, industrial computers, edge servers and data centre equipment.',
    standards: ['JESD79-5', 'ESD-sensitive device \u2014 handle under ESD-protected conditions'],
    features: [
      'DDR5 SDRAM with a 16Gb density',
      '4800Mbps data rate',
      '106-ball FCBGA package',
      '1.045V to 1.155V supply with a 1.8V VPP rail',
      'Synchronous interface',
      '0 to +95\u00b0C operating range',
      'Built to the JESD79-5 DDR5 reference standard',
    ],
    applications: [
      'Server and workstation DDR5 memory modules',
      'Industrial computers',
      'Edge servers',
      'Data centre equipment',
    ],
    faq: [
      {
        q: 'What is the H5CG46MEBDX015N used for?',
        a: 'It is used on DDR5 memory modules for servers and workstations, and in industrial computers, edge servers and data centre equipment. The 16Gb density at 4800Mbps provides the capacity and bandwidth platform memory needs, from server modules to compact edge systems.',
      },
      {
        q: 'What do buyers check before ordering an H5CG46MEBDX015N?',
        a: 'Buyers check platform compatibility, because a 4800Mbps part runs at a reduced speed on a 5600 platform. They also verify that parts are original die rather than downgraded material, confirm how on-die ECC works together with the system ECC scheme, and review platform qualification, batch consistency, price and lead time.',
      },
      {
        q: 'How does YIXINOU check an H5CG46MEBDX015N before it ships?',
        a: 'FCBGA-106 lots are checked before dispatch, with ball count, marking, package condition and date code verified against the order. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Inspection records travel with the shipment and lot photographs are available on request.',
      },
    ],
  },
  'H5CG48MEBDX014N': {
    mpn: 'H5CG48MEBDX014N',
    brand: 'SK hynix',
    title: 'DDR5 SDRAM 16Gb x8 memory die in a 78-ball FCBGA package',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / DDR',
    categoryHref: '/all-products',
    summary: 'The H5CG48MEBDX014N is an SK Hynix DDR5 SDRAM die with a 16Gb density and a x8 data bus, supplied in a 78-ball FCBGA package for surface mounting. It carries a 4800 MHz speed grade and runs from a 1.1 V VDD/VDDQ rail with a separate 1.8 V VPP supply, inside a 1.045 V to 1.155 V supply window. The rated operating range is 0 \u00b0C to 85 \u00b0C and the design follows the JEDEC JESD79-5 DDR5 standard. Typical uses are server RDIMM modules, enterprise storage, industrial computers and AI training or inference servers.',
    img: '/assets/images/h5cg48mebdx014n-fcbga-78.jpg',
    alt: 'A 78-ball FCBGA package, the package used for the H5CG48MEBDX014N',
    imageNote: 'Illustrative package image. Ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'FCBGA'],
      ['Number of pins', '78'],
      ['Mounting type', 'Surface mount'],
      ['Memory size', '16Gb'],
      ['Memory technology', 'DDR5 SDRAM'],
      ['Data bus width', 'x8'],
      ['Speed grade', '4800 MHz'],
      ['Supply voltage', '1.1 V (VDD/VDDQ), 1.8 V (VPP)'],
      ['Supply voltage window', '1.045 V to 1.155 V'],
      ['Operating temperature', '0 \u00b0C to 85 \u00b0C'],
    ],
    about: 'The H5CG48MEBDX014N is a DDR5 SDRAM device from SK Hynix in a 16Gb density with a x8 organisation, packaged as a 78-ball FCBGA for surface mounting. It is specified for a 4800 MHz speed grade, a 1.1 V VDD/VDDQ supply with a 1.8 V VPP rail, and a supply window of 1.045 V to 1.155 V across an operating range of 0 \u00b0C to 85 \u00b0C. The part follows the JEDEC JESD79-5 DDR5 standard. It is intended for server RDIMM memory modules, enterprise storage systems, industrial computers, and AI training or inference servers, as a 16Gb x8 DDR5 die per module rank.',
    standards: ['JEDEC JESD79-5'],
    features: [
      'DDR5 SDRAM in a 16Gb density with a x8 data bus',
      '4800 MHz speed grade for DDR5 module builds',
      '1.1 V VDD/VDDQ supply with a separate 1.8 V VPP rail',
      'Supply window of 1.045 V to 1.155 V',
      '78-ball FCBGA package for surface mounting',
      'Operating range of 0 \u00b0C to 85 \u00b0C',
      'Designed to the JEDEC JESD79-5 DDR5 standard',
    ],
    applications: [
      'Server RDIMM memory modules',
      'Enterprise storage systems',
      'Industrial computers',
      'AI training and inference servers',
    ],
    faq: [
      {
        q: 'What is the H5CG48MEBDX014N used for?',
        a: 'It is a 16Gb x8 DDR5 SDRAM die used in server RDIMM memory modules, enterprise storage systems, industrial computers, and AI training or inference servers, where a 4800 MHz DDR5 speed grade and a 1.1 V rail are required.',
      },
      {
        q: 'What do buyers check before ordering an H5CG48MEBDX014N?',
        a: 'Buyers normally confirm how 4800 and 5600 speed grades can be substituted or mixed, because DDR5 mixed populations drop to the slower rate; whether the die is original or a downgraded part; On-Die ECC support; compatibility certification with the target motherboard or CPU; price volatility and price locking; and lot-to-lot consistency.',
      },
      {
        q: 'How does YIXINOU check an H5CG48MEBDX014N before it ships?',
        a: 'For each 78-ball FCBGA lot we review the marking, packing and lot code against the order and confirm the quantity before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Ask us for a photograph of the actual lot before you commit.',
      },
    ],
  },
  'H5TC4G63EFR-PBA': {
    mpn: 'H5TC4G63EFR-PBA',
    brand: 'SK hynix',
    title: 'DDR3L SDRAM, 4Gb x16, 1600 MHz in a 96-ball FBGA package',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / DDR',
    categoryHref: '/all-products',
    summary: 'The H5TC4G63EFR-PBA is an SK Hynix DDR3L SDRAM in a 4Gb density with a x16 organisation, supplied in a 96-ball FBGA package for surface mounting. It runs a 1600 MHz speed grade (DDR3-1600, CL11) from a 1.35 V supply that is also usable in 1.5 V DDR3 designs, within a 1.283 V to 1.45 V supply window. The peer page record rates the part from -40 \u00b0C to 105 \u00b0C, and the design follows the JEDEC JESD79-3 standard. It is used in industrial control boards, network equipment, set-top boxes, advertising displays, in-car entertainment and DDR3 platform memory modules.',
    img: '/assets/images/h5tc4g63efr-pba-fbga-96.jpg',
    alt: 'A 96-ball FBGA package, the package used for the H5TC4G63EFR-PBA',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'FBGA'],
      ['Number of pins', '96'],
      ['Mounting type', 'Surface mount'],
      ['Memory size', '4Gb'],
      ['Memory technology', 'DDR3L SDRAM'],
      ['Data bus width', 'x16'],
      ['Speed grade', '1600 MHz (DDR3-1600, CL11)'],
      ['Supply voltage', '1.35 V (1.5 V compatible)'],
      ['Supply voltage window', '1.283 V to 1.45 V'],
      ['Operating temperature', '-40 \u00b0C to 105 \u00b0C'],
    ],
    about: 'The H5TC4G63EFR-PBA is a DDR3L SDRAM device from SK Hynix in a 4Gb density with a x16 organisation, packaged as a 96-ball FBGA for surface mounting. It is specified for a 1600 MHz speed grade (DDR3-1600, CL11) with a 1.35 V supply that also works in 1.5 V DDR3 designs, and a supply window of 1.283 V to 1.45 V. The peer page record gives an operating range of -40 \u00b0C to 105 \u00b0C, and the part follows the JEDEC JESD79-3 standard. It is used on industrial control boards, network equipment, set-top boxes, advertising displays, in-car entertainment systems, and DDR3 platform memory modules.',
    standards: ['JEDEC JESD79-3'],
    features: [
      'DDR3L SDRAM in a 4Gb density with a x16 data bus',
      '1600 MHz speed grade, DDR3-1600 with CL11 latency',
      '1.35 V operation with 1.5 V DDR3 compatibility',
      'Supply window of 1.283 V to 1.45 V',
      '96-ball FBGA package for surface mounting',
      'Operating range of -40 \u00b0C to 105 \u00b0C',
      'Designed to the JEDEC JESD79-3 standard',
    ],
    applications: [
      'Industrial control motherboards',
      'Network equipment',
      'Set-top boxes',
      'Advertising displays',
      'In-car entertainment systems',
      'DDR3 platform memory modules',
    ],
    faq: [
      {
        q: 'What is the H5TC4G63EFR-PBA used for?',
        a: 'It is a 4Gb x16 DDR3L SDRAM die used on industrial control motherboards, network equipment, set-top boxes, advertising displays, in-car entertainment systems, and DDR3 platform memory modules where a 1600 MHz DDR3L die is needed.',
      },
      {
        q: 'What do buyers check before ordering an H5TC4G63EFR-PBA?',
        a: 'Buyers check the compatibility and mixing risk between the 1.35 V DDR3L and 1.5 V DDR3 rails; whether the part has reached end of life and which replacement is available; the price gap between original and white-label die; the bandwidth and routing differences between x16 and x8 organisations; whether an industrial or a commercial temperature grade is needed; and lot-to-lot consistency.',
      },
      {
        q: 'How does YIXINOU check an H5TC4G63EFR-PBA before it ships?',
        a: 'Each 96-ball FBGA lot is checked against the order for marking, lot code and quantity before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Photographs of the actual lot are available on request.',
      },
    ],
  },
  'H9HCNNNBKMMLXR-NEE': {
    mpn: 'H9HCNNNBKMMLXR-NEE',
    brand: 'SK hynix',
    title: 'LPDDR4X SDRAM 16Gb x32 in a 200-ball FBGA package',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / LPDDR',
    categoryHref: '/all-products',
    summary: 'The H9HCNNNBKMMLXR-NEE is an SK Hynix LPDDR4X SDRAM in a 16Gb density with a x32 data bus, supplied in a 200-ball FBGA package for surface mounting. It runs at a 2.133 GHz clock, which corresponds to a 4266 Mbps data rate, from a 1.7 V to 1.95 V VDD1 rail and a 1.06 V to 1.17 V VDD2 rail. The rated operating range is -25 \u00b0C to 85 \u00b0C and the design follows the JEDEC JESD209-4 standard. It is used in flagship and mid-to-high-end smartphones, tablets, automotive cockpits, AR and VR devices, and edge AI boxes.',
    img: '/assets/images/h9hcnnnbkmmlxr-nee-fbga-200.jpg',
    alt: 'A 200-ball FBGA package, the package used for the H9HCNNNBKMMLXR-NEE',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'FBGA'],
      ['Number of pins', '200'],
      ['Mounting type', 'Surface mount'],
      ['Memory size', '16Gb'],
      ['Memory technology', 'LPDDR4X SDRAM'],
      ['Data bus width', 'x32'],
      ['Clock frequency', '2.133 GHz (4266 Mbps)'],
      ['Supply voltage', '1.7 V to 1.95 V (VDD1), 1.06 V to 1.17 V (VDD2)'],
      ['Series', 'H9HCNNN'],
      ['Operating temperature', '-25 \u00b0C to 85 \u00b0C'],
    ],
    about: 'The H9HCNNNBKMMLXR-NEE is a low-power DDR4X SDRAM device from SK Hynix in a 16Gb density with a x32 organisation, packaged as a 200-ball FBGA for surface mounting. It runs a 2.133 GHz clock, equivalent to a 4266 Mbps data rate, from a 1.7 V to 1.95 V VDD1 rail and a 1.06 V to 1.17 V VDD2 rail. The peer page record gives an operating range of -25 \u00b0C to 85 \u00b0C, and the part follows the JEDEC JESD209-4 standard. It is intended for flagship and mid-to-high-end smartphones, tablets, automotive cockpits, AR and VR devices, and edge AI boxes with a x32 LPDDR4X memory channel.',
    standards: ['JEDEC JESD209-4'],
    features: [
      'LPDDR4X SDRAM in a 16Gb density with a x32 data bus',
      '2.133 GHz clock, equivalent to a 4266 Mbps data rate',
      'Dual-rail supply, 1.7 V to 1.95 V VDD1 and 1.06 V to 1.17 V VDD2',
      '200-ball FBGA package for surface mounting',
      'Operating range of -25 \u00b0C to 85 \u00b0C',
      'Compact single-die package for space-limited boards',
      'Designed to the JEDEC JESD209-4 standard',
    ],
    applications: [
      'Flagship and mid-to-high-end smartphones',
      'Tablets',
      'Automotive cockpits',
      'AR and VR devices',
      'Edge AI boxes',
    ],
    faq: [
      {
        q: 'What is the H9HCNNNBKMMLXR-NEE used for?',
        a: 'It is a 16Gb x32 LPDDR4X SDRAM die used in flagship and mid-to-high-end smartphones, tablets, automotive cockpits, AR and VR devices, and edge AI boxes, where a 4266 Mbps low-power memory channel is required.',
      },
      {
        q: 'What do buyers check before ordering an H9HCNNNBKMMLXR-NEE?',
        a: 'Buyers check the part against the host SoC DDR support list, for example Rockchip, Qualcomm or MediaTek platforms; the board stack-up and thermal design needed for a single large-density die; whether the memory is original or white-label die; the voltage differences between LPDDR4X and LPDDR4; the batch and package origin; and price and lead time.',
      },
      {
        q: 'How does YIXINOU check an H9HCNNNBKMMLXR-NEE before it ships?',
        a: 'Every 200-ball FBGA lot is verified against the order for marking, lot code and quantity before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. We send photographs of the actual lot on request.',
      },
    ],
  },
  'HF115F-A-230-2ZS4': {
    mpn: 'HF115F-A/230-2ZS4',
    brand: 'Hongfa',
    title: 'HF115F miniature high-power relay, 230 VAC coil, 2 Form C contacts',
    category: 'Others',
    categoryHref: '/all-products',
    summary: 'The HF115F-A/230-2ZS4 is a Hongfa HF115F series miniature high-power relay with a 230 VAC AC coil and two changeover (2 Form C, 2 CO) contacts. It switches up to 8 A at 250 VAC, comes in a through-hole DIP case with 8 pins, and is rated from -40 \u00b0C to +70 \u00b0C. The part is covered by IEC 61810 and UL508 and is RoHS compliant. It is used in home appliance control such as air conditioners, washing machines and water heaters, in industrial control boards, power meters, lighting control and smart electricity meters.',
    img: '/assets/images/hf115f-a-230-2zs4-package.jpg',
    alt: 'A through-hole DIP relay package with 8 pins, the package used for the HF115F-A/230-2ZS4',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'Through-hole DIP, 8 pin'],
      ['Number of pins', '8'],
      ['Mounting type', 'Through hole'],
      ['Relay type', 'Miniature high-power relay, HF115F series'],
      ['Coil voltage', '230 VAC'],
      ['Contact configuration', '2 Form C (2 CO, two changeover contacts)'],
      ['Contact rating', '8 A at 250 VAC'],
      ['Coil type', 'AC coil'],
      ['Operating temperature', '-40 \u00b0C to +70 \u00b0C'],
      ['Standards', 'IEC 61810, UL508, RoHS'],
    ],
    about: 'The HF115F-A/230-2ZS4 is a miniature high-power relay from the Hongfa HF115F series. It has a 230 VAC AC coil and two changeover contacts (2 Form C, 2 CO) rated at 8 A and 250 VAC, and it is built into a through-hole DIP case with 8 pins that suits standard PCB assembly. The relay is specified for an operating range of -40 \u00b0C to +70 \u00b0C and is covered by IEC 61810 and UL508, with RoHS compliance. It is used to switch appliance loads in air conditioners, washing machines and water heaters, and in industrial control boards, power meters, lighting control and smart electricity meters.',
    standards: [
      'IEC 61810',
      'UL508',
      'RoHS compliant',
    ],
    features: [
      '230 VAC AC coil with two changeover contacts (2 Form C, 2 CO)',
      'Contact rating of 8 A at 250 VAC',
      'Through-hole DIP case with 8 pins for standard PCB assembly',
      'Operating range of -40 \u00b0C to +70 \u00b0C',
      'Miniature high-power relay from the Hongfa HF115F series',
      'Covered by IEC 61810 and UL508, RoHS compliant',
    ],
    applications: [
      'Home appliance control (air conditioners, washing machines, water heaters)',
      'Industrial control boards',
      'Power meters',
      'Lighting control',
      'Smart electricity meters',
    ],
    faq: [
      {
        q: 'What is the HF115F-A/230-2ZS4 used for?',
        a: 'It is a 230 VAC coil relay with two 8 A changeover contacts used to switch appliance loads in air conditioners, washing machines and water heaters, and in industrial control boards, power meters, lighting control and smart electricity meters.',
      },
      {
        q: 'What do buyers check before ordering an HF115F-A/230-2ZS4?',
        a: 'Buyers check that the coil voltage matches the drive circuit, since a 230 VAC coil needs a triac or a relay driver and cannot be driven from 5 V logic; the derating of the 8 A 250 VAC contact for inductive, capacitive or lamp loads; the electrical and mechanical life figures; the pin pitch and PCB layout; whether the parts are genuine Hongfa product, because counterfeits are common in this market; and price and minimum order quantity.',
      },
      {
        q: 'How does YIXINOU check an HF115F-A/230-2ZS4 before it ships?',
        a: 'For this through-hole DIP 8-pin relay we check the coil marking, contact configuration, pin layout and quantity against the order before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Photographs of the actual lot are available on request.',
      },
    ],
  },
  'HMC472ALP4ETR': {
    mpn: 'HMC472ALP4ETR',
    brand: 'Analog Devices',
    title: 'GaAs MMIC digital attenuator, 0.5 dB LSB, 6 bit, DC to 3.8 GHz',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / RF Semiconductors and Devices / RF Attenuators',
    categoryHref: '/all-products',
    summary: 'The HMC472ALP4ETR is an Analog Devices 6-bit GaAs MMIC digital attenuator with a 0.5 dB LSB and 31.5 dB of attenuation range, operating from DC to 3.8 GHz. Insertion loss is below 2 dB and the input third-order intercept point is 48 dBm. It runs from a single +5 V supply with a typical current of 2.6 mA and switches in 30 ns, controlled in parallel or serial mode with TTL and CMOS compatible levels. It is used in communication base stations, test and measurement instruments, phased-array radar, RF transceiver front ends and satellite communications.',
    img: '/assets/images/hmc472alp4etr-qfn-24.jpg',
    alt: 'A 24-lead LFCSP (QFN) package measuring 4 mm x 4 mm, the package used for the HMC472ALP4ETR',
    imageNote: 'Illustrative package image. Ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'QFN, 24-lead LFCSP (4 mm x 4 mm, LP4)'],
      ['Number of pins', '24'],
      ['Mounting type', 'Surface mount'],
      ['Frequency range', 'DC to 3.8 GHz'],
      ['Attenuation range', '31.5 dB'],
      ['Attenuation step', '0.5 dB LSB, 6 bit'],
      ['Control interface', '6-bit parallel or serial, TTL and CMOS compatible'],
      ['Supply voltage', '5 V single supply (2.6 mA max)'],
      ['Switching time', '30 ns'],
      ['Operating temperature', '-40 \u00b0C to 85 \u00b0C'],
    ],
    about: 'The HMC472ALP4ETR is a 6-bit GaAs MMIC digital step attenuator from Analog Devices, covering DC to 3.8 GHz with a 0.5 dB least significant bit and a 31.5 dB attenuation range. Insertion loss stays below 2 dB and the input third-order intercept point reaches 48 dBm. The device runs from a single +5 V supply at 2.6 mA maximum, switches in 30 ns, and is driven over a 6-bit parallel or serial control bus with TTL and CMOS compatible levels. It comes in a 24-lead LFCSP measuring 4 mm x 4 mm and is used in base stations, test instruments, phased-array radar, RF front ends and satellite links.',
    standards: [
      'Analog Devices datasheet HMC472A (v02.0420)',
      'RoHS compliant',
      'Meets JEDEC package and ESD standards',
      'MSL3 moisture sensitivity level (J-STD-020)',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '6-bit digital attenuator with a 0.5 dB least significant bit',
      '31.5 dB attenuation range from DC to 3.8 GHz',
      'Insertion loss below 2 dB across the band',
      'Input third-order intercept point of 48 dBm',
      'Single +5 V supply with a 2.6 mA maximum current',
      '30 ns switching time',
      'Parallel and serial control, TTL and CMOS compatible',
      '24-lead LFCSP package measuring 4 mm x 4 mm',
    ],
    applications: [
      'Communication base stations',
      'Test and measurement instruments (spectrum analysers, signal sources)',
      'Phased-array radar',
      'RF transceiver front ends',
      'Satellite communications',
    ],
    faq: [
      {
        q: 'What is the HMC472ALP4ETR used for?',
        a: 'It is a DC to 3.8 GHz 6-bit GaAs MMIC digital attenuator used in communication base stations, test and measurement instruments such as spectrum analysers and signal sources, phased-array radar, RF transceiver front ends and satellite communications, wherever a 0.5 dB step and 31.5 dB range of level control is needed.',
      },
      {
        q: 'What do buyers check before ordering an HMC472ALP4ETR?',
        a: 'Buyers check the insertion loss and the attenuation accuracy at each bit, where errors run at about \u00b10.3 dB; the control interface levels for serial, parallel or latched operation; the single-supply arrangement and the bypass decoupling design; wideband impedance matching and PCB RF trace layout; whether the parts are genuine Analog Devices product, because counterfeit microwave devices are common; and the high price together with long lead times.',
      },
      {
        q: 'How does YIXINOU check an HMC472ALP4ETR before it ships?',
        a: 'For each 24-lead LFCSP lot we check the marking, date code, reel labelling and quantity against the order before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Ask us for a photograph of the actual lot before you commit.',
      },
    ],
  },
  'HMC624ALP4ETR': {
    mpn: 'HMC624ALP4ETR',
    brand: 'Analog Devices',
    title: 'GaAs digital attenuator, 0.5 dB LSB, 6 bit, 0.1 GHz to 6.0 GHz',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / RF Semiconductors and Devices / RF Attenuators',
    categoryHref: '/all-products',
    summary: 'The HMC624ALP4ETR is an Analog Devices 6-bit GaAs digital attenuator with a 0.5 dB LSB and 31.5 dB of attenuation range, covering 0.1 GHz to 6.0 GHz. It runs from a single +3 V to +5 V supply and switches in 30 ns, with 6-bit serial or parallel control that supports serial address selection. The part comes in a 24-lead LFCSP measuring 4 mm x 4 mm and is supplied on tape and reel. It is used in 5G communication, microwave test instruments, radar, electronic warfare, and automatic gain control in RF transceiver chains.',
    img: '/assets/images/hmc624alp4etr-qfn-24.jpg',
    alt: 'A 24-lead LFCSP (QFN) package measuring 4 mm x 4 mm, the package used for the HMC624ALP4ETR',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'QFN, 24-lead LFCSP (4 mm x 4 mm, LP4)'],
      ['Number of pins', '24'],
      ['Mounting type', 'Surface mount'],
      ['Frequency range', '0.1 GHz to 6.0 GHz'],
      ['Attenuation range', '31.5 dB'],
      ['Attenuation step', '0.5 dB LSB, 6 bit'],
      ['Control interface', '6-bit serial or parallel, with serial address selection'],
      ['Supply voltage', '3 V to 5 V single supply'],
      ['Switching time', '30 ns'],
      ['Operating temperature', '-40 \u00b0C to 85 \u00b0C'],
    ],
    about: 'The HMC624ALP4ETR is a 6-bit GaAs digital attenuator from Analog Devices covering 0.1 GHz to 6.0 GHz, with a 0.5 dB least significant bit and a 31.5 dB attenuation range. It operates from a single +3 V to +5 V supply, switches within 30 ns, and takes 6-bit serial or parallel control with serial address selection for multi-device buses. The part is housed in a 24-lead LFCSP measuring 4 mm x 4 mm and ships on tape and reel. It is used in 5G communication, microwave test instruments, radar, electronic warfare and automatic gain control in RF transceiver chains.',
    standards: [
      'Analog Devices datasheet HMC624A Rev. B',
      'RoHS compliant',
      'Meets JEDEC package and ESD standards, including JESD51 thermal standards',
      'MSL3 moisture sensitivity level (J-STD-020)',
      'MSL1 moisture sensitivity level (J-STD-020)',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '6-bit digital attenuator with a 0.5 dB least significant bit',
      '31.5 dB attenuation range from 0.1 GHz to 6.0 GHz',
      'Single +3 V to +5 V supply',
      '30 ns switching time',
      '6-bit serial or parallel control with serial address selection',
      '24-lead LFCSP package measuring 4 mm x 4 mm',
      'Supplied on tape and reel (ETR)',
      'GaAs MMIC process for wideband RF performance',
    ],
    applications: [
      '5G communication systems',
      'Microwave test instruments',
      'Radar',
      'Electronic warfare',
      'Automatic gain control in RF transceiver chains',
    ],
    faq: [
      {
        q: 'What is the HMC624ALP4ETR used for?',
        a: 'It is a 0.1 GHz to 6.0 GHz 6-bit GaAs digital attenuator used in 5G communication systems, microwave test instruments, radar, electronic warfare equipment, and automatic gain control loops in RF transceiver chains that need a 0.5 dB step and 31.5 dB range of level control.',
      },
      {
        q: 'What do buyers check before ordering an HMC624ALP4ETR?',
        a: 'Buyers check the insertion loss and matching at the 6 GHz top of the band; whether serial or parallel control is used and how the latch timing behaves; whether dedicated GaAs bias and DC blocking capacitors are required; heat dissipation and the PCB ground via arrangement; whether the parts are genuine Analog Devices product; and lead time and price, which are volatile on ADI microwave lines.',
      },
      {
        q: 'How does YIXINOU check an HMC624ALP4ETR before it ships?',
        a: 'Each 24-lead LFCSP lot is checked for marking, date code, reel labels and quantity against the order before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. We send photographs of the actual lot on request.',
      },
    ],
  },
  'ICM-42688-P': {
    mpn: 'ICM-42688-P',
    brand: 'InvenSense',
    title: '6-axis MEMS inertial measurement unit in a 14-pin LGA package',
    category: 'Sensor / Sensors / Motion Sensors / Inertial Measurement Units (IMUs)',
    categoryHref: '/all-products',
    summary: 'The ICM-42688-P is a 6-axis MEMS inertial measurement unit that combines a 3-axis accelerometer and a 3-axis gyroscope in one device. The gyroscope full-scale range runs from \u00b115.625 dps to \u00b12000 dps, the accelerometer from \u00b12 g to \u00b116 g, and the output is 16 bit or 18 bit. It communicates over I2C, SPI or I3C, runs from 1.71 V to 3.6 V, and comes in a 14-pin LGA measuring 2.5 mm x 3.0 mm. The operating range is -40 \u00b0C to +85 \u00b0C and the part is RoHS compliant.',
    img: '/assets/images/icm-42688-p-package.jpg',
    alt: 'A 14-pin LGA package measuring 2.5 mm x 3.0 mm, the package used for the ICM-42688-P',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'LGA, 14 pin (2.5 mm x 3.0 mm)'],
      ['Number of pins', '14'],
      ['Mounting type', 'Surface mount'],
      ['Sensor type', '6-axis MEMS IMU (3-axis accelerometer and 3-axis gyroscope)'],
      ['Gyroscope range', '\u00b115.625 dps to \u00b12000 dps'],
      ['Accelerometer range', '\u00b12 g to \u00b116 g'],
      ['Output resolution', '16 bit / 18 bit'],
      ['Interface', 'I2C, SPI, I3C'],
      ['Supply voltage', '1.71 V to 3.6 V'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C'],
    ],
    about: 'The ICM-42688-P is a 6-axis MEMS inertial measurement unit from InvenSense that integrates a 3-axis accelerometer and a 3-axis gyroscope in a single device. The gyroscope full-scale range spans \u00b115.625 dps to \u00b12000 dps and the accelerometer spans \u00b12 g to \u00b116 g, with 16 bit and 18 bit output. Data is read over I2C, SPI or I3C, and the part works from 1.71 V to 3.6 V across -40 \u00b0C to +85 \u00b0C. It is housed in a 14-pin LGA measuring 2.5 mm x 3.0 mm and is RoHS compliant.',
    standards: ['RoHS compliant', 'REACH SVHC unaffected'],
    features: [
      '6-axis MEMS IMU combining a 3-axis accelerometer and a 3-axis gyroscope',
      'Gyroscope full-scale range from \u00b115.625 dps to \u00b12000 dps',
      'Accelerometer full-scale range from \u00b12 g to \u00b116 g',
      '16-bit and 18-bit output data',
      'I2C, SPI and I3C digital interfaces',
      'Compact 14-pin LGA package measuring 2.5 mm x 3.0 mm',
      'Supply range of 1.71 V to 3.6 V',
      'Operating range of -40 \u00b0C to +85 \u00b0C',
    ],
    applications: [
      'Motion tracking in handheld and wearable devices',
      'Robotics and autonomous platform control',
      'Image stabilisation for cameras and gimbals',
      'Industrial vibration and motion monitoring',
    ],
    faq: [
      {
        q: 'What is the ICM-42688-P used for?',
        a: 'The ICM-42688-P is a 6-axis MEMS inertial measurement unit: a 3-axis accelerometer and a 3-axis gyroscope in one 14-pin LGA package, with gyroscope ranges from \u00b115.625 dps to \u00b12000 dps, accelerometer ranges from \u00b12 g to \u00b116 g and 16-bit or 18-bit output over I2C, SPI or I3C. The supplied record does not list end-equipment applications for this part, so please confirm the intended use with YIXINOU before design-in.',
      },
      {
        q: 'What do buyers check before ordering an ICM-42688-P?',
        a: 'Buyers check whether an automotive-grade version is required, because the industrial and automotive part numbers differ; the gyroscope bias stability and temperature drift figures; the SPI interface rate and the FIFO depth; the soldering process requirements, since an LGA is sensitive to board-level stress; whether the parts are genuine, as this series is counterfeited; and price and lead time.',
      },
      {
        q: 'How does YIXINOU check an ICM-42688-P before it ships?',
        a: 'For each 14-pin LGA lot we verify the marking, date code, packing and quantity against the order before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Ask us for a photograph of the actual lot before you commit.',
      },
    ],
  },
  'K4A4G085WF-BCTD': {
    mpn: 'K4A4G085WF-BCTD',
    brand: 'Samsung',
    title: 'DDR4 SDRAM 4Gb x8 memory die in a 78-ball FBGA package',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / DDR',
    categoryHref: '/all-products',
    summary: 'The K4A4G085WF-BCTD is a Samsung DDR4 SDRAM die with a 4Gb density and a x8 data bus, supplied in a 78-ball FBGA package for surface mounting. It runs a 2666 MHz speed grade from a 1.2 V VDD/VDDQ rail with a 2.5 V VPP supply, inside a 1.14 V to 1.26 V supply window. The peer page record gives an operating range of 0 \u00b0C to 85 \u00b0C, and the design follows the JEDEC JESD79-4 DDR4 standard. It is used on industrial control motherboards, network equipment, set-top boxes, digital signage and entry-level embedded platforms.',
    img: '/assets/images/k4a4g085wf-bctd-fbga-78.jpg',
    alt: 'A 78-ball FBGA package, the package used for the K4A4G085WF-BCTD',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'FBGA'],
      ['Number of pins', '78'],
      ['Mounting type', 'Surface mount'],
      ['Memory size', '4Gb'],
      ['Memory technology', 'DDR4 SDRAM'],
      ['Data bus width', 'x8'],
      ['Speed grade', '2666 MHz (2666 Mbps)'],
      ['Supply voltage', '1.2 V (VDD/VDDQ), 2.5 V (VPP)'],
      ['Supply voltage window', '1.14 V to 1.26 V'],
      ['Operating temperature', '0 \u00b0C to 85 \u00b0C'],
    ],
    about: 'The K4A4G085WF-BCTD is a DDR4 SDRAM device from Samsung in a 4Gb density with a x8 organisation, packaged as a 78-ball FBGA for surface mounting. It is specified for a 2666 MHz speed grade, a 1.2 V VDD/VDDQ supply with a 2.5 V VPP rail, and a supply window of 1.14 V to 1.26 V across an operating range of 0 \u00b0C to 85 \u00b0C. The part follows the JEDEC JESD79-4 DDR4 standard. It is used on industrial control motherboards, network equipment, set-top boxes, digital signage, and entry-level embedded platforms that need a low-density DDR4 x8 die.',
    standards: ['JEDEC JESD79-4'],
    features: [
      'DDR4 SDRAM in a 4Gb density with a x8 data bus',
      '2666 MHz speed grade',
      '1.2 V VDD/VDDQ supply with a 2.5 V VPP rail',
      'Supply window of 1.14 V to 1.26 V',
      '78-ball FBGA package for surface mounting',
      'Operating range of 0 \u00b0C to 85 \u00b0C',
      'Designed to the JEDEC JESD79-4 DDR4 standard',
    ],
    applications: [
      'Industrial control motherboards',
      'Network equipment',
      'Set-top boxes',
      'Digital signage',
      'Entry-level embedded platforms',
    ],
    faq: [
      {
        q: 'What is the K4A4G085WF-BCTD used for?',
        a: 'It is a 4Gb x8 DDR4 SDRAM die used on industrial control motherboards, network equipment, set-top boxes, digital signage and entry-level embedded platforms, where a 2666 MHz DDR4 die with a 1.2 V rail is required.',
      },
      {
        q: 'What do buyers check before ordering a K4A4G085WF-BCTD?',
        a: 'Buyers check whether the 4Gb density is being phased out and how long a last-time-buy window remains; whether the speed grade matches the motherboard SPD; whether the die is original or downgraded; whether an 8Gb alternative should be designed in; price and lead time; and lot-to-lot consistency.',
      },
      {
        q: 'How does YIXINOU check a K4A4G085WF-BCTD before it ships?',
        a: 'Each 78-ball FBGA lot is checked for marking, lot code and quantity against the order before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Photographs of the actual lot are available on request.',
      },
    ],
  },
  'K4A4G165WF-BCTD': {
    mpn: 'K4A4G165WF-BCTD',
    brand: 'Samsung',
    title: 'DDR4 SDRAM 4Gb x16 memory die in a 96-ball FBGA package',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / DDR',
    categoryHref: '/all-products',
    summary: 'The K4A4G165WF-BCTD is a Samsung DDR4 SDRAM die with a 4Gb density and a x16 data bus, supplied in a 96-ball FBGA package for surface mounting. It runs a 2666 Mbps speed grade (DDR4-2666, CL19) from a 1.2 V supply, inside a 1.14 V to 1.26 V supply window, and the peer page record lists its lifecycle status as production. The operating range is 0 \u00b0C to 85 \u00b0C and the design follows the JEDEC JESD79-4 DDR4 standard. It is used on industrial control motherboards, network communication equipment, digital signage, POS terminals, and entry-level servers and embedded platforms.',
    img: '/assets/images/k4a4g165wf-bctd-fbga-96.jpg',
    alt: 'A 96-ball FBGA package, the package used for the K4A4G165WF-BCTD',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'FBGA'],
      ['Number of pins', '96'],
      ['Mounting type', 'Surface mount'],
      ['Memory size', '4Gb'],
      ['Memory technology', 'DDR4 SDRAM'],
      ['Data bus width', 'x16'],
      ['Speed grade', '2666 Mbps (DDR4-2666, CL19)'],
      ['Supply voltage', '1.2 V'],
      ['Operating temperature', '0 \u00b0C to 85 \u00b0C'],
      ['Lifecycle status', 'Production (manufacturer)'],
    ],
    about: 'The K4A4G165WF-BCTD is a DDR4 SDRAM device from Samsung in a 4Gb density with a x16 organisation, packaged as a 96-ball FBGA for surface mounting. It runs a 2666 Mbps speed grade (DDR4-2666, CL19) from a 1.2 V supply inside a 1.14 V to 1.26 V window, with lifecycle status listed as production. The operating range is 0 \u00b0C to 85 \u00b0C and the part follows the JEDEC JESD79-4 DDR4 standard. It is used on industrial control motherboards, network communication equipment, digital signage, POS terminals, and entry-level servers and embedded platforms.',
    standards: ['JEDEC JESD79-4'],
    features: [
      'DDR4 SDRAM in a 4Gb density with a x16 data bus',
      '2666 Mbps speed grade, DDR4-2666 with CL19 latency',
      '1.2 V supply with a 1.14 V to 1.26 V window',
      '96-ball FBGA package for surface mounting',
      'Operating range of 0 \u00b0C to 85 \u00b0C',
      'Manufacturer lifecycle status listed as production',
      'Designed to the JEDEC JESD79-4 DDR4 standard',
    ],
    applications: [
      'Industrial control motherboards',
      'Network communication equipment',
      'Digital signage',
      'POS terminals',
      'Entry-level servers and embedded platforms',
    ],
    faq: [
      {
        q: 'What is the K4A4G165WF-BCTD used for?',
        a: 'It is a 4Gb x16 DDR4 SDRAM die used on industrial control motherboards, network communication equipment, digital signage, POS terminals, and entry-level servers and embedded platforms, where a 2666 Mbps DDR4 x16 die is required.',
      },
      {
        q: 'What do buyers check before ordering a K4A4G165WF-BCTD?',
        a: 'Buyers check that the 4Gb density is leaving the market and how much long-term supply or last-time-buy risk remains; whether the speed grade matches the motherboard SPD; whether the die is original or downgraded; whether the part meets an industrial temperature requirement; price and lead time; and whether the stock is refurbished or pulled from used equipment.',
      },
      {
        q: 'How does YIXINOU check a K4A4G165WF-BCTD before it ships?',
        a: 'For each 96-ball FBGA lot we check the marking, lot code, packing and quantity against the order before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Ask us for a photograph of the actual lot before you commit.',
      },
    ],
  },
  'K4A8G045WD-BCWE': {
    mpn: 'K4A8G045WD-BCWE',
    brand: 'Samsung',
    title: 'DDR4 SDRAM 8Gb x4 memory die in a 78-ball FBGA package',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The K4A8G045WD-BCWE is a Samsung DDR4 SDRAM die with an 8Gb density and a x4 organisation, supplied in a 78-ball FBGA package. It runs a 3200 Mbps speed grade from a 1.2 V VDD/VDDQ rail with a 2.5 V VPP supply, over an operating range of 0 \u00b0C to 95 \u00b0C, and the design follows the JEDEC JESD79-4 DDR4 standard. The x4 organisation is intended for server ECC module builds. It is used on server RDIMM and LRDIMM memory modules, in data centres, and in enterprise servers and storage equipment.',
    img: '/assets/images/k4a8g045wd-bcwe-package.jpg',
    alt: 'A 78-ball FBGA package, the package used for the K4A8G045WD-BCWE',
    imageNote: 'Illustrative package image. Ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'FBGA-78'],
      ['Number of pins', '78'],
      ['Mounting type', 'Surface mount'],
      ['Memory size', '8Gb'],
      ['Memory technology', 'DDR4 SDRAM'],
      ['Data bus width', 'x4'],
      ['Speed grade', '3200 Mbps'],
      ['Supply voltage', '1.2 V (VDD/VDDQ), 2.5 V (VPP)'],
      ['Operating temperature', '0 \u00b0C to 95 \u00b0C'],
      ['Product standards', 'JEDEC JESD79-4'],
    ],
    about: 'The K4A8G045WD-BCWE is a DDR4 SDRAM device from Samsung in an 8Gb density with a x4 organisation, packaged as a 78-ball FBGA. It is specified for a 3200 Mbps speed grade from a 1.2 V VDD/VDDQ supply with a 2.5 V VPP rail, over an operating range of 0 \u00b0C to 95 \u00b0C, and it follows the JEDEC JESD79-4 DDR4 standard. The x4 organisation is used mainly for server ECC modules. It is intended for server RDIMM and LRDIMM memory modules, data centres, and enterprise server and storage equipment.',
    standards: ['JEDEC JESD79-4'],
    features: [
      'DDR4 SDRAM in an 8Gb density with a x4 organisation',
      '3200 Mbps speed grade for server module builds',
      '1.2 V VDD/VDDQ supply with a 2.5 V VPP rail',
      '78-ball FBGA package',
      'Operating range of 0 \u00b0C to 95 \u00b0C',
      'x4 organisation intended for server ECC modules',
      'Designed to the JEDEC JESD79-4 DDR4 standard',
    ],
    applications: [
      'Server RDIMM and LRDIMM memory modules',
      'Data centres',
      'Enterprise servers',
      'Enterprise storage equipment',
    ],
    faq: [
      {
        q: 'What is the K4A8G045WD-BCWE used for?',
        a: 'It is an 8Gb x4 DDR4 SDRAM die used on server RDIMM and LRDIMM memory modules, in data centres, and in enterprise server and storage equipment, where the x4 organisation needed for server ECC modules is required.',
      },
      {
        q: 'What do buyers check before ordering a K4A8G045WD-BCWE?',
        a: 'Buyers check that a x4 organisation is used mainly for server ECC modules and cannot be interchanged with x8 or x16 parts; that the 3200 speed grade places high demands on the PCB and signal integrity; whether the die is original or white-label; whether the module design holds the server platform QVL certification; price and lead time; and lot-to-lot consistency.',
      },
      {
        q: 'How does YIXINOU check a K4A8G045WD-BCWE before it ships?',
        a: 'For each 78-ball FBGA lot we check the marking, date code and quantity against the order before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Photographs of the actual lot are available on request.',
      },
    ],
  },
  'K4A8G085WB-BCTD': {
    mpn: 'K4A8G085WB-BCTD',
    brand: 'Samsung',
    title: 'DDR4 SDRAM 8Gb x8 memory die in a 78-ball FBGA package',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / DDR',
    categoryHref: '/all-products',
    summary: 'The K4A8G085WB-BCTD is a Samsung DDR4 SDRAM die with an 8Gb density and a x8 data bus, supplied in a 78-ball FBGA package for surface mounting. It runs a 2666 Mbps speed grade (DDR4-2666, CL19) from a 1.2 V supply inside a 1.14 V to 1.26 V window, and the operating range is 0 \u00b0C to 85 \u00b0C. The peer page record lists the lifecycle status as obsolete, so buyers should plan a last-time-buy or a substitute. The design follows the JEDEC JESD79-4 DDR4 standard and the part is used on server and PC memory modules, industrial control motherboards, network equipment and edge computing platforms.',
    img: '/assets/images/k4a8g085wb-bctd-fbga-78.jpg',
    alt: 'A 78-ball FBGA package, the package used for the K4A8G085WB-BCTD',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'FBGA'],
      ['Number of pins', '78'],
      ['Mounting type', 'Surface mount'],
      ['Memory size', '8Gb'],
      ['Memory technology', 'DDR4 SDRAM'],
      ['Data bus width', 'x8'],
      ['Speed grade', '2666 Mbps (DDR4-2666, CL19)'],
      ['Supply voltage', '1.2 V (1.14 V to 1.26 V)'],
      ['Operating temperature', '0 \u00b0C to 85 \u00b0C'],
      ['Lifecycle status', 'Obsolete (manufacturer)'],
    ],
    about: 'The K4A8G085WB-BCTD is a DDR4 SDRAM device from Samsung in an 8Gb density with a x8 organisation, packaged as a 78-ball FBGA for surface mounting. It is specified for a 2666 Mbps speed grade (DDR4-2666, CL19) from a 1.2 V supply within a 1.14 V to 1.26 V window, over an operating range of 0 \u00b0C to 85 \u00b0C. The peer page record lists its lifecycle status as obsolete, and the part follows the JEDEC JESD79-4 DDR4 standard. It is used on server and PC memory modules such as UDIMM and RDIMM, on industrial control motherboards, in network equipment and in edge computing platforms.',
    standards: ['JEDEC JESD79-4'],
    features: [
      'DDR4 SDRAM in an 8Gb density with a x8 data bus',
      '2666 Mbps speed grade, DDR4-2666 with CL19 latency',
      '1.2 V supply with a 1.14 V to 1.26 V window',
      '78-ball FBGA package for surface mounting',
      'Operating range of 0 \u00b0C to 85 \u00b0C',
      'Manufacturer lifecycle status listed as obsolete',
      'Designed to the JEDEC JESD79-4 DDR4 standard',
    ],
    applications: [
      'Server and PC memory modules (UDIMM, RDIMM)',
      'Industrial control motherboards',
      'Network equipment',
      'Edge computing platforms',
    ],
    faq: [
      {
        q: 'What is the K4A8G085WB-BCTD used for?',
        a: 'It is an 8Gb x8 DDR4 SDRAM die used on server and PC memory modules such as UDIMM and RDIMM, on industrial control motherboards, in network equipment and in edge computing platforms that need a 2666 Mbps DDR4 x8 die.',
      },
      {
        q: 'What do buyers check before ordering a K4A8G085WB-BCTD?',
        a: 'Buyers check the price, because 8Gb is the mainstream DDR4 density and is the most price-sensitive point in the market; how a x8 part fits the module against a x16 alternative; whether the die is original or downgraded, using appearance checks and test reports; how the 2666 and 3200 speed grades substitute for each other; the long-term supply strategy now that DDR4 is at end of life; and lot-to-lot consistency.',
      },
      {
        q: 'How does YIXINOU check a K4A8G085WB-BCTD before it ships?',
        a: 'For each 78-ball FBGA lot we verify the marking, lot code, packing and quantity against the order before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Ask us for a photograph of the actual lot before you commit.',
      },
    ],
  },
  'K4A8G165WB-BCRC': {
    mpn: 'K4A8G165WB-BCRC',
    brand: 'Samsung',
    title: 'DDR4 SDRAM 8 Gb x16 chip in a 96-ball FBGA package',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / DDR',
    categoryHref: '/all-products',
    summary: 'The K4A8G165WB-BCRC is an 8 Gb DDR4 SDRAM organised as 512 M x 16 in a 96-ball FBGA package for surface mounting. It runs at 2400 Mbps (1.2 GHz) from a 1.2 V nominal VDD/VDDQ rail with a 2.5 V VPP, and the peer supply window is 1.14 V to 1.26 V. Data bus width is 16 bit with a 175 ps access time, and the peer operating range is 0 \u00b0C to 85 \u00b0C. The device follows JEDEC JESD79-4, the DDR4 SDRAM standard. The peer record lists the part as obsolete, so supply now comes from stock.',
    img: '/assets/images/k4a8g165wb-bcrc-fbga-96.jpg',
    alt: 'A 96-ball FBGA package, the package used for the K4A8G165WB-BCRC',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Memory type', 'DDR4 SDRAM, synchronous'],
      ['Density', '8 Gb (512 M x 16)'],
      ['Data bus width', '16 bit'],
      ['Data rate', '2400 Mbps (1.2 GHz)'],
      ['Case package', 'FBGA-96 (96 balls, surface mount)'],
      ['Supply voltage', '1.14 V to 1.26 V (1.2 V VDD/VDDQ nominal)'],
      ['Peak supply voltage (VPP)', '2.5 V'],
      ['Operating temperature', '0 \u00b0C to 85 \u00b0C'],
      ['Access time', '175 ps'],
      ['Lifecycle status', 'Obsolete'],
    ],
    about: 'The K4A8G165WB-BCRC is a Samsung 8 Gb DDR4 SDRAM device in a 96-ball FBGA package. It stores 8 Gb as 512 M x 16, runs at 2400 Mbps with a 1.2 GHz clock, and draws from a 1.2 V VDD/VDDQ supply with a 2.5 V VPP; the peer supply window is 1.14 V to 1.26 V. Access time is 175 ps and the rated operating range is 0 \u00b0C to 85 \u00b0C. The part is built to JEDEC JESD79-4. Because the x16 organisation keeps memory module routing simple and low cost, it suits DDR4 modules for PC and industrial builds, network equipment, digital signage, POS terminals and embedded motherboards.',
    standards: [
      'Samsung DDR4 SDRAM, JEDEC JESD79-4',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '8 Gb density arranged as 512 M x 16',
      '2400 Mbps data rate at a 1.2 GHz clock',
      '1.2 V VDD/VDDQ with a 2.5 V VPP',
      '96-ball FBGA surface-mount package',
      '175 ps access time',
      'Rated 0 \u00b0C to 85 \u00b0C',
      'x16 organisation keeps module routing simple and lowers cost',
      'JEDEC JESD79-4 compliant',
    ],
    applications: [
      'PC and industrial memory modules',
      'Network equipment',
      'Digital signage',
      'POS terminals',
      'Embedded motherboards',
    ],
    faq: [
      {
        q: 'What is the K4A8G165WB-BCRC used for?',
        a: 'It is a x16 DDR4 device for PC and industrial memory modules, network equipment, digital signage, POS terminals and embedded motherboards. Its x16 organisation keeps module routing simple and cost low, which suits cost-sensitive module builds.',
      },
      {
        q: 'What do buyers check before ordering a K4A8G165WB-BCRC?',
        a: 'Buyers check that a 2400 Mbps part will be down-clocked on 2666 or 3200 platforms and that the module design can accept that. They also ask whether the parts are original factory die or white-label chips, how long supply can be supported now that the part is obsolete, and what the price, MOQ and lot consistency will be.',
      },
      {
        q: 'How does YIXINOU check a K4A8G165WB-BCRC before it ships?',
        a: 'Every 96-ball FBGA lot is checked before it leaves us. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Lot marking, date code and quantity are recorded against the ordered MPN before packing.',
      },
    ],
  },
  'K4B4G1646E-BCMA': {
    mpn: 'K4B4G1646E-BCMA',
    brand: 'Samsung',
    title: 'DDR3 SDRAM 4 Gb x16 chip in a 96-ball FBGA package',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / DDR',
    categoryHref: '/all-products',
    summary: 'The K4B4G1646E-BCMA is a 4 Gb DDR3 SDRAM organised as 256 M x 16 in a 96-ball FBGA package. It runs DDR3-1866 at 1866 Mbps with CL13 latency from a 1.5 V nominal supply, and the peer supply window is 1.425 V to 1.575 V. The device is synchronous and surface mounted with a 16 bit data bus, and it is rated for 0 \u00b0C to +85 \u00b0C. It follows JEDEC JESD79-3, the DDR3 standard. The part is discontinued, so current supply is stock-based.',
    img: '/assets/images/k4b4g1646e-bcma-fbga-96.jpg',
    alt: 'A 96-ball FBGA package, the package used for the K4B4G1646E-BCMA',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Memory type', 'DDR3 SDRAM, synchronous'],
      ['Density', '4 Gb (256 M x 16)'],
      ['Data bus width', '16 bit'],
      ['Data rate', '1866 Mbps (DDR3-1866, CL13)'],
      ['Case package', 'FBGA-96 (96 balls, surface mount)'],
      ['Supply voltage', '1.425 V to 1.575 V (1.5 V nominal)'],
      ['Operating temperature', '0 \u00b0C to +85 \u00b0C'],
      ['CAS latency', 'CL13 in DDR3-1866 mode'],
      ['Mount', 'Surface mount'],
      ['Lifecycle status', 'Discontinued - supply is stock-based'],
    ],
    about: 'The K4B4G1646E-BCMA is a Samsung 4 Gb DDR3 SDRAM in a 96-ball FBGA package. It is organised as 256 M x 16 and runs DDR3-1866 at 1866 Mbps with CL13 latency from a 1.5 V nominal supply; the peer record gives a window of 1.425 V to 1.575 V. The device is synchronous and surface mounted with a 16 bit data bus, and it is rated for 0 \u00b0C to +85 \u00b0C. It is built to JEDEC JESD79-3. Typical uses are PC and industrial memory modules, network equipment, IPTV set-top boxes, industrial tablets and video surveillance NVR, and because the part is discontinued buyers now source from stock.',
    standards: [
      'Samsung DDR3 SDRAM, JEDEC JESD79-3',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '4 Gb density arranged as 256 M x 16',
      'DDR3-1866 at 1866 Mbps with CL13',
      '1.5 V nominal supply, 1.425 V to 1.575 V window',
      '96-ball FBGA surface-mount package',
      'Synchronous interface with a 16 bit data bus',
      'Rated 0 \u00b0C to +85 \u00b0C',
      'Discontinued - current supply is stock',
      'JEDEC JESD79-3 compliant',
    ],
    applications: [
      'PC and industrial memory modules',
      'Network equipment',
      'IPTV set-top boxes',
      'Industrial tablets',
      'Video surveillance NVR',
    ],
    faq: [
      {
        q: 'What is the K4B4G1646E-BCMA used for?',
        a: 'It is a 16 bit DDR3 chip used in PC and industrial memory modules, network equipment, IPTV set-top boxes, industrial tablets and video surveillance NVR. Its 4 Gb density in a single 96-ball package suits boards that need a compact, low-cost DDR3 device.',
      },
      {
        q: 'What do buyers check before ordering a K4B4G1646E-BCMA?',
        a: 'Buyers confirm whether a 1.5 V DDR3 part can replace or be mixed with 1.35 V DDR3L in the same board and whether the design must be re-qualified. They also ask for the stock year and appearance of discontinued material, whether it is original factory product rather than white-label or salvaged chips, and the MOQ, price and any DDR3L or DDR4 alternative.',
      },
      {
        q: 'How does YIXINOU check a K4B4G1646E-BCMA before it ships?',
        a: 'Each 96-ball FBGA lot is checked before it is released. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Marking, date code and package condition are recorded against the ordered MPN.',
      },
    ],
  },
  'K4B4G1646E-BYMA': {
    mpn: 'K4B4G1646E-BYMA',
    brand: 'Samsung',
    title: 'DDR3L SDRAM 4 Gb x16 chip in a 96-ball FBGA package',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / DDR',
    categoryHref: '/all-products',
    summary: 'The K4B4G1646E-BYMA is a 4 Gb DDR3L SDRAM organised as 256 M x 16 in a 96-ball FBGA package. It runs DDR3-1866 at 1866 Mbps with CL13 from a 1.35 V nominal supply, and the peer supply window is 1.425 V to 1.575 V. Access time is 195 ps and the peer operating range is 0 \u00b0C to 95 \u00b0C. The device is synchronous, surface mounted and built to JEDEC JESD79-3. The peer record lists it as obsolete.',
    img: '/assets/images/k4b4g1646e-byma-fbga-96.jpg',
    alt: 'A 96-ball FBGA package, the package used for the K4B4G1646E-BYMA',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Memory type', 'DDR3L SDRAM, synchronous'],
      ['Density', '4 Gb (256 M x 16)'],
      ['Data bus width', '16 bit'],
      ['Data rate', '1866 Mbps (1866 MHz, DDR3-1866 / CL13)'],
      ['Case package', 'FBGA-96 (96 balls, surface mount)'],
      ['Supply voltage', '1.35 V nominal; peer window 1.425 V to 1.575 V'],
      ['Operating temperature', '0 \u00b0C to 95 \u00b0C'],
      ['Access time', '195 ps'],
      ['Mount', 'Surface mount'],
      ['Lifecycle status', 'Obsolete'],
    ],
    about: 'The K4B4G1646E-BYMA is a Samsung 4 Gb DDR3L SDRAM device in a 96-ball FBGA package. It stores 4 Gb as 256 M x 16 and runs DDR3-1866 at 1866 Mbps with CL13 latency from a 1.35 V nominal supply; the peer record gives a supply window of 1.425 V to 1.575 V. Access time is 195 ps and the peer operating range is 0 \u00b0C to 95 \u00b0C. The device is synchronous and surface mounted, and it is built to JEDEC JESD79-3. Typical uses are PC and industrial memory modules, network equipment, set-top boxes, surveillance equipment and industrial tablets.',
    standards: [
      'Samsung DDR3L SDRAM, JEDEC JESD79-3',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '4 Gb density arranged as 256 M x 16',
      'DDR3L version with a 1.35 V nominal supply',
      'DDR3-1866 at 1866 Mbps with CL13',
      '96-ball FBGA surface-mount package',
      '195 ps access time',
      'Rated 0 \u00b0C to 95 \u00b0C',
      'Synchronous 16 bit data bus',
      'JEDEC JESD79-3 compliant',
    ],
    applications: [
      'PC and industrial memory modules',
      'Network equipment',
      'Set-top boxes',
      'Surveillance equipment',
      'Industrial tablets',
    ],
    faq: [
      {
        q: 'What is the K4B4G1646E-BYMA used for?',
        a: 'It is a 16 bit DDR3L chip for PC and industrial memory modules, network equipment, set-top boxes, surveillance equipment and industrial tablets. The 1.35 V DDR3L supply suits boards that need the lower voltage DDR3 variant rather than standard 1.5 V DDR3.',
      },
      {
        q: 'What do buyers check before ordering a K4B4G1646E-BYMA?',
        a: 'Buyers check how the -BYMA version differs from -BCMA and whether the two can be interchanged, which has to be confirmed with the manufacturer. They also ask about the stock year of a discontinued part, how to identify original factory product, the risk of mixing different versions on one board, the price and the available alternatives.',
      },
      {
        q: 'How does YIXINOU check a K4B4G1646E-BYMA before it ships?',
        a: 'Every 96-ball FBGA lot is verified before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Device marking and date code are compared with the ordered version before packing.',
      },
    ],
  },
  'K4E8E304ED-EGCC': {
    mpn: 'K4E8E304ED-EGCC',
    brand: 'Samsung',
    title: 'LPDDR3 SDRAM 8 Gb x32 chip in an FBGA-178 package',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The K4E8E304ED-EGCC is an 8 Gb LPDDR3 SDRAM organised as 256 M x 32 in an FBGA-178 package. It runs at 1866 Mbps with a 1.8 V VDD1 rail and a 1.2 V VDD2/VDDQ rail. The rated operating range is -25 \u00b0C to 85 \u00b0C. The device follows JEDEC JESD209-3, the LPDDR3 standard. It is used in tablet computers, TV boxes, automotive centre consoles, industrial tablets, AI cameras and POS terminals.',
    img: '/assets/images/k4e8e304ed-egcc-package.jpg',
    alt: 'An FBGA-178 package, the package used for the K4E8E304ED-EGCC',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Memory type', 'LPDDR3 SDRAM'],
      ['Density', '8 Gb (256 M x 32)'],
      ['Data bus width', '32 bit'],
      ['Data rate', '1866 Mbps'],
      ['Case package', 'FBGA-178'],
      ['Supply voltage (VDD1)', '1.8 V'],
      ['Supply voltage (VDD2/VDDQ)', '1.2 V'],
      ['Operating temperature', '-25 \u00b0C to 85 \u00b0C'],
      ['Mount', 'Surface mount'],
      ['Memory standard', 'JEDEC JESD209-3'],
    ],
    about: 'The K4E8E304ED-EGCC is a Samsung 8 Gb LPDDR3 SDRAM device in an FBGA-178 package. It stores 8 Gb as 256 M x 32 and runs at 1866 Mbps, with a 1.8 V VDD1 rail and a 1.2 V VDD2/VDDQ rail. The rated operating range is -25 \u00b0C to 85 \u00b0C and the device is built to JEDEC JESD209-3. It is used in tablet computers, TV boxes, automotive centre consoles, industrial tablets, AI cameras and POS terminals. Because LPDDR3 is phasing out, buyers should confirm the SoC DDR support list and long-term supply before design release.',
    standards: [
      'Samsung LPDDR3 SDRAM, JEDEC JESD209-3',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '8 Gb density arranged as 256 M x 32',
      '1866 Mbps data rate',
      '1.8 V VDD1 and 1.2 V VDD2/VDDQ rails',
      'FBGA-178 surface-mount package',
      'Rated -25 \u00b0C to 85 \u00b0C',
      '32 bit wide data bus',
      'JEDEC JESD209-3 compliant',
    ],
    applications: [
      'Tablet computers',
      'TV boxes',
      'Automotive centre consoles',
      'Industrial tablets',
      'AI cameras',
      'POS terminals',
    ],
    faq: [
      {
        q: 'What is the K4E8E304ED-EGCC used for?',
        a: 'It is a 32 bit wide LPDDR3 chip used in tablet computers, TV boxes, automotive centre consoles, industrial tablets, AI cameras and POS terminals. Its 8 Gb density in an FBGA-178 package suits compact boards that run a 32 bit memory bus.',
      },
      {
        q: 'What do buyers check before ordering a K4E8E304ED-EGCC?',
        a: 'Buyers verify that the SoC DDR support list, for example a Rockchip, Allwinner or MediaTek platform, names this exact part, and they ask about interchangeability with the Nanya NT6CL series. They also ask how to identify original factory product, how long supply can be supported as LPDDR3 phases out, and what the price and lot consistency will be.',
      },
      {
        q: 'How does YIXINOU check a K4E8E304ED-EGCC before it ships?',
        a: 'Each FBGA-178 lot is inspected before shipment. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Lot code and packing quantity are checked against the order before the parts are sealed.',
      },
    ],
  },
  'K4F6E3S4HB-MGCL': {
    mpn: 'K4F6E3S4HB-MGCL',
    brand: 'Samsung',
    title: 'LPDDR4X SDRAM 16 Gb x32 chip in an FBGA-200 package',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / LPDDR',
    categoryHref: '/all-products',
    summary: 'The K4F6E3S4HB-MGCL is a 16 Gb LPDDR4X SDRAM organised as 512 M x 32 in an FBGA-200 package. It runs at 4266 Mbps (4266 MHz) with a 3.5 ns access time, from a 1.8 V VDD1 rail and a 1.1 V VDD2/VDDQ rail. The peer supply windows are 1.7 V to 1.95 V on VDD1 and 1.06 V to 1.17 V on VDD2/VDDQ. The operating range is -25 \u00b0C to 85 \u00b0C and the device follows JEDEC JESD209-4. It is used in smartphones, tablets, automotive centre consoles, smart speakers, wearables and edge AI modules.',
    img: '/assets/images/k4f6e3s4hb-mgcl-fbga-200.jpg',
    alt: 'An FBGA-200 package, the package used for the K4F6E3S4HB-MGCL',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Memory type', 'LPDDR4X SDRAM, synchronous'],
      ['Density', '16 Gb (512 M x 32)'],
      ['Data bus width', '32 bit'],
      ['Data rate', '4266 Mbps (4266 MHz)'],
      ['Case package', 'FBGA-200 (200 balls, surface mount)'],
      ['Supply voltage (VDD1)', '1.7 V to 1.95 V (1.8 V nominal)'],
      ['Supply voltage (VDD2/VDDQ)', '1.06 V to 1.17 V (1.1 V nominal)'],
      ['Operating temperature', '-25 \u00b0C to 85 \u00b0C'],
      ['Access time', '3.5 ns'],
      ['Mount', 'Surface mount'],
    ],
    about: 'The K4F6E3S4HB-MGCL is a Samsung 16 Gb LPDDR4X SDRAM device in an FBGA-200 package. It stores 16 Gb as 512 M x 32 and runs at 4266 Mbps with a 3.5 ns access time. The supply rails are 1.8 V on VDD1, with a peer window of 1.7 V to 1.95 V, and 1.1 V on VDD2/VDDQ, with a peer window of 1.06 V to 1.17 V. The rated operating range is -25 \u00b0C to 85 \u00b0C and the device follows JEDEC JESD209-4. It is aimed at smartphones, tablets, automotive centre consoles, smart speakers, wearable devices and edge AI modules.',
    standards: [
      'Samsung LPDDR4X SDRAM, JEDEC JESD209-4',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '16 Gb density arranged as 512 M x 32',
      '4266 Mbps data rate at 4266 MHz',
      '1.8 V VDD1 and 1.1 V VDD2/VDDQ rails',
      'FBGA-200 surface-mount package',
      '3.5 ns access time',
      'Rated -25 \u00b0C to 85 \u00b0C',
      '32 bit wide data bus',
      'JEDEC JESD209-4 compliant',
    ],
    applications: [
      'Smartphones',
      'Tablets',
      'Automotive centre consoles',
      'Smart speakers',
      'Wearable devices',
      'Edge AI modules',
    ],
    faq: [
      {
        q: 'What is the K4F6E3S4HB-MGCL used for?',
        a: 'It is a 32 bit wide LPDDR4X chip for smartphones, tablets, automotive centre consoles, smart speakers, wearable devices and edge AI modules. Its 16 Gb density and 4266 Mbps rate suit space-constrained designs that need a wide, fast memory bus.',
      },
      {
        q: 'What do buyers check before ordering a K4F6E3S4HB-MGCL?',
        a: 'Buyers confirm what the -MGCL suffix means for speed and temperature grade, using the manufacturer coding table, and that the SoC DDR support list matches this part. They also ask whether the parts are original factory die or white-label chips, how LPDDR4X compares with LPDDR5 for the design, and what the price, MOQ and lot consistency will be.',
      },
      {
        q: 'How does YIXINOU check a K4F6E3S4HB-MGCL before it ships?',
        a: 'Every FBGA-200 lot is checked before it leaves us. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. The suffix code, lot marking and quantity are verified against the order before packing.',
      },
    ],
  },
  'K4RAH086VB-BIWM': {
    mpn: 'K4RAH086VB-BIWM',
    brand: 'Samsung',
    title: 'DDR5 SDRAM 16 Gb x8 chip in an FBGA-102 package',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The K4RAH086VB-BIWM is a 16 Gb DDR5 SDRAM organised as 2 G x 8 in an FBGA-102 package. It runs at 5600 Mbps from a 1.1 V VDD/VDDQ rail with a 1.8 V VPP. The rated operating range is -40 \u00b0C to 95 \u00b0C and the device follows JEDEC JESD79-5, the DDR5 standard. The catalogued MPN carries a trailing D, and the valid ordering code is K4RAH086VB-BIWM, so the number should be confirmed before ordering. It is used in server DDR5 RDIMMs, industrial computers, data centres and high performance computing.',
    img: '/assets/images/k4rah086vb-biwm-fbga-102.jpg',
    alt: 'An FBGA-102 package, the package used for the K4RAH086VB-BIWM',
    imageNote: 'Illustrative package image. Ask us for a photograph of the actual lot.',
    specs: [
      ['Memory type', 'DDR5 SDRAM'],
      ['Density', '16 Gb (2 G x 8)'],
      ['Data bus width', '8 bit'],
      ['Data rate', '5600 Mbps'],
      ['Case package', 'FBGA-102'],
      ['Supply voltage (VDD/VDDQ)', '1.1 V'],
      ['Peak supply voltage (VPP)', '1.8 V'],
      ['Operating temperature', '-40 \u00b0C to 95 \u00b0C'],
      ['Mount', 'Surface mount'],
      ['Memory standard', 'JEDEC JESD79-5'],
    ],
    about: 'The K4RAH086VB-BIWM is a Samsung 16 Gb DDR5 SDRAM device in an FBGA-102 package. It stores 16 Gb as 2 G x 8 and runs at 5600 Mbps from a 1.1 V VDD/VDDQ rail with a 1.8 V VPP. The rated operating range is -40 \u00b0C to 95 \u00b0C and the device follows JEDEC JESD79-5, the DDR5 standard. The catalogued MPN carries a trailing D while the valid ordering code is K4RAH086VB-BIWM, so the number must be confirmed with the supplier before ordering. Typical uses are server DDR5 RDIMMs, industrial computers, data centres and high performance computing.',
    standards: [
      'Samsung DDR5 SDRAM, JEDEC JESD79-5',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '16 Gb density arranged as 2 G x 8',
      '5600 Mbps data rate',
      '1.1 V VDD/VDDQ with a 1.8 V VPP',
      'FBGA-102 surface-mount package',
      'Rated -40 \u00b0C to 95 \u00b0C',
      'x8 organisation suited to server modules',
      'JEDEC JESD79-5 compliant',
      'Valid ordering code K4RAH086VB-BIWM; the catalogued MPN carries a trailing D',
    ],
    applications: [
      'Server DDR5 RDIMM modules',
      'Industrial computers',
      'Data centres',
      'High performance computing',
    ],
    faq: [
      {
        q: 'What is the K4RAH086VB-BIWM used for?',
        a: 'It is an x8 DDR5 chip for server DDR5 RDIMMs, industrial computers, data centres and high performance computing. The x8 width and 5600 Mbps rate suit registered server modules that are built from many devices.',
      },
      {
        q: 'What do buyers check before ordering a K4RAH086VB-BIWM?',
        a: 'Buyers confirm the part number first, because the catalogued MPN carries a trailing D and the valid ordering code is K4RAH086VB-BIWM. They also ask about DDR5 down-clocking when modules are mixed, whether the parts are original factory product or white-label chips, platform QVL approval, price volatility and lock-in terms, and lot consistency.',
      },
      {
        q: 'How does YIXINOU check a K4RAH086VB-BIWM before it ships?',
        a: 'Each FBGA-102 lot is inspected before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. The exact ordering code, lot marking and date code are confirmed against the order before packing.',
      },
    ],
  },
  'K4RAH165VB-BIQK': {
    mpn: 'K4RAH165VB-BIQK',
    brand: 'Samsung',
    title: 'DDR5 SDRAM 16 Gb x16 chip in an FBGA-102 package',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The K4RAH165VB-BIQK is a 16 Gb DDR5 SDRAM organised as 1 G x 16 in an FBGA-102 package. It runs at 4800 Mbps from a 1.1 V VDD/VDDQ rail with a 1.8 V VPP. The rated operating range is -40 \u00b0C to 95 \u00b0C and the device follows JEDEC JESD79-5. The x16 organisation differs from x8 parts in memory module design, so the module topology has to be planned accordingly. Typical uses are server and workstation DDR5 memory modules, industrial computing, and data centre and edge servers.',
    img: '/assets/images/k4rah165vb-biqk-package.jpg',
    alt: 'An FBGA-102 package, the package used for the K4RAH165VB-BIQK',
    imageNote: 'Illustrative package image. Ask us for a photograph of the actual lot.',
    specs: [
      ['Memory type', 'DDR5 SDRAM'],
      ['Density', '16 Gb (1 G x 16)'],
      ['Data bus width', '16 bit'],
      ['Data rate', '4800 Mbps'],
      ['Case package', 'FBGA-102'],
      ['Supply voltage (VDD/VDDQ)', '1.1 V'],
      ['Peak supply voltage (VPP)', '1.8 V'],
      ['Operating temperature', '-40 \u00b0C to 95 \u00b0C'],
      ['Mount', 'Surface mount'],
      ['Memory standard', 'JEDEC JESD79-5'],
    ],
    about: 'The K4RAH165VB-BIQK is a Samsung 16 Gb DDR5 SDRAM device in an FBGA-102 package. It stores 16 Gb as 1 G x 16 and runs at 4800 Mbps from a 1.1 V VDD/VDDQ rail with a 1.8 V VPP. The rated operating range is -40 \u00b0C to 95 \u00b0C and the device follows JEDEC JESD79-5, the DDR5 standard. The x16 organisation differs from x8 parts in memory module design, so the module topology has to be planned accordingly. Typical uses are server and workstation DDR5 memory modules, industrial computing, and data centre and edge servers.',
    standards: [
      'Samsung DDR5 SDRAM, JEDEC JESD79-5',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '16 Gb density arranged as 1 G x 16',
      '4800 Mbps data rate',
      '1.1 V VDD/VDDQ with a 1.8 V VPP',
      'FBGA-102 surface-mount package',
      'Rated -40 \u00b0C to 95 \u00b0C',
      'x16 organisation with a 16 bit data bus',
      'JEDEC JESD79-5 compliant',
    ],
    applications: [
      'Server and workstation DDR5 memory modules',
      'Industrial computing',
      'Data centre servers',
      'Edge servers',
    ],
    faq: [
      {
        q: 'What is the K4RAH165VB-BIQK used for?',
        a: 'It is an x16 DDR5 chip for server and workstation DDR5 memory modules, industrial computing, and data centre and edge servers. The x16 organisation changes module design compared with x8 parts, so both options should be reviewed against the module topology.',
      },
      {
        q: 'What do buyers check before ordering a K4RAH165VB-BIQK?',
        a: 'Buyers ask us to confirm the exact speed grade of the BIQK suffix against the manufacturer coding table or datasheet. They also compare x16 with x8 module design, check for original factory product rather than white-label chips, and ask about DDR5 platform compatibility approval, price volatility, long-term supply and lot consistency.',
      },
      {
        q: 'How does YIXINOU check a K4RAH165VB-BIQK before it ships?',
        a: 'Every FBGA-102 lot is verified before it leaves us. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. The suffix, lot marking and date code are matched to the order before packing.',
      },
    ],
  },
  'K4RAH165VP-BCWM': {
    mpn: 'K4RAH165VP-BCWM',
    brand: 'Samsung',
    title: 'DDR5 SDRAM 16 Gb x16 chip in an FBGA-106 package',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / DDR',
    categoryHref: '/all-products',
    summary: 'The K4RAH165VP-BCWM is a 16 Gb DDR5 SDRAM organised as 1 G x 16 in an FBGA-106 package. It runs at 5600 Mbps (5600 MHz) from a 1.1 V nominal supply, with a peer window of 950 mV to 1.15 V, and VPP is 1.8 V. Data bus width is 16 bit and the peer operating range is 0 \u00b0C to 85 \u00b0C. The device follows JEDEC JESD79-5 and ships 5,120 pieces per package. Typical uses are server and workstation DDR5 memory modules, data centres, industrial computers and AI computing platforms.',
    img: '/assets/images/k4rah165vp-bcwm-fbga-106.jpg',
    alt: 'An FBGA-106 package, the package used for the K4RAH165VP-BCWM',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Memory type', 'DDR5 SDRAM'],
      ['Density', '16 Gb (1 G x 16)'],
      ['Data bus width', '16 bit'],
      ['Data rate', '5600 Mbps (5600 MHz)'],
      ['Case package', 'FBGA-106 (106 balls, surface mount)'],
      ['Supply voltage', '950 mV to 1.15 V (1.1 V nominal)'],
      ['Peak supply voltage (VPP)', '1.8 V'],
      ['Operating temperature', '0 \u00b0C to 85 \u00b0C'],
      ['Mount', 'Surface mount'],
      ['Packing quantity', '5,120 per package'],
    ],
    about: 'The K4RAH165VP-BCWM is a Samsung 16 Gb DDR5 SDRAM device in an FBGA-106 package. It stores 16 Gb as 1 G x 16 and runs at 5600 Mbps, or 5600 MHz, from a 1.1 V nominal supply with a peer window of 950 mV to 1.15 V, plus a 1.8 V VPP. Data bus width is 16 bit and the peer operating range is 0 \u00b0C to 85 \u00b0C. The device follows JEDEC JESD79-5 and ships 5,120 pieces per package. Typical uses are server and workstation DDR5 memory modules, data centres, industrial computers and AI computing platforms.',
    standards: [
      'Samsung DDR5 SDRAM, JEDEC JESD79-5',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '16 Gb density arranged as 1 G x 16',
      '5600 Mbps data rate at 5600 MHz',
      '1.1 V nominal supply with a 1.8 V VPP',
      'FBGA-106 surface-mount package',
      'Rated 0 \u00b0C to 85 \u00b0C',
      '16 bit data bus, 5,120 pieces per package',
      'JEDEC JESD79-5 compliant',
    ],
    applications: [
      'Server and workstation DDR5 memory modules',
      'Data centres',
      'Industrial computers',
      'AI computing platforms',
    ],
    faq: [
      {
        q: 'What is the K4RAH165VP-BCWM used for?',
        a: 'It is a 16 bit DDR5 chip for server and workstation DDR5 memory modules, data centres, industrial computers and AI computing platforms. Its 5600 Mbps rate can also run at 4800 on platforms that only support the lower speed.',
      },
      {
        q: 'What do buyers check before ordering a K4RAH165VP-BCWM?',
        a: 'Buyers ask how the VP version differs from the common VB version, because that has to be confirmed with the manufacturer. They also check that a 5600 Mbps part can run at 4800 where the platform requires it, whether the parts are original factory product, platform compatibility and memory QVL approval, price and lead time, and lot consistency.',
      },
      {
        q: 'How does YIXINOU check a K4RAH165VP-BCWM before it ships?',
        a: 'Each FBGA-106 lot is checked before shipment. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Version code, lot marking and packing quantity are recorded against the ordered MPN.',
      },
    ],
  },
  'K4RHE086VB-BCWM': {
    mpn: 'K4RHE086VB-BCWM',
    brand: 'Samsung',
    title: 'DDR5 SDRAM 24 Gb x8 chip in an FBGA-102 package',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The K4RHE086VB-BCWM is a 24 Gb DDR5 SDRAM organised as 3 G x 8 in an FBGA-102 package. It runs at 5600 Mbps from a 1.1 V VDD/VDDQ rail with a 1.8 V VPP. Data bus width is 8 bit and the rated operating range is 0 \u00b0C to 95 \u00b0C. The device follows JEDEC JESD79-5, the DDR5 standard. Typical uses are server DDR5 RDIMM and UDIMM modules, industrial computers, data centres and AI inference servers, where the higher 24 Gb density allows fewer devices per module.',
    img: '/assets/images/k4rhe086vb-bcwm-package.jpg',
    alt: 'An FBGA-102 package, the package used for the K4RHE086VB-BCWM',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Memory type', 'DDR5 SDRAM'],
      ['Density', '24 Gb (3 G x 8)'],
      ['Data bus width', '8 bit'],
      ['Data rate', '5600 Mbps'],
      ['Case package', 'FBGA-102'],
      ['Supply voltage (VDD/VDDQ)', '1.1 V'],
      ['Peak supply voltage (VPP)', '1.8 V'],
      ['Operating temperature', '0 \u00b0C to 95 \u00b0C'],
      ['Mount', 'Surface mount'],
      ['Memory standard', 'JEDEC JESD79-5'],
    ],
    about: 'The K4RHE086VB-BCWM is a Samsung 24 Gb DDR5 SDRAM device in an FBGA-102 package. It stores 24 Gb as 3 G x 8 and runs at 5600 Mbps from a 1.1 V VDD/VDDQ rail with a 1.8 V VPP. Data bus width is 8 bit and the rated operating range is 0 \u00b0C to 95 \u00b0C. The device follows JEDEC JESD79-5, the DDR5 standard. Typical uses are server DDR5 RDIMM and UDIMM modules, industrial computers, data centres and AI inference servers, where the higher 24 Gb density allows fewer devices per module.',
    standards: [
      'Samsung DDR5 SDRAM, JEDEC JESD79-5',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '24 Gb density arranged as 3 G x 8',
      '5600 Mbps data rate',
      '1.1 V VDD/VDDQ with a 1.8 V VPP',
      'FBGA-102 surface-mount package',
      'Rated 0 \u00b0C to 95 \u00b0C',
      '8 bit data bus for server module builds',
      'JEDEC JESD79-5 compliant',
    ],
    applications: [
      'Server DDR5 RDIMM and UDIMM modules',
      'Industrial computers',
      'Data centres',
      'AI inference servers',
    ],
    faq: [
      {
        q: 'What is the K4RHE086VB-BCWM used for?',
        a: 'It is an x8 DDR5 chip for server DDR5 RDIMM and UDIMM modules, industrial computers, data centres and AI inference servers. The 24 Gb density allows fewer devices per module while keeping the 5600 Mbps rate.',
      },
      {
        q: 'What do buyers check before ordering a K4RHE086VB-BCWM?',
        a: 'Buyers check how the K4RHE series differs from K4RAH in application, using the manufacturer selection table. They also confirm 5600 Mbps platform compatibility, ask for original factory product rather than white-label chips, and need module-maker QVL approval along with price, lead time and lot consistency.',
      },
      {
        q: 'How does YIXINOU check a K4RHE086VB-BCWM before it ships?',
        a: 'Every FBGA-102 lot is inspected before it is released. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Series code, lot marking and quantity are verified against the order before packing.',
      },
    ],
  },
  'K4S643232H-UC60': {
    mpn: 'K4S643232H-UC60',
    brand: 'Samsung',
    title: 'SDRAM 64 Mb x32 chip in an 86-pin TSOP II package',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / SDRAM',
    categoryHref: '/all-products',
    summary: 'The K4S643232H-UC60 is a 64 Mb SDRAM organised as 2 M x 32 in an 86-pin TSOP II package. It runs at 166 MHz with CL=3, holds a 6 ns access time, and works from a 3 V to 3.6 V supply, nominally 3.3 V. The rated operating range is 0 \u00b0C to +70 \u00b0C and the device is synchronous and surface mounted with a 32 bit data bus. It is built to JEDEC JESD21-C, and the peer record lists it as lead free and RoHS compliant. The part has long been discontinued, so supply is stock or salvaged material.',
    img: '/assets/images/k4s643232h-uc60-tsop-ii-86.jpg',
    alt: 'An 86-pin TSOP II package, the package used for the K4S643232H-UC60',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Memory type', 'SDRAM, synchronous'],
      ['Density', '64 Mb (2 M x 32)'],
      ['Data bus width', '32 bit'],
      ['Clock frequency', '166 MHz (CL=3)'],
      ['Case package', 'TSOP-II, 86 pins'],
      ['Supply voltage', '3 V to 3.6 V (3.3 V nominal)'],
      ['Operating temperature', '0 \u00b0C to +70 \u00b0C'],
      ['Access time', '6 ns'],
      ['Mount', 'Surface mount'],
      ['Lead free and RoHS', 'Lead free, RoHS compliant'],
    ],
    about: 'The K4S643232H-UC60 is a Samsung 64 Mb SDRAM device in an 86-pin TSOP II package. It is organised as 2 M x 32, runs at 166 MHz with CL=3, and holds a 6 ns access time. Supply is 3 V to 3.6 V, nominally 3.3 V, and the rated operating range is 0 \u00b0C to +70 \u00b0C. It is built to JEDEC JESD21-C and the peer record lists it as lead free and RoHS compliant. Typical uses are legacy network equipment, industrial control boards, printers, set-top boxes, and repair or replacement of existing industrial boards.',
    standards: [
      'Samsung SDRAM, JEDEC JESD21-C',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '64 Mb density arranged as 2 M x 32',
      '166 MHz clock with CL=3',
      '3.3 V nominal supply, 3 V to 3.6 V range',
      '86-pin TSOP II surface-mount package',
      '6 ns access time',
      'Rated 0 \u00b0C to +70 \u00b0C',
      'Lead free and RoHS compliant',
      'JEDEC JESD21-C compliant',
    ],
    applications: [
      'Legacy network equipment',
      'Industrial control boards',
      'Printers',
      'Set-top boxes',
      'Repair and replacement of existing industrial boards',
    ],
    faq: [
      {
        q: 'What is the K4S643232H-UC60 used for?',
        a: 'It is a 32 bit SDRAM chip used in legacy network equipment, industrial control boards, printers, set-top boxes, and repair or replacement work on existing industrial boards. Its 64 Mb density and 86-pin TSOP II footprint match the older sockets these boards were designed around.',
      },
      {
        q: 'What do buyers check before ordering a K4S643232H-UC60?',
        a: 'Buyers confirm that material for this long-discontinued part is genuine and not refurbished, and ask whether it is original factory product or white-label or polished chips. They also check the moisture sensitivity level, because these parts need baking and vacuum packing, inspect pin and package condition since TSOP packages can deform, and agree MOQ, full-package quantity and any DDR alternative.',
      },
      {
        q: 'How does YIXINOU check a K4S643232H-UC60 before it ships?',
        a: 'Each 86-pin TSOP II lot is checked before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Lead condition, marking and date code are inspected and recorded against the ordered MPN.',
      },
    ],
  },
  'LCMXO3LF-4300C-5BG256I': {
    mpn: 'LCMXO3LF-4300C-5BG256I',
    brand: 'Lattice Semiconductor',
    title: 'MachXO3LF 4300 LUT FPGA in a 256-ball caBGA package, industrial grade',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Field Programmable Gate Arrays (FPGAs)',
    categoryHref: '/all-products',
    summary: 'The LCMXO3LF-4300C-5BG256I is a Lattice MachXO3LF FPGA with 4,300 LUT logic capacity in a 256-ball caBGA package measuring 14 x 14 mm. It provides 540 logic blocks, 206 user I/O, 92 kbit of EBR and 96 kbit of UFM user flash, plus PLL/DLL clock resources. The C device core runs from 2.5 V to 3.3 V and the I grade part is rated -40 \u00b0C to 100 \u00b0C. Configuration memory is on-chip non-volatile flash, so the device is ready at power-up with no external configuration chip. It follows the Lattice MachXO3 family data sheet FPGA-DS-02032-3.1.',
    img: '/assets/images/lcmxo3lf-4300c-5bg256i-package-256.jpg',
    alt: 'A 256-ball caBGA package, the package used for the LCMXO3LF-4300C-5BG256I',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Logic capacity', '4,320 logic elements/cells (540 logic blocks)'],
      ['Embedded block RAM (EBR)', '92 kbit'],
      ['User flash memory (UFM)', '96 kbit'],
      ['User I/O', '206'],
      ['Speed grade', '5'],
      ['Core voltage', '2.5 V to 3.3 V (C device)'],
      ['Case package', 'caBGA-256 (256 balls, 14 x 14 mm)'],
      ['Operating temperature', '-40 \u00b0C to 100 \u00b0C (industrial, I grade)'],
      ['Configuration memory', 'On-chip non-volatile flash, ready at power-up'],
      ['Mount', 'Surface mount'],
    ],
    about: 'The LCMXO3LF-4300C-5BG256I is a Lattice MachXO3LF FPGA with 4,300 LUT logic capacity in a 256-ball caBGA package. It offers 540 logic blocks, 92 kbit of EBR, 96 kbit of UFM user flash, 206 user I/O and PLL/DLL clock resources, and its on-chip non-volatile flash is ready at power-up with no external configuration device. The C device core runs from 2.5 V to 3.3 V and the I grade part is rated -40 \u00b0C to 100 \u00b0C. Typical uses are bridging and interface conversion, power management sequencing, display panel driving, industrial control and glue logic in communications equipment.',
    standards: [
      'Lattice FPGA-DS-02032-3.1, MachXO3 Family Data Sheet, 2021-07',
      'RoHS compliant and halogen free, REACH compliant',
      'JEDEC package standards and JESD65',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '4,300 LUT MachXO3LF logic capacity, 540 logic blocks',
      '92 kbit EBR and 96 kbit UFM user flash',
      '206 user I/O and PLL/DLL clock resources',
      '256-ball caBGA package, 14 x 14 mm',
      'Core voltage 2.5 V to 3.3 V for the C device',
      'Industrial I grade, -40 \u00b0C to 100 \u00b0C',
      'On-chip non-volatile configuration memory, no external config chip',
      'Speed grade 5',
    ],
    applications: [
      'Bridging and interface conversion',
      'Power management sequencing',
      'Display panel driving',
      'Industrial control',
      'Glue logic in communications equipment',
    ],
    faq: [
      {
        q: 'What is the LCMXO3LF-4300C-5BG256I used for?',
        a: 'It is used for bridging and interface conversion, power management sequencing, display panel driving, industrial control and glue logic in communications equipment. Because configuration is stored in on-chip non-volatile flash, the board needs no external configuration device.',
      },
      {
        q: 'What do buyers check before ordering an LCMXO3LF-4300C-5BG256I?',
        a: 'Buyers confirm what the C and LF suffixes mean, that the I grade industrial temperature range is the one required, and that LUT, EBR and I/O resources leave at least 20 percent headroom for the design. They also ask about Diamond development tool licensing, price and lead time.',
      },
      {
        q: 'How does YIXINOU check an LCMXO3LF-4300C-5BG256I before it ships?',
        a: 'Every 256-ball caBGA lot is verified before it leaves us. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Speed grade, temperature grade and lot marking are checked against the ordered part number.',
      },
    ],
  },
  'LPC1225FBD64-301': {
    mpn: 'LPC1225FBD64/301',
    brand: 'NXP Semiconductors',
    title: 'LPC1200 series 32-bit ARM Cortex-M0 microcontroller in a 64-pin LQFP package',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The LPC1225FBD64/301 is an NXP LPC1200 series 32-bit microcontroller with an ARM Cortex-M0 core running at up to 30 MHz, supplied in a 64-pin LQFP package. The specification line for this part lists 64 kB of flash and 8 kB of SRAM, while the product name lists 80 kB of flash, so the exact /301 configuration should be confirmed against the NXP selector table. The rated operating range is -40 \u00b0C to +85 \u00b0C. The device is RoHS compliant and is aimed at cost-sensitive control designs.',
    img: '/assets/images/lpc1225fbd64-301-package.jpg',
    alt: 'A 64-pin LQFP package, the package used for the LPC1225FBD64/301',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Core', 'ARM Cortex-M0, 32-bit'],
      ['Maximum clock frequency', '30 MHz'],
      ['Flash memory', '64 kB (product name lists 80 kB; confirm the /301 configuration)'],
      ['SRAM', '8 kB'],
      ['Case package', 'LQFP-64 (64 pins)'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C'],
      ['Mount', 'Surface mount'],
      ['Device family', 'NXP LPC1200 series'],
      ['Configuration suffix', '/301 - specific configuration version, check against the NXP selector table'],
      ['RoHS', 'Compliant'],
    ],
    about: 'The LPC1225FBD64/301 is an NXP LPC1200 series 32-bit microcontroller built on an ARM Cortex-M0 core running at up to 30 MHz and supplied in a 64-pin LQFP package. The specification line for this part lists 64 kB of flash and 8 kB of SRAM, while the product name lists 80 kB of flash, so the exact /301 configuration should be confirmed against the NXP selector table. The rated operating range is -40 \u00b0C to +85 \u00b0C and the device is RoHS compliant. Typical uses are industrial control, white goods, power management, lighting control, sensor nodes and low-cost gateways.',
    standards: [
      'NXP LPC1200 series 32-bit MCU, RoHS',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'ARM Cortex-M0 32-bit core at up to 30 MHz',
      '64 kB flash in the specification line and 8 kB SRAM',
      '64-pin LQFP surface-mount package',
      'Rated -40 \u00b0C to +85 \u00b0C',
      '/301 configuration version, checked against the NXP selector table',
      'LPC1200 series device family',
      'RoHS compliant',
    ],
    applications: [
      'Industrial control',
      'White goods',
      'Power management',
      'Lighting control',
      'Sensor nodes',
      'Low-cost gateways',
    ],
    faq: [
      {
        q: 'What is the LPC1225FBD64/301 used for?',
        a: 'It is a 32-bit Cortex-M0 microcontroller used in industrial control, white goods, power management, lighting control, sensor nodes and low-cost gateways. Its memory footprint and 64-pin LQFP package suit compact control boards with modest memory needs.',
      },
      {
        q: 'What do buyers check before ordering an LPC1225FBD64/301?',
        a: 'Buyers confirm what the /301 suffix means, because it is a specific configuration version that must be checked against the NXP selector table. They also assess whether the Cortex-M0 memory size fits the application code, compare LPC11xx and comparable 32-bit Cortex-M0 alternatives, verify supply of genuine parts, watch the NXP product lifecycle and EOL notices, and agree price.',
      },
      {
        q: 'How does YIXINOU check an LPC1225FBD64/301 before it ships?',
        a: 'Each 64-pin LQFP lot is checked before shipment. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. The /301 suffix, lot marking and date code are verified against the ordered part number.',
      },
    ],
  },
  'LT3045EDD': {
    mpn: 'LT3045EDD',
    brand: 'Analog Devices',
    title: 'Ultra-low-noise, ultra-high PSRR 500 mA linear regulator (LDO)',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The LT3045EDD is an Analog Devices ultra-low-noise, ultra-high PSRR linear regulator rated for 500 mA. Output noise is 0.8 uV RMS and power supply rejection reaches 76 dB at 1 MHz, which keeps switching residue away from sensitive loads. The device is rated at 20 V and works from -40 \u00b0C to +125 \u00b0C. It is supplied in a 10-lead DFN package measuring 3 x 3 mm. Output voltage and current monitoring are set with external resistors.',
    img: '/assets/images/lt3045edd-package.jpg',
    alt: 'A 10-lead DFN package, the package used for the LT3045EDD',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Function', 'Ultra-low-noise linear regulator (LDO)'],
      ['Output current', '500 mA'],
      ['Voltage rating', '20 V'],
      ['Output noise', '0.8 uV RMS'],
      ['PSRR', '76 dB at 1 MHz'],
      ['Package', '10-lead DFN (3 x 3 mm)'],
      ['Operating temperature', '-40 \u00b0C to +125 \u00b0C'],
      ['Output voltage setting', 'Set by an external resistor'],
      ['Current monitoring', 'External resistor network'],
      ['Compliance', 'RoHS'],
    ],
    about: 'The LT3045EDD is an Analog Devices ultra-low-noise, ultra-high PSRR linear regulator delivering up to 500 mA at a 20 V rating. Output noise is 0.8 uV RMS and power supply rejection is 76 dB at 1 MHz, so the part keeps switching residue out of sensitive rails. It comes in a 10-lead DFN package of 3 x 3 mm and is rated from -40 \u00b0C to +125 \u00b0C. Output voltage and current monitoring are set with external resistors, making it useful as a post-regulator behind a switching supply. It serves instrumentation, medical equipment, RF and ADC rails, audio, test and measurement and sensor signal chains.',
    standards: ['RoHS compliant', 'ESD-sensitive device \u2014 handle under ESD-protected conditions'],
    features: [
      'Ultra-low output noise of 0.8 uV RMS',
      'Ultra-high PSRR of 76 dB at 1 MHz',
      '500 mA output current from a 20 V rating',
      '10-lead DFN package measuring 3 x 3 mm',
      'Operating temperature -40 \u00b0C to +125 \u00b0C',
      'Output voltage set by an external resistor',
      'Current monitoring output for system diagnostics',
      'Suited to use as a post-regulator after a switching supply',
    ],
    applications: [
      'High-precision instrumentation',
      'Medical equipment',
      'RF and ADC supply rails',
      'Audio equipment',
      'Test and measurement',
      'Sensor signal chains',
    ],
    faq: [
      {
        q: 'What is the LT3045EDD used for?',
        a: 'It is used as a low-noise post-regulator on rails that feed noise-sensitive circuits: high-precision instrumentation, medical equipment, RF and ADC supply rails, audio equipment, test and measurement and sensor signal chains. Its 0.8 uV RMS noise and 76 dB PSRR at 1 MHz suit designs where a switching supply has to be cleaned up before an analog stage.',
      },
      {
        q: 'What do buyers check before ordering an LT3045EDD?',
        a: 'Buyers normally check the dropout voltage and the heat the part has to dissipate when it works as a second-stage regulator, the solder quality of the DFN thermal pad, and the external resistors needed to set output voltage and current monitoring. Many also confirm that the stock is genuine original product, because counterfeit LT-series regulators are common, and they compare the LT3042 and ADM7150 as alternatives before agreeing price and lead time.',
      },
      {
        q: 'How does YIXINOU check an LT3045EDD before it ships?',
        a: 'For the 10-lead DFN package we confirm the printed marking, lot and date code and moisture-sensitive packing before the goods leave the warehouse. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'MAX3221CAE': {
    mpn: 'MAX3221CAE',
    brand: 'Analog Devices',
    title: '\u00b115 kV ESD protected RS-232 transceiver with AutoShutdown',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Interface ICs / RS-232, RS-422, RS-485 Interface ICs',
    categoryHref: '/all-products',
    summary: 'The MAX3221CAE is an Analog Devices RS-232 transceiver with one driver and one receiver. It runs from a single 3 V to 5.5 V supply, so a +3.3 V or +5 V rail is enough and no \u00b112 V supply is needed. ESD protection is rated at \u00b115 kV. AutoShutdown reduces the shutdown current to 1 uA while the receiver stays active, and the data rate reaches 235 kbps. The part is supplied in a 16-pin SSOP package rated 0 \u00b0C to +70 \u00b0C.',
    img: '/assets/images/max3221cae-ssop-16.jpg',
    alt: 'A 16-pin SSOP package, the package used for the MAX3221CAE',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Interface', 'RS-232'],
      ['Data rate', '235 kbps'],
      ['Supply voltage', '3 V to 5.5 V'],
      ['Operating temperature', '0 \u00b0C to +70 \u00b0C'],
      ['Package', 'SSOP'],
      ['Number of pins', '16'],
      ['Mount', 'Surface Mount'],
      ['Packaging', 'Bulk'],
      ['Drivers and receivers', '1 driver / 1 receiver'],
      ['Supply current in shutdown', '1 uA'],
    ],
    about: 'The MAX3221CAE is a 1 TX / 1 RX RS-232 transceiver from Analog Devices with AutoShutdown and \u00b115 kV ESD protection. It operates from a single 3 V to 5.5 V supply, so a +3.3 V or +5 V rail is sufficient and no \u00b112 V rail is required; the internal charge pump needs four external 0.1 uF capacitors. AutoShutdown drops the supply current to 1 uA while the receiver stays active, and the data rate reaches 235 kbps. The part comes in a 16-pin SSOP package rated 0 \u00b0C to +70 \u00b0C. It serves industrial serial ports, POS terminals, medical instruments, instrumentation and legacy serial upgrades.',
    standards: [
      'Analog Devices MAX3221/MAX3223/MAX3243 datasheet Rev 10',
      'RoHS compliant',
      'Complies with TIA/EIA-232-F and ITU-T V.28 electrical specifications',
      '\u00b115 kV human body model ESD (IEC 1000-4-2) protection',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'One driver and one receiver (1 TX / 1 RX)',
      'RS-232 interface with a 235 kbps data rate',
      'Single 3 V to 5.5 V supply, no \u00b112 V rail needed',
      'AutoShutdown with 1 uA shutdown current',
      'Receiver remains active during AutoShutdown',
      '\u00b115 kV ESD protection',
      '16-pin SSOP package',
      'Four external 0.1 uF charge-pump capacitors required',
    ],
    applications: [
      'Industrial serial communication',
      'POS terminals',
      'Medical instruments',
      'Instrumentation',
      'Legacy serial upgrades and maintenance',
    ],
    faq: [
      {
        q: 'What is the MAX3221CAE used for?',
        a: 'It provides the RS-232 port on industrial equipment, POS terminals, medical instruments and test gear, and it is also used to upgrade or service the serial port of older machines. The single 3.3 V or 5 V supply and the 1 uA AutoShutdown mode make it convenient where only a low-voltage rail is available and the port stays idle for long periods.',
      },
      {
        q: 'What do buyers check before ordering a MAX3221CAE?',
        a: 'Buyers check that the C-grade temperature range of 0 \u00b0C to +70 \u00b0C matches the application and step up to the E or I grade for industrial use. They also allow for the four external 0.1 uF charge-pump capacitors, confirm how AutoShutdown interacts with their firmware, and compare the part with the MAX3232 and MAX3223 on channel count and shutdown behaviour. Marking changes after the Maxim acquisition by Analog Devices make original-product verification important, and price and EOL status are reviewed as well.',
      },
      {
        q: 'How does YIXINOU check a MAX3221CAE before it ships?',
        a: 'For the 16-pin SSOP package we start by checking the printed marking, pin count and pin-one orientation against the lot paperwork, and we confirm that the moisture barrier packing is intact. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'MT40A512M16TB-083E': {
    mpn: 'MT40A512M16TB-083E',
    brand: 'Micron',
    title: 'DDR4 SDRAM 8 Gb x16 component in FBGA-96',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The MT40A512M16TB-083E is a Micron 8 Gb DDR4 SDRAM component organised as 512M x 16. The -083E speed bin runs at 2400 Mbps with CL17, and the device uses VDD/VDDQ of 1.2 V together with a 2.5 V VPP supply. It is supplied in a 96-ball FBGA package and is rated 0 \u00b0C to 95 \u00b0C. The part follows JEDEC JESD79-4 and is used on PC and industrial memory modules, network equipment, surveillance NVR recorders, industrial computers and embedded mainboards.',
    img: '/assets/images/mt40a512m16tb-083e-package.jpg',
    alt: 'A 96-ball FBGA package, the package used for the MT40A512M16TB-083E',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Memory density', '8 Gb (512M x 16)'],
      ['Memory type', 'DDR4 SDRAM'],
      ['Data width', 'x16'],
      ['Speed', '2400 Mbps'],
      ['Speed bin', '-083E (2400 Mbps, CL17)'],
      ['VDD / VDDQ', '1.2 V'],
      ['VPP', '2.5 V'],
      ['Package', 'FBGA-96'],
      ['Operating temperature', '0 \u00b0C to 95 \u00b0C'],
      ['JEDEC standard', 'JESD79-4'],
    ],
    about: 'The MT40A512M16TB-083E is a Micron DDR4 SDRAM component with an 8 Gb density organised as 512M x 16. The -083E speed bin runs at 2400 Mbps with CL17 latency, and the device is powered from VDD/VDDQ of 1.2 V with a separate 2.5 V VPP rail. It is supplied in a 96-ball FBGA package and is rated 0 \u00b0C to 95 \u00b0C, so the thermal design of the board matters at the top of that range. The part follows JEDEC JESD79-4. It is used on PC and industrial memory modules, in network equipment, surveillance NVR systems, industrial computers and embedded mainboards.',
    standards: ['JESD79-4', 'ESD-sensitive device \u2014 handle under ESD-protected conditions'],
    features: [
      '8 Gb density organised as 512M x 16',
      'DDR4 SDRAM at 2400 Mbps in the -083E speed bin',
      'VDD/VDDQ of 1.2 V with a 2.5 V VPP supply',
      '96-ball FBGA package',
      'Operating temperature 0 \u00b0C to 95 \u00b0C',
      'JEDEC JESD79-4 compliant',
      'CL17 latency for the -083E speed grade',
      'Suited to PC and industrial memory modules',
    ],
    applications: [
      'PC and industrial memory modules',
      'Network equipment',
      'Surveillance NVR systems',
      'Industrial computers',
      'Embedded mainboards',
    ],
    faq: [
      {
        q: 'What is the MT40A512M16TB-083E used for?',
        a: 'It is a memory component for PC and industrial memory modules, network equipment, surveillance NVR recorders, industrial computers and embedded mainboards. Designers choose the -083E bin when they need a 2400 Mbps DDR4 device with a 16-bit bus in a compact 96-ball FBGA footprint.',
      },
      {
        q: 'What do buyers check before ordering an MT40A512M16TB-083E?',
        a: 'Buyers confirm that the -083E speed bin, 2400 Mbps at CL17, matches their platform, and they ask whether the parts are original Micron packaged devices or third-party packaged die, since Micron white-label DDR4 circulates in volume. They also review the thermal design for the 0 \u00b0C to 95 \u00b0C upper limit, end-of-life notices and replacement options, lot traceability, price and lead time.',
      },
      {
        q: 'How does YIXINOU check an MT40A512M16TB-083E before it ships?',
        a: 'For the 96-ball FBGA package we verify the laser marking, the assembly site and the date code against the shipment documents, and we check ball condition and packing. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'MT41K128M16JT-125IT': {
    mpn: 'MT41K128M16JT-125IT',
    brand: 'Micron',
    title: 'DDR3L SDRAM 2 Gb x16, 1600 Mbps, industrial temperature',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / DDR',
    categoryHref: '/all-products',
    summary: 'The MT41K128M16JT-125IT is a Micron DDR3L SDRAM with a 2 Gb density organised as 128M x 16. It runs at 1600 Mbps (DDR3-1600, CL11) and accepts 1.35 V or 1.5 V, with the peer specification giving a 1.283 V to 1.45 V range. The 96-ball FBGA package is rated -40 \u00b0C to +95 \u00b0C, the industrial grade indicated by the IT suffix. The device follows JEDEC JESD79-3 and is used in industrial control, communications base stations, automotive electronics, medical equipment and rugged embedded platforms.',
    img: '/assets/images/mt41k128m16jt-125it-fbga-96.jpg',
    alt: 'A 96-ball FBGA package, the package used for the MT41K128M16JT-125IT',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Memory density', '2 Gb (128M x 16)'],
      ['Memory type', 'DDR3L SDRAM'],
      ['Speed', '1600 Mbps (DDR3-1600, CL11)'],
      ['Supply voltage', '1.283 V to 1.45 V (1.35 V / 1.5 V)'],
      ['Package', 'FBGA'],
      ['Number of pins', '96'],
      ['Mount', 'Surface Mount'],
      ['Operating temperature', '-40 \u00b0C to +95 \u00b0C'],
      ['Series', 'MT41K'],
      ['JEDEC standard', 'JESD79-3'],
    ],
    about: 'The MT41K128M16JT-125IT is a Micron DDR3L SDRAM with a 2 Gb density organised as 128M x 16. It runs at 1600 Mbps with CL11 latency and operates from 1.283 V to 1.45 V, covering both the 1.35 V low-power rail and 1.5 V designs. The IT suffix marks the industrial temperature grade of -40 \u00b0C to +95 \u00b0C, and the device is supplied in a 96-ball FBGA package. It follows JEDEC JESD79-3. Typical uses are industrial control, communications base stations, automotive electronics, medical equipment and rugged embedded platforms that need a long-lived 2 Gb density.',
    standards: ['JEDEC JESD79-3', 'ESD-sensitive device \u2014 handle under ESD-protected conditions'],
    features: [
      '2 Gb density organised as 128M x 16',
      'DDR3L SDRAM running at 1600 Mbps (CL11)',
      '1.283 V to 1.45 V supply, 1.35 V or 1.5 V operation',
      'Industrial temperature range -40 \u00b0C to +95 \u00b0C',
      '96-ball FBGA package',
      'MT41K low-power DDR3L series',
      'JEDEC JESD79-3 compliant',
      'Suited to industrial, communications and automotive designs',
    ],
    applications: [
      'Industrial control',
      'Communications base stations',
      'Automotive electronics',
      'Medical equipment',
      'Rugged embedded platforms',
    ],
    faq: [
      {
        q: 'What is the MT41K128M16JT-125IT used for?',
        a: 'It is used in industrial control equipment, communications base stations, automotive electronics, medical equipment and rugged embedded platforms where a 2 Gb DDR3L device with the industrial temperature range of -40 \u00b0C to +95 \u00b0C is required. The 96-ball FBGA package and the 1600 Mbps data rate suit boards that were designed around the MT41K low-power family.',
      },
      {
        q: 'What do buyers check before ordering an MT41K128M16JT-125IT?',
        a: 'Buyers check the authenticity of the IT industrial temperature grade and the documentation that supports it, because the marking alone does not prove it. With a scarce 2 Gb density they also look at long-term supply, ask whether the parts are original Micron packaging or third-party packaging, and request lot traceability with COC or COA documents. The risk of mixing DDR3L and DDR3 material, price and MOQ are reviewed as well.',
      },
      {
        q: 'How does YIXINOU check an MT41K128M16JT-125IT before it ships?',
        a: 'For the 96-ball FBGA package we check the marking, the date code and the condition of the solder balls against the lot documents, and we confirm that the packing matches the shipped quantity. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'MT41K256M16TW-107': {
    mpn: 'MT41K256M16TW-107',
    brand: 'Micron',
    title: 'DDR3L SDRAM 4 Gb x16, 933 MHz, TFBGA-96',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / DDR',
    categoryHref: '/all-products',
    summary: 'The MT41K256M16TW-107 is a Micron DDR3L SDRAM with a 4 Gb density organised as 256M x 16. It runs at 933 MHz, equivalent to 1866 Mbps DDR3-1866 CL13, and operates from 1.283 V to 1.45 V with 1.35 V typical. The device is supplied in a 96-pin TFBGA package and is rated -40 \u00b0C to +95 \u00b0C. It follows JEDEC JESD79-3 and suits industrial mainboards, communications equipment, automotive electronics, medical instruments and edge gateways.',
    img: '/assets/images/mt41k256m16tw-107-tfbga-96.jpg',
    alt: 'A 96-pin TFBGA package, the package used for the MT41K256M16TW-107',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Memory density', '4 Gb (256M x 16)'],
      ['Memory type', 'DDR3L SDRAM'],
      ['Frequency', '933 MHz'],
      ['Data rate', '1866 Mbps (DDR3-1866, CL13)'],
      ['Supply voltage', '1.283 V to 1.45 V (1.35 V typical)'],
      ['Package', 'TFBGA, 96 pins'],
      ['Mount', 'Surface Mount'],
      ['Operating temperature', '-40 \u00b0C to +95 \u00b0C'],
      ['Series', 'MT41K'],
      ['JEDEC standard', 'JESD79-3'],
    ],
    about: 'The MT41K256M16TW-107 is a Micron DDR3L SDRAM with a 4 Gb density organised as 256M x 16. The device runs at 933 MHz, which corresponds to 1866 Mbps at CL13, and it works from 1.283 V to 1.45 V with 1.35 V as the typical rail, keeping power draw low in always-on equipment. It is supplied in a 96-pin TFBGA package rated -40 \u00b0C to +95 \u00b0C and follows JEDEC JESD79-3. Typical uses are industrial mainboards, communications equipment, automotive electronics, medical instruments and edge gateways.',
    standards: ['JEDEC JESD79-3', 'ESD-sensitive device \u2014 handle under ESD-protected conditions'],
    features: [
      '4 Gb density organised as 256M x 16',
      '933 MHz clock, 1866 Mbps DDR3-1866 at CL13',
      '1.283 V to 1.45 V supply with 1.35 V typical',
      '96-pin TFBGA package',
      'Industrial temperature range -40 \u00b0C to +95 \u00b0C',
      'MT41K low-power DDR3L series',
      'JEDEC JESD79-3 compliant',
      'Suited to mainboards and edge equipment',
    ],
    applications: [
      'Industrial mainboards',
      'Communications equipment',
      'Automotive electronics',
      'Medical instruments',
      'Edge gateways',
    ],
    faq: [
      {
        q: 'What is the MT41K256M16TW-107 used for?',
        a: 'It provides the main memory on industrial mainboards, communications equipment, automotive electronics, medical instruments and edge gateways. The 4 Gb density with a 16-bit bus and the -40 \u00b0C to +95 \u00b0C range are chosen where a low-power 1.35 V DDR3L rail has to keep working in a fanless or sealed enclosure.',
      },
      {
        q: 'What do buyers check before ordering an MT41K256M16TW-107?',
        a: 'Buyers check the difference between the Micron 1.35 V low-power series and the 1.5 V versions, since MT41K and MT41J parts are easy to confuse, and they verify that the 1866 data rate is supported by their platform. They also confirm original Micron packaging rather than third-party assembly, watch for EOL notifications and replacement part numbers, and request lot traceability documents, price and lead time.',
      },
      {
        q: 'How does YIXINOU check an MT41K256M16TW-107 before it ships?',
        a: 'For the 96-pin TFBGA package we examine the top marking, the date code and the ball array, compare them with the shipment paperwork and record the packing condition. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'NCEMAD7B-08G': {
    mpn: 'NCEMAD7B-08G',
    brand: 'Foresee',
    title: 'eMMC 5.0 embedded storage, 8 GB, FBGA-153',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The NCEMAD7B-08G is a Foresee 8 GB eMMC 5.0 embedded multimedia storage device in a 153-ball FBGA package measuring 11.5 x 13 mm. It supports the HS400 bus mode and is rated -25 \u00b0C to +85 \u00b0C. The part follows JEDEC JESD84-B50 and is RoHS compliant. It is used for tablet computers, TV boxes, industrial tablets, automotive centre consoles, smart speakers and AI cameras.',
    img: '/assets/images/ncemad7b-08g-package.jpg',
    alt: 'A 153-ball FBGA package, the package used for the NCEMAD7B-08G',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Memory capacity', '8 GB'],
      ['Storage interface', 'eMMC 5.0'],
      ['Bus mode', 'HS400'],
      ['Package', '153-ball FBGA'],
      ['Package dimensions', '11.5 x 13 mm'],
      ['Operating temperature', '-25 \u00b0C to +85 \u00b0C'],
      ['JEDEC standard', 'JESD84-B50'],
      ['Compliance', 'RoHS'],
      ['Function', 'Embedded boot and data storage'],
      ['Device type', 'Embedded multimedia card (eMMC)'],
    ],
    about: 'The NCEMAD7B-08G is a Foresee eMMC 5.0 embedded multimedia storage device with 8 GB of capacity in a 153-ball FBGA package measuring 11.5 x 13 mm. It supports the HS400 high-speed bus mode and is rated -25 \u00b0C to +85 \u00b0C, and it follows JEDEC JESD84-B50 with RoHS compliance. The part holds both boot code and user data. It is used in tablet computers, TV boxes, industrial tablets, automotive centre consoles, smart speakers, AI cameras and digital signage players.',
    standards: [
      'JEDEC JESD84-B50',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '8 GB eMMC 5.0 embedded storage',
      'HS400 high-speed bus mode',
      '153-ball FBGA package, 11.5 x 13 mm',
      'Operating temperature -25 \u00b0C to +85 \u00b0C',
      'JEDEC JESD84-B50 compliant',
      'RoHS compliant',
      'Holds boot code and user data',
      'Compact footprint for space-limited boards',
    ],
    applications: [
      'Tablet computers',
      'TV boxes',
      'Industrial tablets',
      'Automotive centre consoles',
      'Smart speakers',
      'AI cameras',
    ],
    faq: [
      {
        q: 'What is the NCEMAD7B-08G used for?',
        a: 'It stores the boot code and user data in tablet computers, TV boxes, industrial tablets, automotive centre consoles, smart speakers and AI cameras, and it is also used in digital signage players. Products that need 8 GB of eMMC 5.0 storage with an HS400 interface in a 153-ball FBGA footprint use this part.',
      },
      {
        q: 'What do buyers check before ordering an NCEMAD7B-08G?',
        a: 'The first question is whether the parts are original packaged product, because eMMC white-label and black-label material drives up field return rates. Buyers also check the host SoC eMMC compatibility list, whether older types such as NCEFES88-04G can be replaced by this device with firmware support, write endurance measured in TBW and P/E cycles with power-loss protection, the firmware version and bad-block management, and price, lead time and long-term supply commitments.',
      },
      {
        q: 'How does YIXINOU check an NCEMAD7B-08G before it ships?',
        a: 'For the 153-ball FBGA package we verify the marking, firmware version, lot and date code against the supplier documents and confirm that the packing is unopened. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'NT5CC256M16EP-EK': {
    mpn: 'NT5CC256M16EP-EK',
    brand: 'Nanya',
    title: 'DDR3L SDRAM 4 Gb x16, 1866 Mbps, VFBGA-96',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / DDR',
    categoryHref: '/all-products',
    summary: 'The NT5CC256M16EP-EK is a Nanya 4 Gb DDR3L SDRAM organised as 256M x 16. It runs at 1866 Mbps (DDR3-1866, CL13) and operates from 1.283 V to 1.45 V, with 1.35 V as the typical rail. The 96-pin VFBGA package measures 13 mm x 8 mm on an 800 um terminal pitch and is rated 0 \u00b0C to +95 \u00b0C. The device follows JEDEC JESD79-3, is RoHS compliant and is used in industrial control mainboards, network equipment, digital signage, automotive entertainment and embedded mainboards.',
    img: '/assets/images/nt5cc256m16ep-ek-vfbga-96.jpg',
    alt: 'A 96-pin VFBGA package, the package used for the NT5CC256M16EP-EK',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Memory density', '4 Gb (256M x 16)'],
      ['Memory type', 'DDR3L SDRAM'],
      ['Speed', '1866 Mbps (DDR3-1866, CL13)'],
      ['Supply voltage', '1.283 V to 1.45 V (1.35 V typical)'],
      ['Package', 'VFBGA, 96 pins'],
      ['Mount', 'Surface Mount'],
      ['Operating temperature', '0 \u00b0C to +95 \u00b0C'],
      ['RoHS', 'Compliant'],
      ['Package dimensions', '13 mm x 8 mm, 800 um pitch'],
      ['JEDEC standard', 'JESD79-3'],
    ],
    about: 'The NT5CC256M16EP-EK is a Nanya 4 Gb DDR3L SDRAM organised as 256M x 16 and running at 1866 Mbps with CL13 latency. It operates from 1.283 V to 1.45 V with 1.35 V as the typical rail and is supplied in a 96-pin VFBGA package measuring 13 mm x 8 mm on an 800 um pitch, rated 0 \u00b0C to +95 \u00b0C. The device follows JEDEC JESD79-3 and is RoHS compliant. It is used in industrial control mainboards, network equipment, digital signage, automotive entertainment and embedded mainboards.',
    standards: [
      'JEDEC JESD79-3',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '4 Gb density organised as 256M x 16',
      '1866 Mbps DDR3-1866 at CL13',
      '1.283 V to 1.45 V supply with 1.35 V typical',
      '96-pin VFBGA package, 13 mm x 8 mm',
      '800 um terminal pitch',
      'Operating temperature 0 \u00b0C to +95 \u00b0C',
      'RoHS compliant',
      'JEDEC JESD79-3 compliant',
    ],
    applications: [
      'Industrial control mainboards',
      'Network equipment',
      'Digital signage',
      'Automotive entertainment',
      'Embedded mainboards',
    ],
    faq: [
      {
        q: 'What is the NT5CC256M16EP-EK used for?',
        a: 'It provides main memory in industrial control mainboards, network equipment, digital signage players, automotive entertainment systems and embedded mainboards. The 4 Gb density, 1866 Mbps data rate and 96-pin VFBGA footprint make it a direct fit for boards laid out for this memory class.',
      },
      {
        q: 'What do buyers check before ordering an NT5CC256M16EP-EK?',
        a: 'Buyers look at cross-compatibility with the Samsung K4B4G1646E family when they want a second source, and they confirm that their controller accepts the 1.35 V supply range of the part. They also check end-of-life status and last-time-buy dates, whether the die and packaging come from the original manufacturer, batch consistency between shipments, price and lead time.',
      },
      {
        q: 'How does YIXINOU check an NT5CC256M16EP-EK before it ships?',
        a: 'For the 96-pin VFBGA package we check the marking, the date code, the ball pitch and the packing label against the lot records before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'NT5CC64M16GP-DI': {
    mpn: 'NT5CC64M16GP-DI',
    brand: 'Nanya',
    title: 'DDR3L SDRAM 1 Gb x16, 800 MHz, VFBGA-96',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / DDR',
    categoryHref: '/all-products',
    summary: 'The NT5CC64M16GP-DI is a Nanya 1 Gb DDR3L SDRAM organised as 64M x 16. It runs at 800 MHz, equivalent to 1600 Mbps DDR3-1600 CL11, and accepts 1.283 V to 1.45 V with 1.35 V typical. The 96-pin VFBGA package is rated 0 \u00b0C to +85 \u00b0C and the part is in production. It follows JEDEC JESD79-3 and is used in entry-level industrial control boards, routers and switches, set-top boxes, printing equipment and appliance control boards.',
    img: '/assets/images/nt5cc64m16gp-di-vfbga-96.jpg',
    alt: 'A 96-pin VFBGA package, the package used for the NT5CC64M16GP-DI',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Memory density', '1 Gb (64M x 16)'],
      ['Memory type', 'DDR3L SDRAM'],
      ['Frequency', '800 MHz'],
      ['Data rate', '1600 Mbps (DDR3-1600, CL11)'],
      ['Supply voltage', '1.283 V to 1.45 V (1.35 V typical)'],
      ['Package', 'VFBGA, 96 pins'],
      ['Mount', 'Surface Mount'],
      ['Operating temperature', '0 \u00b0C to +85 \u00b0C'],
      ['Lifecycle status', 'Production'],
      ['JEDEC standard', 'JESD79-3'],
    ],
    about: 'The NT5CC64M16GP-DI is a Nanya 1 Gb DDR3L SDRAM organised as 64M x 16. It runs at 800 MHz, equivalent to 1600 Mbps with CL11 latency, and accepts a supply from 1.283 V to 1.45 V with 1.35 V typical, which keeps power low in always-on equipment. The device comes in a 96-pin VFBGA package rated 0 \u00b0C to +85 \u00b0C and follows JEDEC JESD79-3. It is used in entry-level industrial control boards, routers and switches, set-top boxes, printing equipment and appliance control boards.',
    standards: ['JEDEC JESD79-3', 'ESD-sensitive device \u2014 handle under ESD-protected conditions'],
    features: [
      '1 Gb density organised as 64M x 16',
      '800 MHz clock, 1600 Mbps DDR3-1600 at CL11',
      '1.283 V to 1.45 V supply with 1.35 V typical',
      '96-pin VFBGA package',
      'Operating temperature 0 \u00b0C to +85 \u00b0C',
      'Lifecycle status: production',
      'JEDEC JESD79-3 compliant',
      'Suited to entry-level and repair requirements',
    ],
    applications: [
      'Entry-level industrial control boards',
      'Routers and switches',
      'Set-top boxes',
      'Printing equipment',
      'Appliance control boards',
    ],
    faq: [
      {
        q: 'What is the NT5CC64M16GP-DI used for?',
        a: 'It provides memory in entry-level industrial control boards, routers and switches, set-top boxes, printing equipment and appliance control boards. Most demand for the 1 Gb density today comes from repairing and maintaining older platforms that were designed around this memory class, so the part is usually bought as service stock.',
      },
      {
        q: 'What do buyers check before ordering an NT5CC64M16GP-DI?',
        a: 'Buyers know that 1 Gb small-density parts are mostly older platforms and discontinued material, so availability is checked first. They also compare price and minimum packaging quantity, ask whether the die and packing are original or white-label, decide whether an industrial temperature grade is really needed, request alternative part suggestions, and inspect appearance and batch year before accepting stock.',
      },
      {
        q: 'How does YIXINOU check an NT5CC64M16GP-DI before it ships?',
        a: 'For the 96-pin VFBGA package we check the marking, date code and ball finish, confirm the year of manufacture with the customer when the stock is older material, and record the packing condition. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'NT6CL256M32AM-H1': {
    mpn: 'NT6CL256M32AM-H1',
    brand: 'Nanya',
    title: 'LPDDR3 SDRAM 8 Gb x32, 933 MHz, BGA-178',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Memory Components / RAM / LPDDR',
    categoryHref: '/all-products',
    summary: 'The NT6CL256M32AM-H1 is a Nanya 8 Gb LPDDR3 SDRAM organised as 256M x 32. The maximum frequency is 933 MHz, equivalent to 1866 Mbps, and the device runs from 1.14 V to 1.3 V with 1.2 V typical plus a 1.8 V secondary supply. It is supplied in a 178-pin BGA package with an 800 um terminal pitch and is rated -30 \u00b0C to +105 \u00b0C. The part follows JEDEC JESD209-3, is RoHS compliant and is in production.',
    img: '/assets/images/nt6cl256m32am-h1-bga-178.jpg',
    alt: 'A 178-pin BGA package, the package used for the NT6CL256M32AM-H1',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Memory density', '8 Gb (256M x 32)'],
      ['Memory type', 'LPDDR3 SDRAM'],
      ['Max frequency', '933 MHz'],
      ['Data rate', '1866 Mbps'],
      ['Supply voltage', '1.14 V to 1.3 V (1.2 V typical)'],
      ['Secondary supply', '1.8 V'],
      ['Package', 'BGA, 178 pins'],
      ['Mount', 'Surface Mount'],
      ['Operating temperature', '-30 \u00b0C to +105 \u00b0C'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The NT6CL256M32AM-H1 is a Nanya 8 Gb LPDDR3 SDRAM organised as 256M x 32. The maximum frequency is 933 MHz, equivalent to 1866 Mbps, and the device runs from 1.14 V to 1.3 V with 1.2 V typical together with a 1.8 V secondary supply. It is supplied in a 178-pin BGA package with an 800 um terminal pitch and is rated -30 \u00b0C to +105 \u00b0C, covering hot enclosures. The part follows JEDEC JESD209-3 and is in production. It is used in tablet computers, TV boxes, automotive centre consoles, industrial tablets, mobile POS terminals and AI cameras.',
    standards: [
      'JEDEC JESD209-3',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '8 Gb density organised as 256M x 32',
      'LPDDR3 device with a 933 MHz maximum frequency',
      '1.14 V to 1.3 V supply, 1.2 V typical, plus a 1.8 V rail',
      '178-pin BGA package with 800 um pitch',
      'Wide temperature range of -30 \u00b0C to +105 \u00b0C',
      'JEDEC JESD209-3 compliant and RoHS compliant',
      'Lifecycle status: production',
      'Suited to mobile and embedded platforms',
    ],
    applications: [
      'Tablet computers',
      'TV boxes',
      'Automotive centre consoles',
      'Industrial tablets',
      'Mobile POS terminals',
      'AI cameras',
    ],
    faq: [
      {
        q: 'What is the NT6CL256M32AM-H1 used for?',
        a: 'It provides working memory in tablet computers, TV boxes, automotive centre consoles, industrial tablets, mobile POS terminals and AI cameras. The single 8 Gb x32 die and the -30 \u00b0C to +105 \u00b0C range suit compact designs that need memory capacity in one package without a wide bus fan-out.',
      },
      {
        q: 'What do buyers check before ordering an NT6CL256M32AM-H1?',
        a: 'Buyers first confirm that the host SoC DDR compatibility list includes this type, because LPDDR3 support is fixed at the platform level. They also weigh the price differences and supply stability between Nanya and other memory suppliers, ask for a real test report behind the 105 \u00b0C high-temperature grade, review the strict routing requirements of a single 8 Gb x32 device, and check whether the parts are original product before discussing a long-term supply commitment.',
      },
      {
        q: 'How does YIXINOU check an NT6CL256M32AM-H1 before it ships?',
        a: 'For the 178-pin BGA package we verify the marking, date code and ball condition against the lot documents, and we check the moisture barrier bag and reel or tray count. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'NT6TL256T32AQ-GO': {
    mpn: 'NT6TL256T32AQ-GO',
    brand: 'Nanya',
    title: 'LPDDR2 SDRAM 8 Gb x32, FBGA-178',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The NT6TL256T32AQ-GO is a Nanya 8 Gb LPDDR2 SDRAM organised as 256M x 32. It runs at 1866 Mbps and uses a VDD1 rail of 1.8 V together with VDD2/VDDQ at 1.2 V. The device comes in a 178-ball FBGA package and is rated -25 \u00b0C to +85 \u00b0C. It follows JEDEC JESD209-3 and is used in early-generation tablets, TV boxes, car navigation units, industrial tablets and low-end smart terminals as well as repair replacements.',
    img: '/assets/images/nt6tl256t32aq-go-package.jpg',
    alt: 'A 178-ball FBGA package, the package used for the NT6TL256T32AQ-GO',
    imageNote: 'Illustrative package image. Ask us for a photograph of the actual lot.',
    specs: [
      ['Memory density', '8 Gb (256M x 32)'],
      ['Memory type', 'LPDDR2 SDRAM'],
      ['Data rate', '1866 Mbps'],
      ['VDD1', '1.8 V'],
      ['VDD2 / VDDQ', '1.2 V'],
      ['Package', 'FBGA-178'],
      ['Data bus width', 'x32'],
      ['Operating temperature', '-25 \u00b0C to +85 \u00b0C'],
      ['JEDEC standard', 'JESD209-3'],
      ['Primary use', 'Tablet, TV box, car navigation and industrial panel'],
    ],
    about: 'The NT6TL256T32AQ-GO is a Nanya 8 Gb LPDDR2 SDRAM organised as 256M x 32. It runs at 1866 Mbps and is powered from a VDD1 rail of 1.8 V with VDD2/VDDQ at 1.2 V, and it is supplied in a 178-ball FBGA package rated -25 \u00b0C to +85 \u00b0C. The device follows JEDEC JESD209-3. Because LPDDR2 is an earlier memory generation, the part is usually chosen for early-generation tablets, TV boxes, car navigation units, industrial tablets and low-end smart terminals, and for repairing or replacing boards that are already in the field.',
    standards: ['JEDEC JESD209-3', 'ESD-sensitive device \u2014 handle under ESD-protected conditions'],
    features: [
      '8 Gb density organised as 256M x 32',
      'LPDDR2 SDRAM running at 1866 Mbps',
      'VDD1 of 1.8 V with VDD2/VDDQ at 1.2 V',
      '178-ball FBGA package',
      'Operating temperature -25 \u00b0C to +85 \u00b0C',
      'JEDEC JESD209-3 compliant',
      'Suited to legacy and repair requirements',
      'Single-package 32-bit memory bus',
    ],
    applications: [
      'Early-generation tablets',
      'TV boxes',
      'Car navigation units',
      'Industrial tablets',
      'Low-end smart terminals and repair replacement',
    ],
    faq: [
      {
        q: 'What is the NT6TL256T32AQ-GO used for?',
        a: 'It is used in early-generation tablets, TV boxes, car navigation units, industrial tablets and low-end smart terminals, and it also serves as a repair replacement for boards already deployed in the field. Because LPDDR2 is an earlier generation, the part is normally chosen when the existing platform was designed around this memory type.',
      },
      {
        q: 'What do buyers check before ordering an NT6TL256T32AQ-GO?',
        a: 'Buyers confirm that their SoC supports LPDDR2, since controller support for this generation is shrinking, and they check the inventory year and the refurbishing risk of discontinued stock. They also ask how original parts can be distinguished from copies, look at LPDDR3 and LPDDR4 as replacement options, and review price, minimum order quantity and batch consistency between shipments.',
      },
      {
        q: 'How does YIXINOU check an NT6TL256T32AQ-GO before it ships?',
        a: 'For the 178-ball FBGA package we check the marking, the date code and the ball condition against the supplier records and confirm that the packing is sealed and correctly labelled. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'NTTFSSCH4D0N08XLTWG': {
    mpn: 'NTTFSSCH4D0N08XLTWG',
    brand: 'onsemi',
    title: 'PowerTrench T10 80 V N-channel MOSFET, Source Down, WDFN9',
    category: 'Others / Discrete Semiconductors / Transistors / MOSFETs',
    categoryHref: '/all-products',
    summary: 'The NTTFSSCH4D0N08XLTWG is an onsemi single N-channel power MOSFET built on the PowerTrench T10 process in a Source Down, DualCool 33 WDFN9 package measuring 3.3 x 3.3 mm. It has an 80 V drain-to-source rating, 3.6 mOhm on-resistance and a continuous drain current of 107 A at TC = 25 \u00b0C, with a 419 A pulsed rating and 102 W power dissipation. The gate-to-source voltage range is \u00b120 V and the junction and storage temperature range is -55 \u00b0C to +175 \u00b0C. The TWG suffix indicates tape and reel packing.',
    img: '/assets/images/nttfssch4d0n08xltwg-package.jpg',
    alt: 'A 9-terminal WDFN package, the package used for the NTTFSSCH4D0N08XLTWG',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Drain to source voltage (VDSS)', '80 V'],
      ['Continuous drain current (ID)', '107 A at TC = 25 \u00b0C'],
      ['Pulsed drain current (IDM)', '419 A'],
      ['Drain to source on resistance (RDS(on))', '3.6 mOhm'],
      ['Power dissipation (PD)', '102 W'],
      ['Gate to source voltage (VGS)', '\u00b120 V'],
      ['Junction and storage temperature', '-55 \u00b0C to +175 \u00b0C'],
      ['Package', 'DualCool 33 / WDFN9 (3.3 x 3.3 mm)'],
      ['Number of terminals', '9'],
      ['Packaging', 'TWG, tape and reel'],
    ],
    about: 'The NTTFSSCH4D0N08XLTWG is an onsemi single N-channel power MOSFET from the PowerTrench T10 process, supplied in the Source Down DualCool 33 WDFN9 package measuring 3.3 x 3.3 mm. It is rated 80 V drain to source with 3.6 mOhm on-resistance, 107 A continuous drain current at TC = 25 \u00b0C, 419 A pulsed current and 102 W power dissipation. The gate-to-source range is \u00b120 V and junction and storage temperature spans -55 \u00b0C to +175 \u00b0C. It serves 48 V intermediate bus power racks in servers and data centres, synchronous rectification, BLDC motor drives and high-current load switches.',
    standards: [
      'onsemi NTTFSSCH4D0N08XL/D datasheet Rev. 1 (2025-04)',
      'Pb-free, halogen free / BFR free, RoHS compliant',
      'Meets JEDEC package standards',
      'MSL1 moisture sensitivity level',
      'TWG suffix is tape and reel packaging',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '80 V drain-to-source voltage rating',
      'RDS(on) of 3.6 mOhm confirmed by the datasheet',
      '107 A continuous drain current at TC = 25 \u00b0C',
      '419 A pulsed drain current and 102 W power dissipation',
      '\u00b120 V gate-to-source voltage range',
      'Source Down DualCool 33 WDFN9 package, 3.3 x 3.3 mm',
      'PowerTrench T10 process technology',
      'MSL1 moisture sensitivity level and tape and reel packing',
    ],
    applications: [
      '48 V intermediate bus power racks in servers and data centres',
      'Synchronous rectification',
      'BLDC motor drives',
      'High-current load switches',
    ],
    faq: [
      {
        q: 'What is the NTTFSSCH4D0N08XLTWG used for?',
        a: 'It is used where a low on-resistance 80 V device has to carry high current: the 48 V intermediate bus and power racks in servers and data centres, synchronous rectification, BLDC motor drives and high-current load switches. The Source Down DualCool 33 package is chosen so that heat leaves through the PCB thermal pad.',
      },
      {
        q: 'What do buyers check before ordering an NTTFSSCH4D0N08XLTWG?',
        a: 'Buyers note that the trailing TWG is only a packaging suffix and that the valid device number is NTTFSSCH4D0N08XL. They confirm the official 3.6 mOhm RDS(on) and 107 A ID ratings against the datasheet rather than estimates, review the PCB thermal pad design that the Source Down structure requires, check gate drive voltage and switching losses, plan current sharing when devices are paralleled, and agree price, MOQ and lead time.',
      },
      {
        q: 'How does YIXINOU check an NTTFSSCH4D0N08XLTWG before it ships?',
        a: 'For the 9-terminal WDFN9 package we check the marking, terminal condition and reel count against the packing list, and we confirm that the MSL1 moisture barrier packing is intact. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'PIC16F628A-I-P': {
    mpn: 'PIC16F628A-I/P',
    brand: 'Microchip Technology',
    title: 'PIC16F628A 8-bit Flash microcontroller in PDIP-18',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The PIC16F628A-I/P is a Microchip 8-bit Flash microcontroller built on the PIC16 core and running at up to 20 MHz. It has 2 KB of Flash program memory, 224 B of RAM and 128 B of EEPROM, and it operates from 3.0 V to 5.5 V over the industrial range of -40 \u00b0C to +85 \u00b0C. On-chip peripherals include a USART, CCP, two comparators and a programmable internal 4 MHz / 8 MHz oscillator. The part is supplied in an 18-pin plastic DIP package.',
    img: '/assets/images/pic16f628a-i-p-package.jpg',
    alt: 'An 18-pin PDIP package, the package used for the PIC16F628A-I/P',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Core', 'PIC16 at up to 20 MHz'],
      ['Flash program memory', '2 KB (2 K x 14-bit words)'],
      ['RAM', '224 B'],
      ['EEPROM', '128 B'],
      ['Supply voltage', '3.0 V to 5.5 V'],
      ['Operating temperature', '-40 \u00b0C to +85 \u00b0C (industrial, I)'],
      ['Package', 'PDIP-18'],
      ['Oscillator', 'Internal programmable 4 MHz / 8 MHz'],
      ['Peripherals', 'USART, CCP, two comparators'],
      ['Memory endurance', '100,000 Flash and 1,000,000 EEPROM cycles, retention over 40 years'],
    ],
    about: 'The PIC16F628A-I/P is a Microchip 8-bit Flash microcontroller on the PIC16 core running at up to 20 MHz. It provides 2 KB of Flash program memory, 224 B of RAM and 128 B of EEPROM, and works from 3.0 V to 5.5 V across the industrial temperature range of -40 \u00b0C to +85 \u00b0C. Peripherals include a USART, CCP, two comparators and a programmable internal 4 MHz / 8 MHz oscillator. It is supplied in an 18-pin plastic DIP package and is used in small home appliances, LED control, sensor interfaces, power management and other low-cost control designs.',
    standards: [
      'Microchip PIC16F627A/628A/648A family datasheet DS40044G',
      'RoHS compliant',
      'Lead-free (Pb-free) package, compliant with RoHS and REACH',
      'Meets JEDEC package and ESD test standards',
      'ESD protection meets human body model (HBM) and machine model specifications',
      'Moisture sensitivity level and reflow profile follow J-STD-020',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'PIC16 core running at up to 20 MHz',
      '2 KB Flash program memory, 224 B RAM and 128 B EEPROM',
      '3.0 V to 5.5 V supply voltage',
      'Industrial temperature range -40 \u00b0C to +85 \u00b0C',
      'USART, CCP and two comparators on chip',
      'Programmable internal 4 MHz / 8 MHz oscillator',
      '18-pin PDIP package, marked I for industrial grade',
      'Flash endurance of 100,000 cycles and EEPROM endurance of 1,000,000 cycles',
    ],
    applications: [
      'Small home appliances',
      'LED control',
      'Sensor interfaces',
      'Power management',
      'Low-cost control applications',
    ],
    faq: [
      {
        q: 'What is the PIC16F628A-I/P used for?',
        a: 'It handles low-cost control tasks in small home appliances, LED control, sensor interfaces and power management circuits. Its on-chip USART, CCP and comparators let a design connect a sensor or drive output stages with very few external parts, and the PDIP-18 package suits boards that are hand-assembled or repaired in the field.',
      },
      {
        q: 'What do buyers check before ordering a PIC16F628A-I/P?',
        a: 'The memory resources are small, so buyers first confirm that the program fits within the available Flash and EEPROM. They then check whether the 18-pin I/O count is enough for the design, insist on genuine original product, and compare the part with the earlier PIC16F628 without the A suffix. End-of-life risk, price and minimum order quantity are reviewed before the order is placed.',
      },
      {
        q: 'How does YIXINOU check a PIC16F628A-I/P before it ships?',
        a: 'For the 18-pin PDIP package we check the printed marking, pin condition and date code against the supplier documents, and we confirm that the tube or tray packing matches the order. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'PIC16F877A-I-P': {
    mpn: 'PIC16F877A-I/P',
    brand: 'Microchip Technology',
    title: 'Microchip PIC16F877A 8-bit flash microcontroller in PDIP-40',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The PIC16F877A-I/P is a Microchip PIC16 mid-range 8-bit flash microcontroller running at up to 20 MHz in a 40-pin plastic DIP package. It provides 8 KB of flash program memory, 368 bytes of RAM and 256 bytes of data EEPROM, and it operates from a 2.0 V to 5.5 V supply over the -40 to 85 \u00b0C industrial range. On-chip peripherals include a 10-bit 8-channel ADC, two CCP modules, MSSP, USART and a parallel slave port. Flash endurance is rated at 100,000 erase/write cycles, and the device is used in industrial control, instrumentation and legacy repair work.',
    img: '/assets/images/pic16f877a-i-p-package.jpg',
    alt: 'A 40-pin plastic DIP (PDIP-40) package, the package used for the PIC16F877A-I/P',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Core', 'PIC16 mid-range, 20 MHz'],
      ['Program memory', '8 KB Flash (4 K x 14-bit words)'],
      ['RAM', '368 B'],
      ['Data EEPROM', '256 B'],
      ['Package', 'PDIP-40 (plastic DIP)'],
      ['Supply voltage', '2.0 V to 5.5 V'],
      ['Operating temperature', '-40 to 85 \u00b0C (I industrial grade)'],
      ['ADC', '10-bit, 8 channels'],
      ['Serial interfaces', 'MSSP, USART, PSP'],
      ['Capture/Compare/PWM', '2 x CCP, 10-bit PWM resolution'],
    ],
    about: 'The PIC16F877A-I/P is a PIC16 mid-range 8-bit flash microcontroller from Microchip Technology supplied in a 40-pin plastic dual in-line package. It provides 8 KB of flash program memory, 368 bytes of RAM, 256 bytes of data EEPROM and a 10-bit 8-channel ADC, together with two CCP modules, MSSP, USART and a parallel slave port. It runs from a 2.0 V to 5.5 V supply over the -40 to 85 \u00b0C industrial range. Typical uses are industrial control, teaching laboratories, instrumentation, appliance control, and repair or replacement of older designs.',
    standards: [
      'Microchip datasheet DS39582C (PIC16F87XA family)',
      'RoHS compliant',
      'Lead-free (Pb-free) package, RoHS and REACH compliant',
      'JEDEC package and ESD test standards; ESD protection to human body model and machine model requirements',
      'Moisture sensitivity level and reflow profile per J-STD-020',
      'ICSP programming interface specification',
      'Data EEPROM endurance 1,000,000 cycles, data retention over 40 years',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'PIC16 mid-range core running at up to 20 MHz',
      '8 KB flash program memory with 100,000-cycle erase/write endurance',
      '368 bytes of RAM and 256 bytes of data EEPROM',
      '10-bit 8-channel analog-to-digital converter',
      'Two CCP modules with 10-bit PWM resolution',
      'MSSP, USART and parallel slave port (PSP)',
      '2.0 V to 5.5 V operating supply',
      'Industrial -40 to 85 \u00b0C grade in a PDIP-40 through-hole package',
    ],
    applications: [
      'Industrial control systems',
      'Teaching and laboratory experiment boards',
      'Test and measurement instrumentation',
      'Home appliance control boards',
      'Repair and replacement of legacy designs',
    ],
    faq: [
      {
        q: 'What is the PIC16F877A-I/P used for?',
        a: 'It is used in industrial control, teaching and laboratory experiment boards, instrumentation and home appliance control, and it is widely chosen for repair and replacement of older designs built around the PIC16F87XA family. Its 10-bit ADC, two CCP modules, MSSP, USART and parallel slave port cover most small embedded control tasks.',
      },
      {
        q: 'What do buyers check before ordering a PIC16F877A-I/P?',
        a: 'Buyers normally confirm that the -I/P industrial through-hole PDIP-40 variant is the one required rather than a commercial or surface-mount version, and they verify that the device is original. They also check whether 20 MHz and 8 KB of flash are enough for the application. Because this classic part has reached end of life, last order timing, price and stock year are reviewed as well, and the PIC16F887 or PIC18F families are assessed as alternatives.',
      },
      {
        q: 'How does YIXINOU check a PIC16F877A-I/P in a 40-pin PDIP package before it ships?',
        a: 'Each lot is inspected for original markings, labels and packaging, and the 40-pin PDIP package is checked for straight leads and overall condition. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'PIC16F887-I-P': {
    mpn: 'PIC16F887-I/P',
    brand: 'Microchip Technology',
    title: 'Microchip PIC16F887 8-bit flash microcontroller in PDIP-40',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The PIC16F887-I/P is a Microchip PIC16 mid-range 8-bit flash microcontroller in a 40-pin plastic DIP package. It runs at up to 20 MHz with 8 KB of flash program memory, 368 bytes of RAM and 256 bytes of data EEPROM. The supply range is 2.0 V to 5.5 V and the industrial temperature grade covers -40 to 85 \u00b0C. Its 10-bit ADC offers up to 14 channels, and on-chip peripherals include MSSP for SPI and I2C, EUSART, ECCP, two comparators and a CVREF module.',
    img: '/assets/images/pic16f887-i-p-package.jpg',
    alt: 'A 40-pin plastic DIP (PDIP-40) package, the package used for the PIC16F887-I/P',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Core', 'PIC16 mid-range, 20 MHz'],
      ['Program memory', '8 KB Flash'],
      ['RAM', '368 B'],
      ['Data EEPROM', '256 B'],
      ['Package', 'PDIP-40 (plastic DIP)'],
      ['Supply voltage', '2.0 V to 5.5 V'],
      ['Operating temperature', '-40 to 85 \u00b0C (I industrial grade)'],
      ['ADC', '10-bit, up to 14 channels'],
      ['Serial interfaces', 'MSSP (SPI/I2C), EUSART'],
      ['Analog and PWM peripherals', 'ECCP, 2 comparators, CVREF module'],
    ],
    about: 'The PIC16F887-I/P is a Microchip PIC16 mid-range 8-bit flash microcontroller in a 40-pin plastic DIP package with 8 KB of flash program memory, 368 bytes of RAM and 256 bytes of data EEPROM. It runs at up to 20 MHz from a 2.0 V to 5.5 V supply and is rated for the -40 to 85 \u00b0C industrial range. Its 10-bit ADC has up to 14 channels, and the periphery includes MSSP with SPI and I2C, EUSART, ECCP, two comparators and a CVREF module. It is widely used as the upgrade path for PIC16F877A projects in industrial control, appliances, instrumentation and teaching.',
    standards: [
      'Microchip datasheet DS40001291H (PIC16F882/883/884/886/887 family)',
      'RoHS compliant',
      'Lead-free (Pb-free) package, RoHS and REACH compliant',
      'JEDEC package and ESD test standards; ESD protection to human body model and machine model requirements',
      'Moisture sensitivity level and reflow profile per J-STD-020',
      'The family includes AEC-Q100 qualified versions, ordered by the corresponding suffix',
      'Flash endurance 100,000 cycles, data EEPROM endurance 1,000,000 cycles, data retention over 40 years',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'PIC16 mid-range core running at up to 20 MHz',
      '8 KB flash program memory with 100,000-cycle erase/write endurance',
      '368 bytes of RAM and 256 bytes of data EEPROM with 1,000,000-cycle endurance',
      '10-bit ADC with up to 14 channels',
      'MSSP (SPI/I2C), EUSART and ECCP modules',
      'Two comparators and a CVREF module',
      'Internal oscillator option that can remove the need for an external crystal',
      'Industrial -40 to 85 \u00b0C grade in a PDIP-40 package',
    ],
    applications: [
      'Industrial control systems',
      'Home appliance control boards',
      'Test and measurement instrumentation',
      'Teaching and laboratory boards',
      'Upgrade projects that replace the PIC16F877A',
    ],
    faq: [
      {
        q: 'What is the PIC16F887-I/P used for?',
        a: 'It is used in industrial control, home appliance control boards, instrumentation and teaching, and it is a common upgrade choice for projects moving from the PIC16F877A. The 10-bit 14-channel ADC, MSSP, EUSART, ECCP, dual comparators and CVREF module cover mixed analog and digital control tasks without extra support chips.',
      },
      {
        q: 'What do buyers check before ordering a PIC16F887-I/P?',
        a: 'Buyers confirm the industrial temperature grade and the through-hole PDIP-40 package, and they check that the part is original. They also plan for firmware changes, because the PIC16F887 is the recommended replacement for the PIC16F877A but the pinout and registers differ. The built-in oscillator that removes the crystal is another point of interest, along with price, supply and the matching surface-mount part number.',
      },
      {
        q: 'How does YIXINOU check a PIC16F887-I/P in a 40-pin PDIP package before it ships?',
        a: 'Incoming lots are checked for original markings, tray or tube packaging and consistent date codes, and the PDIP-40 leads are inspected for alignment and finish. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'PIC18F4520-I-PT': {
    mpn: 'PIC18F4520-I/PT',
    brand: 'Microchip Technology',
    title: 'Microchip PIC18F4520 8-bit MCU with 32 KB flash in TQFP-44',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The PIC18F4520-I/PT is a Microchip PIC18 8-bit microcontroller running at up to 40 MHz in a 44-pin TQFP package measuring 10 x 10 mm. It offers 32 KB of flash program memory, 1536 bytes of RAM and a 10-bit ADC, and it operates at 5 V over the -40 to +85 \u00b0C industrial temperature range. The -I/PT suffix identifies the industrial-grade surface-mount TQFP variant. Typical uses include industrial control, instrumentation, appliance electronics, automotive electronics, communication equipment and motor control.',
    img: '/assets/images/pic18f4520-i-pt-package.jpg',
    alt: 'A 44-pin TQFP package measuring 10 x 10 mm, the package used for the PIC18F4520-I/PT',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Core', 'PIC 8-bit, 40 MHz'],
      ['Program memory', '32 KB Flash'],
      ['RAM', '1536 B'],
      ['Package', '44-pin TQFP (10 x 10 mm)'],
      ['Mounting', 'Surface mount'],
      ['Supply voltage', '5 V'],
      ['Operating temperature', '-40 to +85 \u00b0C'],
      ['Temperature grade', 'Industrial (I)'],
      ['ADC', '10-bit'],
      ['Device class', '8-bit microcontroller (MCU)'],
    ],
    about: 'The PIC18F4520-I/PT is a Microchip PIC18 8-bit microcontroller in a 44-pin TQFP package measuring 10 x 10 mm. It runs at up to 40 MHz with 32 KB of flash program memory, 1536 bytes of RAM and a 10-bit ADC, and it operates from a 5 V supply over the -40 to +85 \u00b0C industrial range. The -I/PT suffix marks the industrial-grade surface-mount TQFP variant, which must not be confused with other temperature or package options. It is used in industrial control, instrumentation, appliances, automotive electronics, communication equipment and motor control.',
    standards: ['RoHS compliant', 'ESD-sensitive device \u2014 handle under ESD-protected conditions'],
    features: [
      'PIC18 8-bit core running at up to 40 MHz',
      '32 KB flash program memory',
      '1536 bytes of RAM',
      '10-bit analog-to-digital converter',
      '44-pin TQFP package measuring 10 x 10 mm',
      '5 V operation for direct matching with 5 V peripherals',
      'Industrial temperature grade, -40 to +85 \u00b0C',
    ],
    applications: [
      'Industrial control',
      'Test and measurement instrumentation',
      'Home appliance electronics',
      'Automotive electronics',
      'Communication equipment',
      'Motor control',
    ],
    faq: [
      {
        q: 'What is the PIC18F4520-I/PT used for?',
        a: 'It is used in industrial control, instrumentation, home appliance electronics, automotive electronics, communication equipment and motor control. Its 40 MHz PIC18 core, 32 KB flash, 1536 bytes of RAM and 10-bit ADC suit embedded boards that need a 5 V part in a small surface-mount package.',
      },
      {
        q: 'What do buyers check before ordering a PIC18F4520-I/PT?',
        a: 'Buyers check that the -I/PT industrial TQFP variant is the correct one rather than another temperature or package option, and they confirm that the design can be supplied at 5 V and matched with the surrounding components. They also compare the PIC18 and PIC16 families, because code is not directly compatible between them and a port requires rewriting, and they review programmer compatibility, authenticity, price, supply and the differences against alternatives such as the PIC18F45K20 and PIC18F45K22.',
      },
      {
        q: 'How does YIXINOU check a PIC18F4520-I/PT in a 44-pin TQFP package before it ships?',
        a: 'Lots are checked for original markings and packaging, and the 44-pin TQFP body and lead finish are inspected for oxidation, bent leads and signs of reworking. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'PIC18F4620-I-PT': {
    mpn: 'PIC18F4620-I/PT',
    brand: 'Microchip Technology',
    title: 'Microchip PIC18F4620 8-bit flash microcontroller in TQFP-44',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The PIC18F4620-I/PT is a Microchip PIC18 8-bit flash microcontroller in a 44-pin TQFP (PT) package. It runs at up to 40 MHz with 64 KB of flash program memory, 3968 bytes of RAM, 1024 bytes of data EEPROM and a 10-bit 13-channel ADC. The supply range is 2.0 V to 5.5 V and the industrial temperature grade covers -40 to 85 \u00b0C. On-chip peripherals include MSSP, EUSART, CCP and a comparator, and the device is in production at Microchip.',
    img: '/assets/images/pic18f4620-i-pt-package.jpg',
    alt: 'A 44-pin TQFP (PT) package, the package used for the PIC18F4620-I/PT',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Core', 'PIC18, 40 MHz'],
      ['Program memory', '64 KB Flash'],
      ['RAM', '3968 B'],
      ['Data EEPROM', '1024 B'],
      ['Package', 'TQFP-44 (PT)'],
      ['Supply voltage', '2.0 V to 5.5 V (5.5 V maximum)'],
      ['Operating temperature', '-40 to 85 \u00b0C (I industrial grade)'],
      ['ADC', '10-bit, 13 channels'],
      ['Serial interfaces', 'MSSP, EUSART'],
      ['Analog and PWM peripherals', 'CCP, comparator'],
    ],
    about: 'The PIC18F4620-I/PT is a Microchip PIC18 8-bit flash microcontroller supplied in a 44-pin TQFP (PT) package. It runs at up to 40 MHz with 64 KB of flash program memory, 3968 bytes of RAM, 1024 bytes of data EEPROM and a 10-bit ADC with 13 channels. The supply range is 2.0 V to 5.5 V and the industrial temperature grade covers -40 to 85 \u00b0C. Peripherals include MSSP, EUSART and CCP. As the large-memory version of the PIC18F4520, it suits industrial control, instrumentation, appliances, automotive electronics, and data acquisition or communication equipment.',
    standards: [
      'Microchip datasheet DS39626E (PIC18F2525/2620/4525/4620 family)',
      'RoHS compliant',
      'Manufacturer status: In Production',
      'Lead-free (Pb-free) package, RoHS and REACH compliant',
      'JEDEC package and ESD test standards; ESD protection to human body model and machine model requirements',
      'Moisture sensitivity level and reflow profile per J-STD-020',
      'Flash endurance 100,000 cycles, data EEPROM endurance 1,000,000 cycles, data retention typically 100 years',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'PIC18 core running at up to 40 MHz',
      '64 KB flash program memory with 100,000-cycle erase/write endurance',
      '3968 bytes of RAM and 1024 bytes of data EEPROM',
      '10-bit ADC with 13 channels',
      'MSSP, EUSART and CCP modules plus a comparator',
      'Enhanced flash process with 100-year typical data retention',
      '2.0 V to 5.5 V supply range',
      'Industrial -40 to 85 \u00b0C grade in a TQFP-44 package',
    ],
    applications: [
      'Industrial control',
      'Test and measurement instrumentation',
      'Home appliance electronics',
      'Automotive electronics',
      'Data acquisition and communication equipment',
    ],
    faq: [
      {
        q: 'What is the PIC18F4620-I/PT used for?',
        a: 'It is used in industrial control, instrumentation, home appliance and automotive electronics, and in data acquisition or communication equipment. It is the large-memory version of the PIC18F4520 with 64 KB of flash and 3968 bytes of RAM, so it suits designs that need more program space, more buffering and the 10-bit 13-channel ADC in a compact TQFP-44 footprint.',
      },
      {
        q: 'What do buyers check before ordering a PIC18F4620-I/PT?',
        a: 'Buyers assess whether the larger memory of the PIC18F4620 is actually needed, since the device is the high-capacity counterpart of the PIC18F4520 with 64 KB of flash and 3968 bytes of RAM. They also confirm the industrial temperature grade and the TQFP-44 package, check 5 V level matching with surrounding parts, verify that the part is original, review price and supply, and evaluate newer families such as the PIC18F46K22 as a replacement option.',
      },
      {
        q: 'How does YIXINOU check a PIC18F4620-I/PT in a 44-pin TQFP package before it ships?',
        a: 'Lots are checked for original marking, labelling and packaging, and the 44-pin TQFP pins are inspected for coplanarity, solderability and signs of prior rework. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'R5F100ACASP': {
    mpn: 'R5F100ACASP',
    brand: 'Renesas',
    title: 'Renesas RL78/G13 16-bit low-power MCU in 30-pin LSSOP',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The R5F100ACASP is a Renesas RL78/G13 series 16-bit low-power microcontroller in a 30-pin LSSOP package. It runs at up to 32 MHz with 32 KB of flash program memory and 2.5 KB of RAM. The operating temperature range is -40 to +85 \u00b0C, and the device is AEC-Q100 qualified and RoHS compliant. Typical uses include home appliances such as air conditioners, washing machines and microwave ovens, industrial control, lighting, sensor nodes and battery-powered equipment.',
    img: '/assets/images/r5f100acasp-package.jpg',
    alt: 'A 30-pin LSSOP package, the package used for the R5F100ACASP',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Core', 'RL78/G13, 32 MHz'],
      ['Architecture', '16-bit'],
      ['Series', 'RL78/G13'],
      ['Program memory', '32 KB Flash'],
      ['RAM', '2.5 KB'],
      ['Package', '30-pin LSSOP'],
      ['Mounting', 'Surface mount'],
      ['Operating temperature', '-40 to +85 \u00b0C'],
      ['Power profile', 'Low-power operation'],
      ['Device class', '16-bit microcontroller (MCU)'],
    ],
    about: 'The R5F100ACASP is a Renesas RL78/G13 series 16-bit low-power microcontroller supplied in a 30-pin LSSOP package. It runs at up to 32 MHz with 32 KB of flash program memory and 2.5 KB of RAM, and it is rated for the -40 to +85 \u00b0C industrial range. The device is AEC-Q100 qualified and RoHS compliant. Its combination of a small package, low power draw and on-chip flash makes it suitable for home appliances such as air conditioners, washing machines and microwave ovens, as well as industrial control, lighting, sensor nodes and battery-powered equipment.',
    standards: [
      'AEC-Q100 qualified',
      'RoHS compliant',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'RL78/G13 16-bit core running at up to 32 MHz',
      '32 KB flash program memory and 2.5 KB of RAM',
      '30-pin LSSOP package for compact boards',
      'Low-power operation suited to battery-powered devices',
      'AEC-Q100 qualified',
      'RoHS compliant',
      'Operating temperature range -40 to +85 \u00b0C',
    ],
    applications: [
      'Home appliances such as air conditioners, washing machines and microwave ovens',
      'Industrial control',
      'Lighting control',
      'Sensor nodes',
      'Battery-powered equipment',
    ],
    faq: [
      {
        q: 'What is the R5F100ACASP used for?',
        a: 'It is used in home appliances such as air conditioners, washing machines and microwave ovens, in industrial control and lighting, in sensor nodes and in battery-powered equipment. The 16-bit RL78/G13 core at 32 MHz, 32 KB of flash and 2.5 KB of RAM fit control tasks where low power and a small 30-pin LSSOP footprint matter more than heavy computation.',
      },
      {
        q: 'What do buyers check before ordering an R5F100ACASP?',
        a: 'Buyers check whether 16-bit resources are sufficient for the algorithm the application has to run, and they confirm the low-power figures against the battery life target. The Renesas ecosystem is relatively closed, so the development tools CS+ or e2studio and the matching E1 or E2 Lite emulator must be available to the team. Buyers also verify that the parts come from a regular channel, compare replacement options, and review price and lead time.',
      },
      {
        q: 'How does YIXINOU check an R5F100ACASP in a 30-pin LSSOP package before it ships?',
        a: 'Lots are checked for original markings and packaging, and the fine-pitch 30-pin LSSOP leads are inspected for coplanarity, oxidation and prior rework. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'SN65LVDS93ADGGR': {
    mpn: 'SN65LVDS93ADGGR',
    brand: 'Texas Instruments',
    title: 'Texas Instruments SN65LVDS93A 28-bit FlatLink LVDS serializer in TSSOP-56',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Interface ICs / Serializers and Deserializers (SerDes)',
    categoryHref: '/all-products',
    summary: 'The SN65LVDS93ADGGR is a Texas Instruments FlatLink LVDS serializer, or transmitter, that converts 28 bits of parallel display data plus 4 control bits into four LVDS differential pairs. It operates from 10 MHz to 135 MHz, matching the pixel clock of the panel, and accepts 1.8 V data inputs with tolerance up to 3.3 V. The device is supplied in a 56-pin TSSOP (DGG) package, runs from a 3 V to 3.6 V supply and is rated -40 to 85 \u00b0C. It is used in industrial LCD panels, medical displays, automotive displays and industrial HMI video links.',
    img: '/assets/images/sn65lvds93adggr-tssop-56.jpg',
    alt: 'A 56-pin TSSOP (DGG) package, the package used for the SN65LVDS93ADGGR',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package', 'TSSOP (DGG)'],
      ['Number of pins', '56'],
      ['Mounting', 'Surface mount'],
      ['Supply voltage', '3 V to 3.6 V'],
      ['Operating temperature', '-40 to 85 \u00b0C'],
      ['Packing', 'Tape and reel'],
      ['RoHS', 'Compliant'],
      ['Lifecycle status', 'Production'],
      ['Function', '28-bit LVDS serializer (transmitter)'],
      ['Operating frequency', '10 MHz to 135 MHz'],
    ],
    about: 'The SN65LVDS93ADGGR is a Texas Instruments FlatLink LVDS serializer, or transmitter, that converts 28 bits of parallel display data plus 4 control bits into four LVDS differential pairs. It operates from 10 MHz to 135 MHz, matching the pixel clock of the panel, and accepts 1.8 V data inputs with tolerance up to 3.3 V. The device is supplied in a 56-pin TSSOP (DGG) package, runs from a 3 V to 3.6 V supply and is rated -40 to 85 \u00b0C. Typical uses are industrial LCD panels, medical displays, automotive displays and industrial HMI video links.',
    standards: [
      'Texas Instruments datasheet SN65LVDS93A (FlatLink LVDS SerDes transmitter)',
      'RoHS compliant',
      'REACH compliant',
      'JEDEC package and ESD standards (JESD22 series)',
      'Package thermal characteristics per JESD51',
      'PCB land pattern design per IPC-7351 and IPC-7525',
      'Green lead-free package',
      'TIA/EIA-644 LVDS electrical specification',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      '28-bit LVDS serializer (transmitter) for flat panel display links',
      'Operating frequency 10 MHz to 135 MHz, matching the pixel clock',
      'Converts 28 bits of parallel data plus 4 control bits into four LVDS differential pairs',
      '1.8 V data inputs with tolerance up to 3.3 V',
      'Supply voltage 3 V to 3.6 V',
      '56-pin TSSOP (DGG) package in tape and reel',
      'Industrial -40 to 85 \u00b0C operating range',
    ],
    applications: [
      'Industrial LCD display panels',
      'Medical displays',
      'Automotive displays',
      'Industrial HMI and video transmission',
    ],
    faq: [
      {
        q: 'What is the SN65LVDS93ADGGR used for?',
        a: 'It is used to drive LVDS links in industrial LCD panels, medical displays, automotive displays and industrial HMI video transmission. It serializes 28 bits of parallel display data plus 4 control bits into four LVDS differential pairs at a 10 MHz to 135 MHz clock, so it sits between the display controller and the panel cable.',
      },
      {
        q: 'What do buyers check before ordering an SN65LVDS93ADGGR?',
        a: 'Buyers confirm the receiver they will pair with it, such as the SN65LVDS94 or a DS90C series device, and they check the difference against the SN65LVDS93 without the A suffix, since the A version covers a different, wider frequency range. They also review the pitch and soldering profile of the 56-pin TSSOP, clock jitter and trace length matching on the board, cable and connector selection, and finally price and end-of-life status.',
      },
      {
        q: 'How does YIXINOU check an SN65LVDS93ADGGR in a 56-pin TSSOP package before it ships?',
        a: 'Each lot is checked for original markings, reel and label details, and the fine-pitch 56-pin TSSOP leads are inspected for coplanarity, oxidation and signs of reworking. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'STM32F030C8T6': {
    mpn: 'STM32F030C8T6',
    brand: 'STMicroelectronics',
    title: 'STMicroelectronics STM32F030C8 32-bit Cortex-M0 MCU in LQFP-48',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The STM32F030C8T6 is an STMicroelectronics STM32F0 Value-line 32-bit microcontroller with an Arm Cortex-M0 core running at 48 MHz in a 48-pin LQFP package. It provides 64 KB of flash program memory and 8 KB of SRAM, operates from 2.4 V to 3.6 V and is rated -40 to 85 \u00b0C. On-chip peripherals include a 12-bit ADC with up to 12 channels, seven timers and I2C, SPI, UART and USART interfaces. It targets small appliances, power tools, LED lighting, chargers, sensor nodes and low-cost control boards.',
    img: '/assets/images/stm32f030c8t6-lqfp-48.jpg',
    alt: 'A 48-pin LQFP package, the package used for the STM32F030C8T6',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Core', 'Arm Cortex-M0, 48 MHz'],
      ['Series', 'STM32F0'],
      ['Program memory', '64 KB Flash'],
      ['RAM', '8 KB SRAM'],
      ['Package', 'LQFP-48'],
      ['Supply voltage', '2.4 V to 3.6 V'],
      ['Operating temperature', '-40 to 85 \u00b0C'],
      ['Interfaces', 'I2C, SPI, UART, USART'],
      ['ADC', '12-bit, up to 12 channels'],
      ['Timers', '7 timers'],
    ],
    about: 'The STM32F030C8T6 is an STMicroelectronics STM32F0 Value-line 32-bit microcontroller with an Arm Cortex-M0 core running at 48 MHz in a 48-pin LQFP package. It provides 64 KB of flash program memory and 8 KB of SRAM, operates from 2.4 V to 3.6 V and is rated -40 to 85 \u00b0C. On-chip peripherals include a 12-bit ADC with up to 12 channels, seven timers and I2C, SPI, UART and USART interfaces. It targets small appliances, power tools, LED lighting, chargers, sensor nodes and low-cost control boards.',
    standards: [
      'ST datasheet DS9773 Rev 5 (STM32F030x4/x6/x8/xC)',
      'RoHS compliant',
      'ECOPACK package (lead-free, RoHS and REACH compliant)',
      'ESD protection per JESD22-A114 (HBM) and JESD22-C101 (CDM)',
      'Package thermal characteristics per JESD51',
      'EMC per IEC 61000-4-x and IEC 61967',
      'IEC 60335-1 household appliance safety standard applies',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Arm Cortex-M0 core running at 48 MHz',
      '64 KB flash program memory and 8 KB of SRAM',
      '12-bit ADC with up to 12 channels',
      'Seven timers and I2C, SPI, UART and USART interfaces',
      '2.4 V to 3.6 V supply voltage',
      '48-pin LQFP package',
      'Industrial temperature range -40 to 85 \u00b0C',
    ],
    applications: [
      'Small home appliances',
      'Power tools',
      'LED lighting',
      'Chargers',
      'Sensor nodes',
      'Low-cost control boards',
    ],
    faq: [
      {
        q: 'What is the STM32F030C8T6 used for?',
        a: 'It is used in small home appliances, power tools, LED lighting, chargers, sensor nodes and low-cost control boards. The 48 MHz Cortex-M0 core, 64 KB of flash, 8 KB of SRAM, 12-bit ADC and I2C, SPI, UART and USART interfaces give a low-cost control solution for products that do not need heavy computation.',
      },
      {
        q: 'What do buyers check before ordering an STM32F030C8T6?',
        a: 'Because this low-cost class is heavily targeted by domestic replacement parts such as GD32, Lingdong Micro and Huada devices, buyers first confirm whether the design must use the genuine ST original. They then check the flash and SRAM headroom, the accuracy and channel count of the 12-bit ADC, and whether CAN or USB is needed, since the F030 does not provide them. Price, minimum order quantity and lead time are compared, along with the development environment and code porting effort.',
      },
      {
        q: 'How does YIXINOU check an STM32F030C8T6 in a 48-pin LQFP package before it ships?',
        a: 'Lots are checked for original markings, labelling and tray or reel packaging, and the 48-pin LQFP leads are inspected for coplanarity, solderability and evidence of refurbishing. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'STM32F103RCT6': {
    mpn: 'STM32F103RCT6',
    brand: 'STMicroelectronics',
    title: 'STMicroelectronics STM32F103RC 32-bit Cortex-M3 MCU with 256 KB flash in LQFP-64',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The STM32F103RCT6 is an STMicroelectronics STM32F103 high-density performance line 32-bit microcontroller with an Arm Cortex-M3 core running at 72 MHz in a 64-pin LQFP package. It offers 256 KB of flash program memory, 48 KB of SRAM, a 12-bit ADC with up to 16 channels and 11 timers, together with 13 communication interfaces including USB 2.0 full speed and CAN 2.0B. The supply range is 2.0 V to 3.6 V and the industrial temperature range is -40 to 85 \u00b0C. Typical uses are industrial control, motor drives, consumer electronics, smart home devices, drones and teaching boards.',
    img: '/assets/images/stm32f103rct6-lfqfp-64.jpg',
    alt: 'A 64-pin LQFP (LFQFP) package, the package used for the STM32F103RCT6',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Core', 'Arm Cortex-M3, 72 MHz'],
      ['Series', 'STM32F1'],
      ['Program memory', '256 KB Flash'],
      ['RAM', '48 KB SRAM'],
      ['Package', 'LQFP-64 (LFQFP)'],
      ['Supply voltage', '2.0 V to 3.6 V'],
      ['Operating temperature', '-40 to 85 \u00b0C'],
      ['ADC', '12-bit, up to 16 channels'],
      ['Communication interfaces', '13 interfaces including CAN, IrDA, LIN and USB'],
      ['Timers', '11 timers'],
    ],
    about: 'The STM32F103RCT6 is an STMicroelectronics STM32F103 high-density performance line 32-bit microcontroller with an Arm Cortex-M3 core running at 72 MHz in a 64-pin LQFP package. It offers 256 KB of flash program memory, 48 KB of SRAM, a 12-bit ADC with up to 16 channels and 11 timers, with 13 communication interfaces including USB 2.0 full speed and CAN 2.0B. The supply range is 2.0 V to 3.6 V over -40 to 85 \u00b0C. Typical uses are industrial control, motor drives, consumer electronics, smart home devices, drones and teaching boards.',
    standards: [
      'ST datasheet DS5792 Rev 13 (STM32F103xC/xD/xE)',
      'RoHS compliant',
      'ECOPACK package (lead-free, RoHS and REACH compliant)',
      'ISO 7816-3 smart card interface',
      'ESD protection per JESD22-A114 (HBM) and JESD22-C101 (CDM)',
      'Package thermal characteristics per JESD51',
      'EMC per IEC 61000-4-x and IEC 61967',
      'IEC 60335-1 household appliance safety standard applies',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Arm Cortex-M3 core running at 72 MHz',
      '256 KB flash program memory and 48 KB of SRAM',
      '12-bit ADC with up to 16 channels',
      'USB 2.0 full speed and CAN 2.0B on chip',
      '11 timers and 13 communication interfaces',
      'Supply range 2.0 V to 3.6 V',
      'Industrial temperature range -40 to 85 \u00b0C',
    ],
    applications: [
      'Industrial control',
      'Motor drives',
      'Consumer electronics',
      'Smart home devices',
      'Drones',
      'Teaching and development boards',
    ],
    faq: [
      {
        q: 'What is the STM32F103RCT6 used for?',
        a: 'It is used in industrial control, motor drives, consumer electronics, smart home devices, drones and teaching or development boards. The 72 MHz Cortex-M3 core with 256 KB of flash, 48 KB of SRAM, a 16-channel 12-bit ADC, 11 timers and 13 communication interfaces including USB and CAN covers a wide range of embedded control and connectivity work.',
      },
      {
        q: 'What do buyers check before ordering an STM32F103RCT6?',
        a: 'The STM32F103 family is one of the most heavily counterfeited and refurbished lines, so buyers insist on original authorized channels and arrange appearance inspection and electrical testing. They also compare the 256 KB capacity of the RCT6 against the 512 KB RET6 and the resulting price gap, decide whether CAN and USB peripherals will actually be used, and check the temperature grade and crystal accuracy. Domestic replacements such as GD32F103 are assessed, along with supply and price.',
      },
      {
        q: 'How does YIXINOU check an STM32F103RCT6 in a 64-pin LQFP package before it ships?',
        a: 'Because this family is frequently counterfeited, each lot is checked for original markings, laser marking quality and packaging details, and the 64-pin LQFP leads are inspected for coplanarity and rework traces. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'STM32F103RET6': {
    mpn: 'STM32F103RET6',
    brand: 'STMicroelectronics',
    title: 'STMicroelectronics STM32F103RE 32-bit Cortex-M3 MCU with 512 KB flash in LQFP-64',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The STM32F103RET6 is an STMicroelectronics STM32F103 high-density performance line 32-bit microcontroller with an Arm Cortex-M3 core running at 72 MHz in a 64-pin LQFP package. It provides 512 KB of flash program memory, 64 KB of SRAM, a 12-bit ADC with up to 16 channels and 11 timers, plus a broad interface set covering CAN, I2C, I2S, IrDA, LIN, SDIO, SPI, UART, USART and USB. It runs from 2.0 V to 3.6 V over -40 to 85 \u00b0C. Typical uses are industrial control, motor drives, power management, consumer electronics, smart home products and teaching boards.',
    img: '/assets/images/stm32f103ret6-lqfp-64.jpg',
    alt: 'A 64-pin LQFP package, the package used for the STM32F103RET6',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Core', 'Arm Cortex-M3, 72 MHz'],
      ['Series', 'STM32F1'],
      ['Program memory', '512 KB Flash'],
      ['RAM', '64 KB SRAM'],
      ['Package', 'LQFP-64'],
      ['Supply voltage', '2.0 V to 3.6 V'],
      ['Operating temperature', '-40 to 85 \u00b0C'],
      ['ADC', '12-bit, up to 16 channels'],
      ['Communication interfaces', 'CAN, I2C, I2S, IrDA, LIN, SDIO, SPI, UART, USART, USB'],
      ['Timers', '11 timers'],
    ],
    about: 'The STM32F103RET6 is an STMicroelectronics STM32F103 high-density performance line 32-bit microcontroller with an Arm Cortex-M3 core at 72 MHz in a 64-pin LQFP package. It provides 512 KB of flash program memory, 64 KB of SRAM, a 12-bit ADC with up to 16 channels and 11 timers, plus a broad interface set covering CAN, I2C, I2S, IrDA, LIN, SDIO, SPI, UART, USART and USB. It runs from 2.0 V to 3.6 V over -40 to 85 \u00b0C. Typical uses are industrial control, motor drives, power management, consumer electronics, smart home products and teaching boards.',
    standards: [
      'ST datasheet DS5792 Rev 13 (STM32F103xC/xD/xE)',
      'RoHS compliant',
      'ECOPACK package (lead-free, RoHS and REACH compliant)',
      'ISO 7816-3 smart card interface',
      'ESD protection per JESD22-A114 (HBM) and JESD22-C101 (CDM)',
      'Package thermal characteristics per JESD51',
      'EMC per IEC 61000-4-x and IEC 61967',
      'IEC 60335-1 household appliance safety standard applies',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Arm Cortex-M3 core running at 72 MHz',
      '512 KB flash program memory and 64 KB of SRAM',
      '12-bit ADC with up to 16 channels',
      '11 timers and a wide CAN, I2C, I2S, IrDA, LIN, SDIO, SPI, UART, USART and USB interface set',
      'USB 2.0 full speed and CAN 2.0B',
      'Supply range 2.0 V to 3.6 V',
      'Industrial temperature range -40 to 85 \u00b0C',
    ],
    applications: [
      'Industrial control',
      'Motor drives',
      'Power management',
      'Consumer electronics',
      'Smart home products',
      'Teaching and development boards',
    ],
    faq: [
      {
        q: 'What is the STM32F103RET6 used for?',
        a: 'It is used in industrial control, motor drives, power management, consumer electronics, smart home products and teaching boards. With 512 KB of flash, 64 KB of SRAM, a 16-channel 12-bit ADC, 11 timers and interfaces covering CAN, SDIO, SPI, I2C, USART and USB, it fits designs that need more program space than the 256 KB devices in the same family.',
      },
      {
        q: 'What do buyers check before ordering an STM32F103RET6?',
        a: 'This is one of the models most affected by counterfeit and refurbished stock, so buyers require an original manufacturer channel and inspect the appearance of the parts before accepting them. They also compare the 512 KB capacity with the 256 KB RCT6, check the temperature grade and crystal matching, and confirm whether the CAN and USB peripherals are needed. Replacement options such as GD32 and other domestic Cortex-M3 parts are evaluated, along with supply and price movement.',
      },
      {
        q: 'How does YIXINOU check an STM32F103RET6 in a 64-pin LQFP package before it ships?',
        a: 'Given how often this family is counterfeited, lots are checked for original markings, marking technique and packaging, and the 64-pin LQFP leads are inspected for coplanarity, solderability and refurbishing signs. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'STM32F303RBT6': {
    mpn: 'STM32F303RBT6',
    brand: 'STMicroelectronics',
    title: 'STMicroelectronics STM32F303RB 32-bit Cortex-M4 MCU with FPU in LQFP-64',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The STM32F303RBT6 is an STMicroelectronics STM32F303xB 32-bit microcontroller with an Arm Cortex-M4F core including a floating-point unit, running at 72 MHz in a 64-pin LQFP package. It provides 128 KB of flash program memory and 40 KB of SRAM and operates from 2.0 V to 3.6 V over the -40 to 85 \u00b0C industrial range. Its strength is analog integration: four 12-bit ADCs with up to 39 channels, two 12-bit DACs, seven comparators and four programmable gain amplifiers. It is used in motor control, digital power, sensor signal processing, medical instrumentation and industrial measurement.',
    img: '/assets/images/stm32f303rbt6-lqfp-64.jpg',
    alt: 'A 64-pin LQFP package, the package used for the STM32F303RBT6',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Core', 'Arm Cortex-M4F with FPU, 72 MHz'],
      ['Series', 'STM32F3'],
      ['Program memory', '128 KB Flash'],
      ['RAM', '40 KB SRAM'],
      ['Package', 'LQFP-64'],
      ['Supply voltage', '2.0 V to 3.6 V'],
      ['Operating temperature', '-40 to 85 \u00b0C'],
      ['ADC', '4 x 12-bit, up to 39 channels'],
      ['DAC and analog', '2 x 12-bit DAC, 7 comparators, 4 programmable gain amplifiers'],
      ['Interfaces', 'CAN, I2C, I2S, IrDA, LIN, SPI, UART, USART, USB'],
    ],
    about: 'The STM32F303RBT6 is an STMicroelectronics STM32F303xB 32-bit microcontroller with an Arm Cortex-M4F core including a floating-point unit, running at 72 MHz in a 64-pin LQFP package. It has 128 KB of flash program memory and 40 KB of SRAM, and it operates from 2.0 V to 3.6 V over the -40 to 85 \u00b0C industrial range. Its strength is analog integration: four 12-bit ADCs with up to 39 channels, two 12-bit DACs, seven comparators and four programmable gain amplifiers. It is used in motor control, digital power, sensor signal processing, medical instrumentation and industrial measurement.',
    standards: [
      'ST datasheet DS9118 Rev 14 (STM32F303xB/xC)',
      'RoHS compliant',
      'ECOPACK package (lead-free, RoHS and REACH compliant)',
      'ISO 7816-3 smart card interface',
      'ESD protection per JESD22-A114 (HBM) and JESD22-C101 (CDM)',
      'EMC per IEC 61000-4-x and IEC 61967',
      'IEC 60335-1 household appliance safety standard applies',
      'Operational amplifiers and comparators per JESD78 latch-up testing',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Arm Cortex-M4F core with floating-point unit at 72 MHz',
      '128 KB flash program memory and 40 KB of SRAM',
      'Four 12-bit ADCs with up to 39 channels',
      'Two 12-bit DACs, seven comparators and four programmable gain amplifiers',
      'CAN, I2C, I2S, IrDA, LIN, SPI, UART, USART and USB interfaces',
      'Supply range 2.0 V to 3.6 V',
      'Industrial temperature range -40 to 85 \u00b0C',
    ],
    applications: [
      'Motor control with field-oriented control',
      'Digital power',
      'Sensor signal processing',
      'Medical instrumentation',
      'Industrial measurement',
    ],
    faq: [
      {
        q: 'What is the STM32F303RBT6 used for?',
        a: 'It is used in motor control with field-oriented control, digital power supplies, sensor signal processing, medical instrumentation and industrial measurement. The part is chosen where analog performance matters, because it carries four 12-bit ADCs with up to 39 channels, two 12-bit DACs, seven comparators and four programmable gain amplifiers alongside the 72 MHz Cortex-M4F core with FPU.',
      },
      {
        q: 'What do buyers check before ordering an STM32F303RBT6?',
        a: 'Buyers confirm the ADC, DAC and operational amplifier configuration they need, since the F303 series is chosen mainly for its rich analog periphery. They also assess how easily existing F103 designs can move to this part, verify that the supply is original, and check the temperature grade, price and lead time. Whether the family has been superseded by the G4 series is another question raised during selection.',
      },
      {
        q: 'How does YIXINOU check an STM32F303RBT6 in a 64-pin LQFP package before it ships?',
        a: 'Lots are checked for original markings and packaging, and the 64-pin LQFP leads are inspected for coplanarity, solderability and traces of prior rework. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'STM32F405RGT6': {
    mpn: 'STM32F405RGT6',
    brand: 'STMicroelectronics',
    title: 'STMicroelectronics STM32F405RG 32-bit Cortex-M4 MCU with FPU and 1 MB flash in LQFP-64',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The STM32F405RGT6 is an STMicroelectronics STM32F405 32-bit microcontroller with an Arm Cortex-M4F core including a floating-point unit, running at 168 MHz and delivering 210 DMIPS in a 64-pin LQFP package. It offers 1 MB of flash program memory, 192 KB plus 4 KB of SRAM, three 12-bit ADCs with up to 24 channels, two 12-bit DACs, 17 timers, an RTC and USB OTG high speed and full speed. The supply range is 1.8 V to 3.6 V over -40 to 85 \u00b0C. It is common in drone flight controllers, industrial control, audio processing, motor drives and data acquisition.',
    img: '/assets/images/stm32f405rgt6-lqfp-64.jpg',
    alt: 'A 64-pin LQFP package, the package used for the STM32F405RGT6',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Core', 'Arm Cortex-M4F, 168 MHz / 210 DMIPS'],
      ['Series', 'STM32F4'],
      ['Program memory', '1 MB Flash'],
      ['RAM', '192 KB + 4 KB SRAM'],
      ['Package', 'LQFP-64'],
      ['Supply voltage', '1.8 V to 3.6 V'],
      ['Operating temperature', '-40 to 85 \u00b0C'],
      ['ADC', '3 x 12-bit, up to 24 channels'],
      ['USB', 'USB OTG high speed and full speed'],
      ['Timers', '17 timers'],
    ],
    about: 'The STM32F405RGT6 is an STMicroelectronics STM32F405 32-bit microcontroller with an Arm Cortex-M4F core including a floating-point unit, running at 168 MHz and delivering 210 DMIPS in a 64-pin LQFP package. It offers 1 MB of flash program memory, 192 KB plus 4 KB of SRAM, three 12-bit ADCs with up to 24 channels, two 12-bit DACs, 17 timers, an RTC and USB OTG high speed and full speed. The supply range is 1.8 V to 3.6 V over -40 to 85 \u00b0C. It is common in drone flight controllers, industrial control, audio processing, motor drives and data acquisition.',
    standards: [
      'ST datasheet DS8626 Rev 12 (STM32F405xx/STM32F407xx)',
      'RoHS compliant',
      'ECOPACK2 package (lead-free, RoHS and REACH compliant)',
      'ISO 7816-3 smart card interface',
      'ESD protection per JESD22-A114 (HBM) and JESD22-C101 (CDM)',
      'Package thermal characteristics per JESD51',
      'EMC per IEC 61000-4-x and IEC 61967',
      'IEC 60335-1 and IEC 60335-2 household appliance safety standards apply',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Arm Cortex-M4F core with floating-point unit at 168 MHz and 210 DMIPS',
      '1 MB flash program memory and 192 KB plus 4 KB of SRAM',
      'Three 12-bit ADCs with up to 24 channels and two 12-bit DACs',
      'USB OTG high speed and full speed',
      '17 timers and an on-chip RTC',
      'Supply range 1.8 V to 3.6 V',
      'Industrial temperature range -40 to 85 \u00b0C',
    ],
    applications: [
      'Drone flight controllers, widely used in Pixhawk class designs',
      'Industrial control',
      'Audio processing',
      'Motor drives',
      'Data acquisition',
    ],
    faq: [
      {
        q: 'What is the STM32F405RGT6 used for?',
        a: 'It is used in drone flight controllers, where it is common in Pixhawk class designs, as well as industrial control, audio processing, motor drives and data acquisition. The 168 MHz Cortex-M4F core with FPU, 1 MB of flash, 192 KB plus 4 KB of SRAM, three 12-bit ADCs, two DACs, 17 timers and USB OTG high speed and full speed support demanding control and signal processing tasks.',
      },
      {
        q: 'What do buyers check before ordering an STM32F405RGT6?',
        a: 'Because flight controller and open source communities use this part in large volumes, buyers pay close attention to sourcing from a genuine channel. They also compare the F405 with the F407 model, noting that the F405 does not include an Ethernet MAC, check whether 64 pins provide enough I/O for the design, and confirm the temperature grade. Replacement options, supply and price are reviewed at the same time.',
      },
      {
        q: 'How does YIXINOU check an STM32F405RGT6 in a 64-pin LQFP package before it ships?',
        a: 'Each lot is checked for original markings, labelling and packaging consistency, and the 64-pin LQFP leads are inspected for coplanarity, solderability and any sign of previous use. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'STM32F407ZGT6': {
    mpn: 'STM32F407ZGT6',
    brand: 'STMicroelectronics',
    title: '168 MHz Arm Cortex-M4F MCU with 1 MB Flash, Ethernet MAC and USB OTG in LQFP-144',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The STM32F407ZGT6 is an STMicroelectronics STM32F4 series 32-bit microcontroller built on an Arm Cortex-M4F core running at 168 MHz and rated at 210 DMIPS. It integrates 1 MB of Flash with 192 KB plus 4 KB of SRAM in an LQFP-144 package carrying 114 programmable I/Os. The peripheral set includes a 10/100 Ethernet MAC, USB OTG high-speed and full-speed, three 12-bit ADCs, two DAC channels, 17 timers and a DCMI camera interface. It runs from a 1.8 V to 3.6 V supply over -40 \u00b0C to 85 \u00b0C and is listed as production status.',
    img: '/assets/images/stm32f407zgt6-lqfp-144.jpg',
    alt: 'A 144-lead LQFP package, the package used for the STM32F407ZGT6',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'LQFP-144'],
      ['Number of pins', '144'],
      ['Core', 'Arm Cortex-M4F'],
      ['Maximum CPU frequency', '168 MHz'],
      ['Program memory', '1 MB Flash'],
      ['SRAM', '192 KB + 4 KB'],
      ['Supply voltage', '1.8 V to 3.6 V'],
      ['Operating temperature', '-40 \u00b0C to 85 \u00b0C'],
      ['Interfaces', 'CAN, EBI/EMI, Ethernet, I2C, I2S, IrDA, LIN, SPI, UART, USART, USB'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The STM32F407ZGT6 is a 32-bit microcontroller from the STM32F407xx family with an Arm Cortex-M4F core at 168 MHz, 1 MB Flash and 192 KB plus 4 KB SRAM in an LQFP-144 package. Connectivity covers a 10/100 Ethernet MAC, USB OTG HS/FS, CAN, I2C, I2S, SPI, UART and USART, while the analog side provides three 12-bit ADCs and two DAC channels. Seventeen timers, a DCMI camera interface and 114 programmable I/Os support control, display and imaging work. It is used in industrial gateways, image acquisition, industrial HMIs, robot control, audio processing and power monitoring terminals.',
    standards: [
      'STMicroelectronics datasheet DS8626 Rev 12 (STM32F405xx / STM32F407xx)',
      'RoHS compliant, ECOPACK2 lead-free package meeting RoHS and REACH',
      'ISO 7816-3 smart card interface compliant',
      'ESD protection per JESD22-A114 (HBM) and JESD22-C101 (CDM)',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Arm Cortex-M4F core at 168 MHz, 210 DMIPS',
      '1 MB Flash and 192 KB plus 4 KB SRAM',
      '10/100 Ethernet MAC and USB OTG HS/FS',
      'Three 12-bit ADCs and two DAC channels',
      '17 timers plus a DCMI camera interface',
      '114 programmable I/Os in LQFP-144',
      'FMC support for external SDRAM and NAND',
      '1.8 V to 3.6 V supply, -40 \u00b0C to 85 \u00b0C',
    ],
    applications: [
      'Industrial gateways',
      'Image acquisition',
      'Industrial HMI',
      'Robot control',
      'Audio processing',
      'Power monitoring terminals',
    ],
    faq: [
      {
        q: 'What is the STM32F407ZGT6 used for?',
        a: 'It is used in industrial gateways, image acquisition front ends, industrial human-machine interfaces, robot control, audio processing and power monitoring terminals. The Cortex-M4F core at 168 MHz, 1 MB Flash, Ethernet MAC, USB OTG and DCMI camera interface suit designs that combine control, networking and imaging in one device.',
      },
      {
        q: 'What do buyers check before ordering an STM32F407ZGT6?',
        a: 'Buyers verify that the parts are genuine and not refurbished units with re-marked silkscreen, because the F407 is a very high-volume industrial part. They also confirm the pin-count suffix, since the 144-pin ZGT6 differs in pinout from the 100-pin VGT6 and the 176-pin IGT6, check the temperature grade, plan the Ethernet PHY and DCMI wiring, and confirm FMC support for external SDRAM or NAND.',
      },
      {
        q: 'How does YIXINOU check an STM32F407ZGT6 before it ships?',
        a: 'Each LQFP-144 lot of the STM32F407ZGT6 is checked against the supplied ST datasheet before dispatch, covering device marking, date code, lead finish and pin condition. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'STM32F427VGT6': {
    mpn: 'STM32F427VGT6',
    brand: 'STMicroelectronics',
    title: '180 MHz Arm Cortex-M4F MCU with 1 MB Flash, Chrom-ART and Ethernet in LQFP-100',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The STM32F427VGT6 is an STMicroelectronics STM32F4 series 32-bit microcontroller with an Arm Cortex-M4F core at 180 MHz delivering 225 DMIPS. It provides 1 MB of Flash and 192 KB plus 4 KB of SRAM in an LQFP-100 package with 82 programmable I/Os. On-chip functions include an Ethernet MAC, USB OTG HS/FS, an LCD-TFT controller, a Chrom-ART graphics accelerator, three 12-bit ADCs, two DAC channels and 17 timers. It operates from a 1.8 V to 3.6 V supply over -40 \u00b0C to 85 \u00b0C and is listed as production status.',
    img: '/assets/images/stm32f427vgt6-lqfp-100.jpg',
    alt: 'A 100-lead LQFP package, the package used for the STM32F427VGT6',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'LQFP-100'],
      ['Number of pins', '100'],
      ['Core', 'Arm Cortex-M4F'],
      ['Maximum CPU frequency', '180 MHz'],
      ['Program memory', '1 MB Flash'],
      ['SRAM', '192 KB + 4 KB'],
      ['Supply voltage', '1.8 V to 3.6 V'],
      ['Operating temperature', '-40 \u00b0C to 85 \u00b0C'],
      ['Interfaces', 'CAN, EBI/EMI, Ethernet, I2C, I2S, IrDA, LIN, SPI, UART, USART, USB'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The STM32F427VGT6 is a 32-bit microcontroller from the STM32F427xx family built on an Arm Cortex-M4F core at 180 MHz with 1 MB Flash and 192 KB plus 4 KB SRAM in an LQFP-100 package. It combines an Ethernet MAC, USB OTG HS/FS, CAN, I2C, SPI, UART and USART with an LCD-TFT controller and a Chrom-ART graphics accelerator. Three 12-bit ADCs, two DAC channels and 17 timers cover analog and timing duties, and the Flash accelerator supports larger firmware. It is used in industrial automation, servo drives, robot control, industrial gateways, medical instruments and image processing.',
    standards: [
      'STMicroelectronics datasheet DS9405 Rev 13 (STM32F427xx / STM32F429xx)',
      'RoHS compliant, ECOPACK2 lead-free package meeting RoHS and REACH',
      'ISO 7816-3 smart card interface compliant',
      'ESD protection per JESD22-A114 (HBM) and JESD22-C101 (CDM)',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Arm Cortex-M4F core at 180 MHz, 225 DMIPS',
      '1 MB Flash and 192 KB plus 4 KB SRAM',
      'Ethernet MAC and USB OTG HS/FS',
      'LCD-TFT controller and Chrom-ART graphics accelerator',
      'Three 12-bit ADCs and two DAC channels',
      '17 timers plus camera and LCD-TFT interfaces',
      '82 programmable I/Os in LQFP-100',
      '1.8 V to 3.6 V supply, -40 \u00b0C to 85 \u00b0C',
    ],
    applications: [
      'Industrial automation',
      'Servo drives',
      'Robot control',
      'Industrial gateways',
      'Medical instruments',
      'Image processing terminals',
    ],
    faq: [
      {
        q: 'What is the STM32F427VGT6 used for?',
        a: 'It is used in industrial automation, servo drives, robot control, industrial gateways, medical instruments and image processing terminals. The 180 MHz Cortex-M4F core, 1 MB Flash, Ethernet MAC, USB OTG, LCD-TFT controller and Chrom-ART accelerator fit equipment that needs motion control together with a graphical or networked front end.',
      },
      {
        q: 'What do buyers check before ordering an STM32F427VGT6?',
        a: 'Buyers assess the pinout and peripheral differences against the STM32F407 series, because a drop-in replacement needs evaluation. They also confirm genuine ST material, verify the T6 or I6 temperature grade, check that the Ethernet and USB peripherals meet the design, and confirm the Flash accelerator and SDRAM interface requirements, along with supply and price.',
      },
      {
        q: 'How does YIXINOU check an STM32F427VGT6 before it ships?',
        a: 'LQFP-100 deliveries of the STM32F427VGT6 are inspected against the supplied ST datasheet, with device marking, date code, lead finish and pin condition verified before packing. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'STM32F429IIT6': {
    mpn: 'STM32F429IIT6',
    brand: 'STMicroelectronics',
    title: '180 MHz Arm Cortex-M4F MCU with 2 MB Flash and LCD-TFT controller in LQFP-176',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The STM32F429IIT6 is an STMicroelectronics STM32F4 series 32-bit microcontroller with an Arm Cortex-M4F core at 180 MHz rated at 225 DMIPS. It carries 2 MB of Flash and 256 KB plus 4 KB of SRAM in an LQFP-176 package with 140 programmable I/Os. The LCD-TFT parallel controller, Chrom-ART graphics accelerator and SDRAM expansion support rich displays, while an Ethernet MAC, USB OTG HS/FS, three 12-bit ADCs and two DAC channels cover connectivity and analog needs. It runs from a 1.8 V to 3.6 V supply over -40 \u00b0C to 85 \u00b0C and is listed as production status.',
    img: '/assets/images/stm32f429iit6-lqfp-176.jpg',
    alt: 'A 176-lead LQFP package, the package used for the STM32F429IIT6',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'LQFP-176'],
      ['Number of pins', '176'],
      ['Core', 'Arm Cortex-M4F'],
      ['Maximum CPU frequency', '180 MHz'],
      ['Program memory', '2 MB Flash'],
      ['SRAM', '256 KB + 4 KB'],
      ['Supply voltage', '1.8 V to 3.6 V'],
      ['Operating temperature', '-40 \u00b0C to 85 \u00b0C'],
      ['Interfaces', 'CAN, EBI/EMI, Ethernet, I2C, I2S, IrDA, LIN, SDIO, SPI, UART, USART, USB'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The STM32F429IIT6 is a 32-bit microcontroller from the STM32F429xx family with an Arm Cortex-M4F core at 180 MHz, 2 MB Flash and 256 KB plus 4 KB SRAM in an LQFP-176 package with 140 programmable I/Os. Its LCD-TFT parallel controller, Chrom-ART accelerator and SDRAM expansion make it display-oriented, backed by an Ethernet MAC, USB OTG HS/FS, CAN, SDIO, SPI, UART and USART. Three 12-bit ADCs and two DAC channels handle analog signals, and 17 timers cover timing. It is used in industrial HMIs, smart metering, medical equipment, gateways, graphic display terminals and drone flight control.',
    standards: [
      'STMicroelectronics datasheet DS9405 Rev 13 (STM32F427xx / STM32F429xx)',
      'RoHS compliant, ECOPACK2 lead-free package meeting RoHS and REACH',
      'ISO 7816-3 smart card interface compliant',
      'ESD protection per JESD22-A114 (HBM) and JESD22-C101 (CDM)',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Arm Cortex-M4F core at 180 MHz, 225 DMIPS',
      '2 MB Flash and 256 KB plus 4 KB SRAM',
      'LCD-TFT parallel controller with SDRAM expansion',
      'Chrom-ART graphics accelerator',
      'Ethernet MAC and USB OTG HS/FS',
      'Three 12-bit ADCs and two DAC channels',
      '140 programmable I/Os in LQFP-176',
      '1.8 V to 3.6 V supply, -40 \u00b0C to 85 \u00b0C',
    ],
    applications: [
      'Industrial HMI',
      'Smart metering',
      'Medical equipment',
      'Industrial gateways',
      'Graphic display terminals',
      'Drone flight control',
    ],
    faq: [
      {
        q: 'What is the STM32F429IIT6 used for?',
        a: 'It is used in industrial human-machine interfaces, smart metering, medical equipment, industrial gateways, graphic display terminals and drone flight control. The 2 MB Flash, 256 KB SRAM, LCD-TFT parallel controller with SDRAM expansion and Chrom-ART accelerator target products that drive a colour display while also running control and communication tasks.',
      },
      {
        q: 'What do buyers check before ordering an STM32F429IIT6?',
        a: 'Buyers check that the board crystal and power decoupling are specified so that start-up problems do not occur, and confirm the parts are genuine ST material rather than counterfeit or refurbished stock. They also verify whether Flash and SRAM are sufficient, confirm the T6 (-40 to 85 \u00b0C) rather than the I6 (-40 to 105 \u00b0C) grade, match the LCD controller to the required resolution, and review lead time, alternatives such as the STM32F439 or H7 series, and toolchain support.',
      },
      {
        q: 'How does YIXINOU check an STM32F429IIT6 before it ships?',
        a: 'For LQFP-176 shipments of the STM32F429IIT6 we confirm device marking, date code, lead finish and pin coplanarity against the supplied ST datasheet before packing. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'STM32F429ZGT6': {
    mpn: 'STM32F429ZGT6',
    brand: 'STMicroelectronics',
    title: '180 MHz Arm Cortex-M4F MCU with 1 MB Flash and LCD-TFT controller in LQFP-144',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The STM32F429ZGT6 is an STMicroelectronics STM32F4 series 32-bit microcontroller with an Arm Cortex-M4F core at 180 MHz and 225 DMIPS. It combines 1 MB of Flash with 256 KB plus 4 KB of SRAM in an LQFP-144 package holding 114 programmable I/Os. The device includes an LCD-TFT parallel controller, a Chrom-ART graphics accelerator, an Ethernet MAC, USB OTG HS/FS, three 12-bit ADCs and two DAC channels. It operates from a 1.8 V to 3.6 V supply over -40 \u00b0C to 85 \u00b0C and is listed as production status.',
    img: '/assets/images/stm32f429zgt6-lqfp-144.jpg',
    alt: 'A 144-lead LQFP package, the package used for the STM32F429ZGT6',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'LQFP-144'],
      ['Number of pins', '144'],
      ['Core', 'Arm Cortex-M4F'],
      ['Maximum CPU frequency', '180 MHz'],
      ['Program memory', '1 MB Flash'],
      ['SRAM', '256 KB + 4 KB'],
      ['Supply voltage', '1.8 V to 3.6 V'],
      ['Operating temperature', '-40 \u00b0C to 85 \u00b0C'],
      ['Interfaces', 'CAN, EBI/EMI, Ethernet, I2C, I2S, IrDA, LIN, SDIO, SPI, UART, USART, USB'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The STM32F429ZGT6 is a 32-bit microcontroller from the STM32F429xx family with an Arm Cortex-M4F core at 180 MHz, 1 MB Flash and 256 KB plus 4 KB SRAM in an LQFP-144 package. The LCD-TFT parallel controller and Chrom-ART graphics accelerator are its headline functions, supported by an Ethernet MAC, USB OTG HS/FS, CAN, SDIO, SPI, UART and USART. Three 12-bit ADCs, two DAC channels and 17 timers handle analog and timing work across 114 programmable I/Os. It is used in industrial HMIs and display driving, smart metering, medical equipment, graphic terminals and industrial automation.',
    standards: [
      'STMicroelectronics datasheet DS9405 Rev 13 (STM32F427xx / STM32F429xx)',
      'RoHS compliant, ECOPACK2 lead-free package meeting RoHS and REACH',
      'ISO 7816-3 smart card interface compliant',
      'ESD protection per JESD22-A114 (HBM) and JESD22-C101 (CDM)',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Arm Cortex-M4F core at 180 MHz, 225 DMIPS',
      '1 MB Flash and 256 KB plus 4 KB SRAM',
      'LCD-TFT parallel controller and Chrom-ART accelerator',
      'Ethernet MAC and USB OTG HS/FS',
      'Three 12-bit ADCs and two DAC channels',
      '17 timers and SDIO interface',
      '114 programmable I/Os in LQFP-144',
      '1.8 V to 3.6 V supply, -40 \u00b0C to 85 \u00b0C',
    ],
    applications: [
      'Industrial HMI and display driving',
      'Smart metering',
      'Medical equipment',
      'Graphic terminals',
      'Industrial automation',
    ],
    faq: [
      {
        q: 'What is the STM32F429ZGT6 used for?',
        a: 'It is used to drive industrial human-machine interfaces and displays, smart metering, medical equipment, graphic terminals and industrial automation. The LCD-TFT controller, Chrom-ART accelerator and 1 MB Flash let equipment render a graphical interface while the Ethernet MAC, USB OTG and CAN interfaces handle networking and field-bus traffic.',
      },
      {
        q: 'What do buyers check before ordering an STM32F429ZGT6?',
        a: 'The LCD controller is the key selling point, so buyers confirm the panel resolution and the RGB or LTDC interface it needs. They also compare the 144-pin ZGT6 against the 176-pin IIT6 and 100-pin VGT6, plan the external SDRAM frame buffer, confirm the parts are genuine, check the temperature grade, and review supply and price.',
      },
      {
        q: 'How does YIXINOU check an STM32F429ZGT6 before it ships?',
        a: 'Each LQFP-144 lot of the STM32F429ZGT6 is compared with the supplied ST datasheet, checking marking, date code, lead finish and pin condition before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'STM32G474RET6': {
    mpn: 'STM32G474RET6',
    brand: 'STMicroelectronics',
    title: '170 MHz Arm Cortex-M4F MCU with 512 KB Flash, CORDIC and FMAC accelerators in LQFP-64',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The STM32G474RET6 is an STMicroelectronics STM32G4 series 32-bit microcontroller with an Arm Cortex-M4F core at 170 MHz rated at 213 DMIPS. It provides 512 KB of Flash and 128 KB of SRAM in an LQFP-64 package with 52 programmable I/Os. Dedicated CORDIC and FMAC math accelerators, a 184 ps high-resolution timer, five 12-bit ADCs, seven DAC and comparator channels and FDCAN target precision control loops. It operates from a 1.71 V to 3.6 V supply over -40 \u00b0C to 85 \u00b0C and is listed as production status.',
    img: '/assets/images/stm32g474ret6-lqfp-64.jpg',
    alt: 'A 64-lead LQFP package, the package used for the STM32G474RET6',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'LQFP-64'],
      ['Number of pins', '64'],
      ['Core', 'Arm Cortex-M4F'],
      ['Maximum CPU frequency', '170 MHz'],
      ['Program memory', '512 KB Flash'],
      ['SRAM', '128 KB'],
      ['Supply voltage', '1.71 V to 3.6 V'],
      ['Operating temperature', '-40 \u00b0C to 85 \u00b0C'],
      ['Interfaces', 'CAN, I2C, I2S, IrDA, LIN, SMBus, SPI, UART, USART, USB'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The STM32G474RET6 is a 32-bit microcontroller from the STM32G474xE family with an Arm Cortex-M4F core at 170 MHz, 512 KB Flash and 128 KB SRAM in an LQFP-64 package with 52 programmable I/Os. It is built for control loops: a CORDIC accelerator, an FMAC filter accelerator and a 184 ps high-resolution timer work with five 12-bit ADCs, seven DAC/comparator channels and FDCAN. Communication covers CAN, I2C, SMBus, SPI, UART, USART and USB. It is used in digital power such as LLC and totem-pole PFC, FOC motor drive, photovoltaic inverters, charging piles, and servo and industrial automation.',
    standards: [
      'STMicroelectronics datasheet DS12288 Rev 6 (STM32G474xB / xC / xE)',
      'RoHS compliant, ECOPACK2 lead-free package meeting RoHS and REACH',
      'ISO 7816-3 smart card interface and ISO 11898-1 (CAN) compliant',
      'Reliability verification per JESD47, latch-up per JESD78 and life test per JESD36',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Arm Cortex-M4F core at 170 MHz, 213 DMIPS',
      '512 KB Flash and 128 KB SRAM',
      'CORDIC trigonometric and FMAC filter accelerators',
      '184 ps high-resolution timer for digital power',
      'Five 12-bit ADCs and seven DAC or comparator channels',
      'FDCAN plus CAN, SMBus, UART and USB interfaces',
      '52 programmable I/Os in LQFP-64',
      '1.71 V to 3.6 V supply, -40 \u00b0C to 85 \u00b0C',
    ],
    applications: [
      'Digital power (LLC and totem-pole PFC)',
      'Motor drive (FOC)',
      'Photovoltaic inverters',
      'EV charging piles',
      'Servo and industrial automation',
    ],
    faq: [
      {
        q: 'What is the STM32G474RET6 used for?',
        a: 'It is used in digital power stages such as LLC and totem-pole PFC, field-oriented motor drive, photovoltaic inverters, EV charging piles, and servo and industrial automation. The 184 ps high-resolution timer, five 12-bit ADCs, CORDIC and FMAC accelerators and FDCAN are aimed at fast, precise control loops in power conversion equipment.',
      },
      {
        q: 'What do buyers check before ordering an STM32G474RET6?',
        a: 'The high-resolution timer and high-precision ADC are the core selling points, so buyers confirm whether the design actually uses them. They also compare the part against the STM32G431 and G491 options, verify that the material is genuine, plan for the CORDIC and FMAC acceleration libraries, check the temperature grade and thermal design, and review supply and price.',
      },
      {
        q: 'How does YIXINOU check an STM32G474RET6 before it ships?',
        a: 'Every LQFP-64 reel of the STM32G474RET6 is examined against the supplied ST datasheet, with marking, date code, lead finish and pin condition confirmed before packing. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'STM32H743VGT6': {
    mpn: 'STM32H743VGT6',
    brand: 'STMicroelectronics',
    title: '480 MHz Arm Cortex-M7 MCU with 1 MB Flash, FMC, LCD-TFT and Ethernet in LQFP-100',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The STM32H743VGT6 is an STMicroelectronics STM32H7 series 32-bit microcontroller with an Arm Cortex-M7 core running at 480 MHz. It offers 1 MB of Flash and 1 MB of SRAM in an LQFP-100 package with 82 programmable I/Os. The device integrates an FMC external memory interface, an LCD-TFT controller, Ethernet, a JPEG hardware codec, a Chrom-ART graphics accelerator, three 16-bit ADCs and two DAC channels. It runs from a 1.71 V to 3.6 V supply over -40 \u00b0C to 85 \u00b0C and is listed as production status.',
    img: '/assets/images/stm32h743vgt6-lqfp-100.jpg',
    alt: 'A 100-lead LQFP package, the package used for the STM32H743VGT6',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'LQFP-100'],
      ['Number of pins', '100'],
      ['Core', 'Arm Cortex-M7'],
      ['Maximum CPU frequency', '480 MHz'],
      ['Program memory', '1 MB Flash'],
      ['SRAM', '1 MB'],
      ['Supply voltage', '1.71 V to 3.6 V'],
      ['Operating temperature', '-40 \u00b0C to 85 \u00b0C'],
      ['On-chip peripherals', 'FMC, LCD-TFT, Ethernet, JPEG codec, Chrom-ART accelerator'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The STM32H743VGT6 is a 32-bit microcontroller from the STM32H743xG family with an Arm Cortex-M7 core at 480 MHz, 1 MB Flash and 1 MB SRAM in an LQFP-100 package with 82 programmable I/Os. It brings an FMC interface, an LCD-TFT controller, Ethernet, a JPEG hardware codec and a Chrom-ART accelerator, plus three 16-bit ADCs, two DAC channels and 46 communication and analog interfaces. The high core speed and large SRAM support demanding workloads. It is used in edge AI inference, high-end HMIs, industrial gateways, medical equipment, drone flight control and audio and image processing.',
    standards: [
      'STMicroelectronics datasheet DS12110 Rev 11 (STM32H742xI / xG, STM32H743xI / xG)',
      'RoHS compliant, ECOPACK2 lead-free package meeting RoHS and REACH',
      'ISO 7816-3 smart card interface and ISO 11898-1 (CAN) compliant',
      'IEC 10918 (JPEG) hardware codec conformity',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Arm Cortex-M7 core at 480 MHz',
      '1 MB Flash and 1 MB SRAM',
      'FMC, LCD-TFT controller and Ethernet',
      'JPEG hardware codec and Chrom-ART accelerator',
      'Three 16-bit ADCs and two DAC channels',
      '46 communication and analog interfaces',
      '82 programmable I/Os in LQFP-100',
      '1.71 V to 3.6 V supply, -40 \u00b0C to 85 \u00b0C',
    ],
    applications: [
      'Edge AI inference',
      'High-end HMI',
      'Industrial gateways',
      'Medical equipment',
      'Drone flight control',
      'Audio and image processing',
    ],
    faq: [
      {
        q: 'What is the STM32H743VGT6 used for?',
        a: 'It is used for edge AI inference, high-end human-machine interfaces, industrial gateways, medical equipment, drone flight control, and audio and image processing. The 480 MHz Cortex-M7 core, 1 MB SRAM, JPEG codec, Chrom-ART accelerator, LCD-TFT controller and Ethernet support compute-heavy products that also need graphics and networking.',
      },
      {
        q: 'What do buyers check before ordering an STM32H743VGT6?',
        a: 'The most common mistake is confusing the VGT6, which has 1 MB Flash, with the VIT6, which has 2 MB, so buyers confirm the capacity suffix carefully. They also review the TCM partitioning and cache coherency of the 1 MB RAM, the PCB layout for the high-speed peripherals, the genuineness of the material, the temperature grade, and lead time and price, since the H7 series has longer lead times.',
      },
      {
        q: 'How does YIXINOU check an STM32H743VGT6 before it ships?',
        a: 'LQFP-100 lots of the STM32H743VGT6 are checked against the supplied ST datasheet, covering marking, date code, lead finish and pin condition before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'STM32H743VIT6': {
    mpn: 'STM32H743VIT6',
    brand: 'STMicroelectronics',
    title: '480 MHz Arm Cortex-M7 MCU with 2 MB Flash, FMC, LCD-TFT and Ethernet in LQFP-100',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The STM32H743VIT6 is an STMicroelectronics STM32H7 series 32-bit microcontroller with an Arm Cortex-M7 core at 480 MHz. It carries 2 MB of Flash and 1 MB of SRAM in an LQFP-100 package with 82 programmable I/Os. The peripheral set covers an FMC external memory interface, an LCD-TFT controller, Ethernet, a JPEG hardware codec, a Chrom-ART graphics accelerator, three 16-bit ADCs and two DAC channels. It operates from a 1.71 V to 3.6 V supply over -40 \u00b0C to 85 \u00b0C and is listed as production status.',
    img: '/assets/images/stm32h743vit6-lqfp-100.jpg',
    alt: 'A 100-lead LQFP package, the package used for the STM32H743VIT6',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'LQFP-100'],
      ['Number of pins', '100'],
      ['Core', 'Arm Cortex-M7'],
      ['Maximum CPU frequency', '480 MHz'],
      ['Program memory', '2 MB Flash'],
      ['SRAM', '1 MB'],
      ['Supply voltage', '1.71 V to 3.6 V'],
      ['Operating temperature', '-40 \u00b0C to 85 \u00b0C'],
      ['Interfaces', 'Ethernet, I2C, I2S, IrDA, LIN, SPI, UART, USART, USB'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The STM32H743VIT6 is a 32-bit microcontroller from the STM32H743xI family with an Arm Cortex-M7 core at 480 MHz, 2 MB Flash and 1 MB SRAM in an LQFP-100 package with 82 programmable I/Os. It provides an FMC interface, an LCD-TFT controller, Ethernet, a JPEG hardware codec, a Chrom-ART accelerator, three 16-bit ADCs and two DAC channels, plus 46 communication and analog interfaces. The 2 MB Flash gives extra room for larger firmware. It is used in high-end industrial HMIs, edge AI inference, industrial gateways, medical equipment, audio processing, drone flight control and power monitoring.',
    standards: [
      'STMicroelectronics datasheet DS12110 Rev 11 (STM32H742xI / xG, STM32H743xI / xG)',
      'RoHS compliant, ECOPACK2 lead-free package meeting RoHS and REACH',
      'ISO 7816-3 smart card interface and ISO 11898-1 (CAN) compliant',
      'IEC 10918 (JPEG) hardware codec conformity',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Arm Cortex-M7 core at 480 MHz',
      '2 MB Flash and 1 MB SRAM',
      'FMC, LCD-TFT controller and Ethernet',
      'JPEG hardware codec and Chrom-ART accelerator',
      'Three 16-bit ADCs and two DAC channels',
      '46 communication and analog interfaces',
      '82 programmable I/Os in LQFP-100',
      '1.71 V to 3.6 V supply, -40 \u00b0C to 85 \u00b0C',
    ],
    applications: [
      'High-end industrial HMI',
      'Edge AI inference',
      'Industrial gateways',
      'Medical equipment',
      'Audio processing',
      'Power monitoring',
    ],
    faq: [
      {
        q: 'What is the STM32H743VIT6 used for?',
        a: 'It is used in high-end industrial human-machine interfaces, edge AI inference, industrial gateways, medical equipment, audio processing, drone flight control and power monitoring. The 2 MB Flash, 1 MB SRAM, 480 MHz Cortex-M7 core, JPEG codec, Chrom-ART accelerator and LCD-TFT controller suit products with large firmware images plus graphics and networking.',
      },
      {
        q: 'What do buyers check before ordering an STM32H743VIT6?',
        a: 'Buyers compare the 100-pin VIT6 with the 144-pin ZIT6 and 265-pin XIH6, since the pinouts differ. They also review TCM allocation and cache coherency for the 1 MB RAM, the PCB routing rules for high-speed peripherals and DDR or SDRAM expansion, the genuineness of the material, the temperature grade, and supply and price, because H7 lead times are long.',
      },
      {
        q: 'How does YIXINOU check an STM32H743VIT6 before it ships?',
        a: 'Each LQFP-100 lot of the STM32H743VIT6 is verified against the supplied ST datasheet before dispatch, covering device marking, date code, lead finish and pin condition. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'STM32WLE5CCU6': {
    mpn: 'STM32WLE5CCU6',
    brand: 'STMicroelectronics',
    title: '48 MHz Arm Cortex-M4 LPWAN wireless MCU with sub-GHz LoRa radio in UFQFPN-48',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The STM32WLE5CCU6 is an STMicroelectronics STM32WLE5xx multiprotocol LPWAN wireless microcontroller built on an Arm Cortex-M4 core at 48 MHz. It integrates 256 KB of Flash and 64 KB of SRAM with a sub-GHz radio covering 150 MHz to 960 MHz for LoRa, (G)FSK, (G)MSK and BPSK modulation, with transmit power up to +22 dBm. The part is supplied in a UFQFPN-48 package with 29 programmable I/Os and runs from a 1.8 V to 3.6 V supply over -40 \u00b0C to 85 \u00b0C. Interfaces include I2C, I2S, IrDA, LIN, SPI, UART and USART.',
    img: '/assets/images/stm32wle5ccu6-ufqfn-48.jpg',
    alt: 'A 48-lead UFQFPN package, the package used for the STM32WLE5CCU6',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'UFQFPN-48'],
      ['Number of pins', '48'],
      ['Core', 'Arm Cortex-M4'],
      ['Maximum CPU frequency', '48 MHz'],
      ['Program memory', '256 KB Flash'],
      ['SRAM', '64 KB'],
      ['Supply voltage', '1.8 V to 3.6 V'],
      ['Operating temperature', '-40 \u00b0C to 85 \u00b0C'],
      ['Radio', 'Sub-GHz transceiver, 150 to 960 MHz, LoRa, (G)FSK, (G)MSK and BPSK, up to +22 dBm'],
      ['Interfaces', 'I2C, I2S, IrDA, LIN, SPI, UART, USART'],
    ],
    about: 'The STM32WLE5CCU6 is a multiprotocol LPWAN wireless microcontroller from the STM32WLE5xx family, combining an Arm Cortex-M4 core at 48 MHz with 256 KB Flash and 64 KB SRAM in a UFQFPN-48 package. Its integrated sub-GHz radio tunes from 150 MHz to 960 MHz and supports LoRa, (G)FSK, (G)MSK and BPSK with transmit power up to +22 dBm, so no separate transceiver is needed. Peripherals include a 12-bit ADC, I2C, SPI, UART and USART across 29 programmable I/Os. It is used in smart water, electricity and gas metering, agriculture, environmental monitoring, asset tracking and industrial IoT nodes.',
    standards: [
      'STMicroelectronics datasheet DS13105 Rev 12 (STM32WLE5xx / STM32WLE4xx)',
      'RoHS compliant, ECOPACK2 lead-free package meeting RoHS and REACH',
      'ISO 7816-3 smart card interface compliant',
      'Radio subsystem aligned with LoRaWAN and ETSI EN 300 220 specifications',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Arm Cortex-M4 core at 48 MHz',
      '256 KB Flash and 64 KB SRAM',
      'Integrated sub-GHz radio covering 150 to 960 MHz',
      'LoRa, (G)FSK, (G)MSK and BPSK modulation',
      'Transmit power up to +22 dBm',
      '12-bit ADC with 12 channels',
      'I2C, I2S, SPI, UART and USART interfaces',
      '1.8 V to 3.6 V supply, -40 \u00b0C to 85 \u00b0C',
    ],
    applications: [
      'Smart metering (water, electricity, gas)',
      'Smart agriculture',
      'Environmental monitoring',
      'Asset tracking',
      'Industrial IoT nodes',
    ],
    faq: [
      {
        q: 'What is the STM32WLE5CCU6 used for?',
        a: 'It is used in smart water, electricity and gas meters, smart agriculture, environmental monitoring, asset tracking and industrial IoT nodes. Its integrated sub-GHz radio for LoRa, (G)FSK, (G)MSK and BPSK removes the need for an external transceiver, so a single UFQFPN-48 device can run the application and the long-range radio link.',
      },
      {
        q: 'What do buyers check before ordering an STM32WLE5CCU6?',
        a: 'Buyers confirm the radio band and the regional regulatory approvals such as CE, FCC and SRRC, since these depend on the destination market. They also review LoRaWAN stack licensing and gateway interoperability, the antenna design and matching network, which is demanding at these frequencies, the choice against vendor LoRa modules, genuineness and supply, and price and minimum order quantity.',
      },
      {
        q: 'How does YIXINOU check an STM32WLE5CCU6 before it ships?',
        a: 'UFQFPN-48 parts are checked against the supplied ST datasheet, with device marking, date code, lead finish and pin condition confirmed before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'STM8S003F3P6TR': {
    mpn: 'STM8S003F3P6TR',
    brand: 'STMicroelectronics',
    title: '16 MHz STM8S value-line 8-bit MCU with 8 KB Flash and 128 B data EEPROM in TSSOP-20',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The STM8S003F3P6TR is an STMicroelectronics STM8S value-line 8-bit microcontroller with an STM8 core running at 16 MHz. It provides 8 KB of Flash, 128 bytes of data EEPROM and 1 KB of SRAM in a TSSOP-20 package with 16 programmable I/Os. On-chip resources include a 10-bit ADC with five channels, three timers, UART, SPI, I2C and LIN interfaces. It operates from a 2.95 V to 5.5 V supply over -40 \u00b0C to 85 \u00b0C, and the TR suffix denotes tape-and-reel packing.',
    img: '/assets/images/stm8s003f3p6tr-tssop-20.jpg',
    alt: 'A 20-lead TSSOP package, the package used for the STM8S003F3P6TR',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'TSSOP-20'],
      ['Number of pins', '20'],
      ['Core', 'STM8 8-bit'],
      ['Maximum CPU frequency', '16 MHz'],
      ['Program memory', '8 KB Flash'],
      ['Data EEPROM', '128 B'],
      ['SRAM', '1 KB'],
      ['Supply voltage', '2.95 V to 5.5 V'],
      ['Operating temperature', '-40 \u00b0C to 85 \u00b0C'],
      ['Interfaces', 'I2C, IrDA, LIN, SPI, UART'],
    ],
    about: 'The STM8S003F3P6TR is a value-line 8-bit microcontroller from the STM8S003F3 family with an STM8 core at 16 MHz, 8 KB Flash, 128 bytes of data EEPROM and 1 KB SRAM in a TSSOP-20 package with 16 programmable I/Os. A 10-bit ADC with five channels, three timers, UART, SPI, I2C and LIN cover the usual small-control requirements, and the wide 2.95 V to 5.5 V supply suits operation from regulated rails in low-cost products. The TR suffix means tape-and-reel packing. It is used in small home appliances, power adapters, LED drivers, motor control, battery chargers and low-cost consumer control.',
    standards: [
      'STMicroelectronics datasheet DS7147 Rev 10 (STM8S003F3 / STM8S003K3)',
      'RoHS compliant, ECOPACK lead-free package meeting RoHS and REACH',
      'Reliability per JESD47',
      'ESD protection per JESD22-A114 (HBM) and JESD22-C101 (CDM)',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'STM8 8-bit core at 16 MHz',
      '8 KB Flash, 128 B data EEPROM and 1 KB SRAM',
      '10-bit ADC with five channels',
      'Three timers plus UART, SPI, I2C and LIN',
      '16 programmable I/Os in TSSOP-20',
      'Wide 2.95 V to 5.5 V supply range',
      'Tape-and-reel packing under the TR suffix',
      '-40 \u00b0C to 85 \u00b0C operating range',
    ],
    applications: [
      'Small home appliances',
      'Power adapters',
      'LED drivers',
      'Motor control',
      'Battery chargers',
      'Low-cost consumer control',
    ],
    faq: [
      {
        q: 'What is the STM8S003F3P6TR used for?',
        a: 'It is used in small home appliances, power adapters, LED drivers, motor control, battery chargers and other low-cost consumer control boards. The 16 MHz STM8 core, 8 KB Flash, 10-bit ADC, three timers and UART, SPI, I2C and LIN interfaces are enough for simple sensing, timing and serial communication tasks at a low unit cost.',
      },
      {
        q: 'What do buyers check before ordering an STM8S003F3P6TR?',
        a: 'This part has been widely replaced by pin-to-pin domestic equivalents, so buyers confirm that the original ST device is specified and supplied. They also distinguish the TR tape-and-reel packing from tube packing, check the real usable Flash margin, which is roughly 6 KB of the 8 KB, plan data storage because the EEPROM is only 128 bytes, and review price volatility, minimum order quantity and lead time.',
      },
      {
        q: 'How does YIXINOU check an STM8S003F3P6TR before it ships?',
        a: 'TSSOP-20 tape-and-reel lots are inspected against the supplied ST datasheet, with device marking, date code, lead finish and pin condition verified before packing. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'TMS320F28034PNT': {
    mpn: 'TMS320F28034PNT',
    brand: 'Texas Instruments',
    title: '60 MHz C2000 Piccolo 32-bit real-time MCU with 128 KB Flash in LQFP-80',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The TMS320F28034PNT is a Texas Instruments C2000 Piccolo 32-bit real-time microcontroller built on the TMS320C28x core at 60 MHz, giving a 16.67 ns instruction cycle. It provides 128 KB of Flash, 45 programmable I/Os and interfaces for CAN, I2C, LIN, SCI, SPI, UART and USART in an LQFP-80 package. Control peripherals include a 12-bit ADC, eCAP and eQEP modules, 16x16 and 32x32 MAC units and a CLA co-processor. It runs from a 1.71 V to 3.63 V supply on a single 3.3 V rail over -40 \u00b0C to 105 \u00b0C and is listed as production status.',
    img: '/assets/images/tms320f28034pnt-lqfp-80.jpg',
    alt: 'An 80-lead LQFP package, the package used for the TMS320F28034PNT',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'LQFP-80'],
      ['Number of pins', '80'],
      ['Core', 'TMS320C28x 32-bit'],
      ['Maximum CPU frequency', '60 MHz'],
      ['Program memory', '128 KB Flash'],
      ['Supply voltage', '1.71 V to 3.63 V, 3.3 V nominal'],
      ['Operating temperature', '-40 \u00b0C to 105 \u00b0C'],
      ['Interfaces', 'CAN, I2C, LIN, SCI, SPI, UART, USART'],
      ['Control peripherals', '2 x 12-bit ADC, eCAP, eQEP, CLA co-processor'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The TMS320F28034PNT is a C2000 Piccolo 32-bit real-time microcontroller from Texas Instruments with a TMS320C28x core at 60 MHz and a 16.67 ns instruction cycle, 128 KB Flash and 45 programmable I/Os in an LQFP-80 package. It is aimed at closed-loop control, pairing 16x16 and 32x32 MAC units and a CLA co-processor with two 12-bit ADCs, eCAP and eQEP modules, plus CAN, I2C, LIN, SCI, SPI, UART and USART interfaces. It runs from a single 3.3 V supply. It is used in digital power, FOC motor drive, solar inverters, industrial inverters, charging piles and appliance variable-frequency control.',
    standards: [
      'Texas Instruments datasheet TMS320F2803x Real-Time Microcontrollers',
      'RoHS compliant and REACH compliant, lead-free green package',
      'CAN interface compliant with ISO 11898',
      'Package and ESD standards per JEDEC JESD22 series, thermal characteristics per JESD51',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'TMS320C28x core at 60 MHz, 16.67 ns cycle',
      '128 KB Flash with 45 programmable I/Os',
      '16x16 and 32x32 MAC units',
      'CLA co-processor for parallel control tasks',
      '12-bit ADC with 16 channels',
      'eCAP and eQEP modules for motion control',
      'CAN, I2C, LIN, SCI, SPI, UART and USART',
      'Single 3.3 V supply, -40 \u00b0C to 105 \u00b0C',
    ],
    applications: [
      'Digital power',
      'Motor drive (FOC)',
      'Solar inverters',
      'Industrial inverters',
      'EV charging piles',
      'Appliance variable-frequency control',
    ],
    faq: [
      {
        q: 'What is the TMS320F28034PNT used for?',
        a: 'It is used in digital power conversion, field-oriented motor drive, solar inverters, industrial inverters, EV charging piles and appliance variable-frequency control. The C28x core at 60 MHz with 16x16 and 32x32 MAC units, a CLA co-processor, 12-bit ADC, eCAP and eQEP modules is designed for fast current and position control loops rather than general-purpose computing.',
      },
      {
        q: 'What do buyers check before ordering a TMS320F28034PNT?',
        a: 'Because C2000 devices are dedicated to real-time control rather than being general-purpose MCUs, buyers assess the development cost of adopting the platform. They also check ePWM and ADC accuracy and dead-band configuration, compare the part with the F28035 and F28027 options, confirm access to the TI development environment and libraries, verify genuineness, and review lead time and price, since TI lead times fluctuate.',
      },
      {
        q: 'How does YIXINOU check a TMS320F28034PNT before it ships?',
        a: 'LQFP-80 devices are checked against the supplied TI datasheet before dispatch, covering device marking, date code, lead finish and pin condition. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'TMS320F2812PGFQ': {
    mpn: 'TMS320F2812PGFQ',
    brand: 'Texas Instruments',
    title: '150 MHz C2000 32-bit DSP with 256 KB Flash and EMIF in LQFP-176',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The TMS320F2812PGFQ is a Texas Instruments C2000 32-bit digital signal processor with a TMS320C28x core at 150 MHz, a 6.67 ns instruction cycle, 256 KB of Flash and 36 KB of RAM in an LQFP-176 package. Interfaces include CAN, EBI/EMI, SCI, SPI, UART and USART, with an EMIF external memory interface and a 12-bit ADC. The core runs at 1.81 V to 1.89 V with a 3.3 V I/O rail, over -40 \u00b0C to 125 \u00b0C. It is listed as production status and the Q suffix version carries AEC-Q100 automotive qualification.',
    img: '/assets/images/tms320f2812pgfq-lqfp-176.jpg',
    alt: 'A 176-lead LQFP package, the package used for the TMS320F2812PGFQ',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'LQFP-176'],
      ['Number of pins', '176'],
      ['Core', 'TMS320C28x 32-bit'],
      ['Maximum CPU frequency', '150 MHz'],
      ['Program memory', '256 KB Flash'],
      ['RAM', '36 KB'],
      ['Core supply voltage', '1.81 V to 1.89 V with 3.3 V I/O'],
      ['Operating temperature', '-40 \u00b0C to 125 \u00b0C'],
      ['Interfaces', 'CAN, EBI/EMI, SCI, SPI, UART, USART'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The TMS320F2812PGFQ is a C2000 32-bit digital signal processor from Texas Instruments with a TMS320C28x core at 150 MHz and a 6.67 ns instruction cycle, offering 256 KB Flash, 36 KB RAM and 56 programmable I/Os in an LQFP-176 package. An EMIF external memory interface, a 12-bit ADC, eCAN, McBSP, SCI and SPI cover motor and power conversion designs, with the core at 1.8 V for 135 MHz operation or 1.9 V for 150 MHz and a 3.3 V I/O rail. It is used in motor drive and servo control, industrial inverters, UPS systems, power electronics, and wind and photovoltaic inverters.',
    standards: [
      'Texas Instruments datasheet TMS320F281x Digital Signal Processors (tms320f2812-q1)',
      'RoHS compliant and REACH compliant, lead-free green package',
      'AEC-Q100 automotive qualification for the Q suffix version',
      'CAN interface compliant with ISO 11898',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'TMS320C28x core at 150 MHz, 6.67 ns cycle',
      '256 KB Flash and 36 KB RAM',
      'EMIF external memory interface',
      '12-bit ADC',
      'eCAN, McBSP, SCI and SPI interfaces',
      'Core at 1.8 V or 1.9 V with 3.3 V I/O',
      '56 programmable I/Os in LQFP-176',
      'Q suffix version AEC-Q100 automotive qualified',
    ],
    applications: [
      'Motor drive and servo control',
      'Industrial inverters',
      'UPS systems',
      'Power electronics',
      'Wind and photovoltaic inverters',
    ],
    faq: [
      {
        q: 'What is the TMS320F2812PGFQ used for?',
        a: 'It is used in motor drive and servo control, industrial inverters, UPS systems, power electronics and wind or photovoltaic inverters. The 150 MHz C28x core, EMIF external memory interface, 12-bit ADC and eCAN, McBSP, SCI and SPI peripherals make it a controller for power conversion and motion applications that were designed around the classic C2000 architecture.',
      },
      {
        q: 'What do buyers check before ordering a TMS320F2812PGFQ?',
        a: 'This is a classic older device, so buyers watch the TI lifecycle status and possible migration to the TMS320F28335 or F2837x families. They also confirm that PGFQ means the LQFP-176 package and is not pin compatible with the BGA version, review event manager configuration and dead band settings, verify genuineness because this part is widely refurbished, and check price and the year of inventory, plus the development environment and code porting effort.',
      },
      {
        q: 'How does YIXINOU check a TMS320F2812PGFQ before it ships?',
        a: 'For LQFP-176 shipments of the TMS320F2812PGFQ we confirm device marking, date code, lead finish and pin coplanarity against the supplied TI datasheet before packing. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'TMS320F28335PGFA': {
    mpn: 'TMS320F28335PGFA',
    brand: 'Texas Instruments',
    title: '150 MHz C2000 32-bit DSP with FPU, 512 KB Flash and EMIF in LQFP-176',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The TMS320F28335PGFA is a Texas Instruments C2000 32-bit digital signal processor with a TMS320C28x core at 150 MHz and a 6.67 ns instruction cycle, plus a single-precision FPU. It offers 512 KB of Flash and 88 programmable I/Os in an LQFP-176 package. On-chip functions include an EMIF external memory interface, a 12-bit ADC with 16 channels, eCAN, McBSP, SCI and SPI. The core runs at 1.805 V to 1.995 V with a 3.3 V I/O rail over -40 \u00b0C to 85 \u00b0C and it is listed as production status.',
    img: '/assets/images/tms320f28335pgfa-lqfp-176.jpg',
    alt: 'A 176-lead LQFP package, the package used for the TMS320F28335PGFA',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'LQFP-176'],
      ['Number of pins', '176'],
      ['Core', 'TMS320C28x 32-bit with single-precision FPU'],
      ['Maximum CPU frequency', '150 MHz'],
      ['Program memory', '512 KB Flash'],
      ['Core supply voltage', '1.805 V to 1.995 V with 3.3 V I/O'],
      ['Operating temperature', '-40 \u00b0C to 85 \u00b0C'],
      ['Interfaces', 'CAN, EBI/EMI, I2C, SCI, SPI, UART, USART'],
      ['Control peripherals', '16-channel 12-bit ADC, EMIF, eCAN, McBSP'],
      ['Lifecycle status', 'Production'],
    ],
    about: 'The TMS320F28335PGFA is a C2000 32-bit digital signal processor from Texas Instruments with a TMS320C28x core at 150 MHz and a 6.67 ns instruction cycle, 512 KB Flash and 88 programmable I/Os in an LQFP-176 package. Its single-precision FPU is the main advance over the earlier F2812, and an EMIF interface, a 16-channel 12-bit ADC, eCAN, McBSP, SCI and SPI support power conversion and motion designs. The core runs at 1.9 V or 1.8 V with 3.3 V I/O. It is used in industrial inverters, servo drives, solar and wind inverters, EV motor control, and power electronics and digital power.',
    standards: [
      'Texas Instruments datasheet TMS320F2833x / TMS320F2823x Real-Time Microcontrollers (tms320f28232)',
      'RoHS compliant and REACH compliant, lead-free green package',
      'AEC-Q100 automotive grade versions plus applicable IEC 60730 and IEC 60335 appliance safety clauses',
      'CAN interface compliant with ISO 11898',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'TMS320C28x core at 150 MHz, 6.67 ns cycle',
      'Single-precision FPU floating-point unit',
      '512 KB Flash and 88 programmable I/Os',
      'EMIF external memory interface',
      '12-bit ADC with 16 channels',
      'eCAN, McBSP, SCI, SPI and I2C interfaces',
      'Core at 1.9 V or 1.8 V with 3.3 V I/O',
      'Industrial inverters, servo drive and digital power applications',
    ],
    applications: [
      'Industrial inverters',
      'Servo drives',
      'Solar and wind inverters',
      'EV motor control',
      'Power electronics and digital power',
    ],
    faq: [
      {
        q: 'What is the TMS320F28335PGFA used for?',
        a: 'It is used in industrial inverters, servo drives, solar and wind inverters, EV motor control, and power electronics and digital power systems. The single-precision FPU, 150 MHz C28x core, 512 KB Flash, 12-bit ADC and EMIF external memory interface support control loops that benefit from floating-point arithmetic and external memory expansion.',
      },
      {
        q: 'What do buyers check before ordering a TMS320F28335PGFA?',
        a: 'The floating-point capability is the key upgrade over the F2812, so buyers confirm the free-running performance the application needs. They also choose between the PGFA LQFP-176 and the ZJZA BGA-176 package, check how ePWM and the ADC work with the IQmath and DMC motor control libraries, verify genuineness because refurbished material is common in the market, review lead time and price, and look for a long-term supply commitment.',
      },
      {
        q: 'How does YIXINOU check a TMS320F28335PGFA before it ships?',
        a: 'Each LQFP-176 lot of the TMS320F28335PGFA is examined against the supplied TI datasheet before dispatch, covering marking, date code, lead finish and pin condition. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'TMS320F28335ZJZA': {
    mpn: 'TMS320F28335ZJZA',
    brand: 'Texas Instruments',
    title: '32-bit C2000 digital signal processor, 150 MHz, 512 kB Flash, BGA-176',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'Texas Instruments TMS320F28335ZJZA is a 32-bit C2000 digital signal processor built on the C28x core and running at 150 MHz. It integrates 512 kB of Flash, a single-precision FPU, an external memory interface and a 12-bit ADC. The ZJZ device is supplied in a 176-ball BGA package and is specified for -40 \u00b0C to 125 \u00b0C (Q grade). Core supply is 1.805 V to 1.995 V with 3.3 V I/O, and interfaces include CAN, EBI/EMI, I2C, SCI, SPI and UART/USART. It is a production-status part aimed at real-time control in industrial drives, photovoltaic inverters and electric-vehicle controllers.',
    img: '/assets/images/tms320f28335zjza-bga-176.jpg',
    alt: 'A 176-ball BGA package, the package used for the TMS320F28335ZJZA',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'BGA-176 (ZJZ)'],
      ['Number of pins', '176'],
      ['Core', 'C2000 C28x 32-bit'],
      ['Maximum frequency', '150 MHz'],
      ['Flash memory', '512 kB'],
      ['Core supply voltage', '1.805 V to 1.995 V'],
      ['I/O voltage', '3.3 V'],
      ['Interfaces', 'CAN, EBI/EMI, I2C, SCI, SPI, UART, USART'],
      ['Operating temperature', '-40 \u00b0C to 125 \u00b0C'],
      ['RoHS compliance', 'Compliant'],
    ],
    about: 'The TMS320F28335ZJZA is a 150 MHz 32-bit C2000 digital signal processor from Texas Instruments with a C28x core, 512 kB of embedded Flash, a single-precision FPU, an external memory interface and a 12-bit ADC, plus eCAN. It runs from a 1.805 V to 1.995 V core supply with 3.3 V I/O. The ZJZ suffix denotes the 176-ball BGA package, the same silicon as the LQFP-176 PGF option but not footprint compatible. Typical uses are industrial variable-frequency and servo drives, photovoltaic inverters, electric-vehicle motor control, industrial power supplies and power-electronics control.',
    standards: [
      'Texas Instruments datasheet TMS320F2833x / TMS320F2823x Real-Time Microcontrollers (tms320f28232)',
      'RoHS compliant',
      'REACH compliant',
      'JEDEC package and ESD standards (JESD22 series)',
      'Package thermal characteristics per JESD51',
      'PCB land pattern design per IPC-7351 and IPC-7525',
      'CAN interface per ISO 11898',
      'AEC-Q100 automotive-grade version available',
      'IEC 60730 / IEC 60335 appliance safety standards apply',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'C2000 C28x 32-bit core at 150 MHz',
      '512 kB of embedded Flash',
      'Single-precision floating-point unit (FPU)',
      'External memory interface (EMIF)',
      '12-bit ADC and eCAN',
      'CAN, EBI/EMI, I2C, SCI, SPI and UART/USART interfaces',
      '176-ball BGA (ZJZ) package, Q grade',
      'Operating temperature -40 \u00b0C to 125 \u00b0C',
    ],
    applications: [
      'Industrial variable-frequency and servo drives',
      'Photovoltaic inverters',
      'Electric-vehicle motor control',
      'Industrial power supplies',
      'Power electronics control',
    ],
    faq: [
      {
        q: 'What is the TMS320F28335ZJZA used for?',
        a: 'It is a real-time control processor used in industrial variable-frequency and servo drives, photovoltaic inverters, electric-vehicle motor control, industrial power supplies and other power-electronics control designs.',
      },
      {
        q: 'What do buyers check before ordering a TMS320F28335ZJZA?',
        a: 'Buyers first confirm that the BGA-176 ZJZ footprint matches their board, because it is not pin compatible with the LQFP-176 PGF version, and that the assembly house has X-ray inspection and reflow capability for BGA. They also review thermal pad and via design, consistent sourcing of genuine-manufacturer parts, lead time and price, and long-term supply.',
      },
      {
        q: 'How does YIXINOU check a TMS320F28335ZJZA before it ships?',
        a: 'The BGA-176 devices are inspected for package and marking integrity, and the incoming record is matched to the supplier trace. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Lot photographs and the inspection record are available on request.',
      },
    ],
  },
  'TMS320F28377DPTPT': {
    mpn: 'TMS320F28377DPTPT',
    brand: 'Texas Instruments',
    title: 'Dual-core C2000 Delfino 32-bit real-time MCU, 200 MHz, 1 MB Flash, HLQFP-176',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The TMS320F28377DPTPT is a dual-core C2000 Delfino 32-bit real-time microcontroller from Texas Instruments running at 200 MHz per C28x core. It carries 1 MB of Flash, a control law accelerator, 16-bit and 12-bit ADCs, DAC, eQEP, EMIF and USB. The PTP device comes in a 176-pin HLQFP exposed-pad package supplied in trays. Operating supply range is 1.14 V to 3.47 V with interfaces including CAN, I2C, SPI, UART and USB, and the operating temperature range is -40 \u00b0C to 105 \u00b0C. It targets high-end servo drives, multi-axis motor control, photovoltaic and energy-storage converters, electric-vehicle control and industrial power supplies.',
    img: '/assets/images/tms320f28377dptpt-hlqfp-176.jpg',
    alt: 'A 176-pin HLQFP exposed-pad package, the package used for the TMS320F28377DPTPT',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'HLQFP-176 (PTP)'],
      ['Number of pins', '176'],
      ['Core', 'Dual-core C2000 C28x 32-bit'],
      ['Maximum frequency', '200 MHz per core'],
      ['Flash memory', '1 MB'],
      ['Supply voltage', '1.14 V to 3.47 V'],
      ['Interfaces', 'CAN, I2C, SPI, UART, USB'],
      ['On-chip converters', '16-bit and 12-bit ADC, DAC'],
      ['Operating temperature', '-40 \u00b0C to 105 \u00b0C'],
      ['RoHS compliance', 'Compliant'],
    ],
    about: 'The TMS320F28377DPTPT is a dual-core 32-bit C2000 Delfino real-time microcontroller from Texas Instruments. Each C28x core runs at up to 200 MHz and the device integrates 1 MB of Flash, a CLA co-processor, 16-bit and 12-bit ADCs, DAC, eQEP, EMIF and USB, all in a 176-pin HLQFP exposed-pad package supplied in trays. It operates from 1.14 V to 3.47 V over -40 \u00b0C to 105 \u00b0C. It is intended for high-end servo drives, multi-axis motor control, photovoltaic and energy-storage power conversion systems, electric-vehicle motor control and industrial power supplies.',
    standards: [
      'Texas Instruments datasheet TMS320F2837xD Dual-Core Real-Time Microcontrollers (tms320f28377d)',
      'RoHS compliant',
      'REACH compliant',
      'JEDEC package and ESD standards (JESD22 series)',
      'Package thermal characteristics per JESD51',
      'PCB land pattern design per IPC-7351 and IPC-7525',
      'CAN interface per ISO 11898',
      'Functional safety aligned with IEC 61508 (SIL) and ISO 26262 (ASIL); IEC 60730 appliance safety standards apply',
      'Lead-free (green) package',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Dual-core C28x 32-bit cores at 200 MHz each',
      '1 MB of on-chip Flash memory',
      'Control law accelerator (CLA) co-processor',
      '16-bit and 12-bit ADCs plus DAC outputs',
      'eQEP, EMIF and USB interfaces',
      'CAN, I2C, SPI and UART connectivity',
      '176-pin HLQFP exposed-pad package, tray supplied',
      'Production lifecycle status',
    ],
    applications: [
      'High-end servo drives',
      'Multi-axis motor control',
      'Photovoltaic and energy-storage power conversion systems (PCS)',
      'Electric-vehicle motor control',
      'Industrial power supplies',
    ],
    faq: [
      {
        q: 'What is the TMS320F28377DPTPT used for?',
        a: 'It is used for high-end servo drives, multi-axis motor control, photovoltaic and energy-storage power conversion systems, electric-vehicle motor control and industrial power supplies where a dual-core real-time controller is required.',
      },
      {
        q: 'What do buyers check before ordering a TMS320F28377DPTPT?',
        a: 'Buyers weigh the software partitioning and inter-core communication effort that a dual-core architecture demands, and the step up that 1 MB Flash and 204 kB RAM represent over a single-core device. They also decide how the high-precision ADC and the CLB programmable logic will be used, confirm the CCS tool and library versions, and verify genuine-manufacturer sourcing, price and lead time, which is long for this part.',
      },
      {
        q: 'How does YIXINOU check a TMS320F28377DPTPT before it ships?',
        a: 'Each HLQFP-176 lot is checked for package condition, pin coplanarity and marking before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. The inspection record for the lot is available on request.',
      },
    ],
  },
  'XC6SLX9-3CPG196I': {
    mpn: 'XC6SLX9-3CPG196I',
    brand: 'AMD',
    title: 'Spartan-6 LX9 FPGA, 9,152 logic cells, speed grade -3, CSBGA-196, industrial',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Field Programmable Gate Arrays (FPGAs)',
    categoryHref: '/all-products',
    summary: 'The XC6SLX9-3CPG196I is an AMD Spartan-6 LX9 field programmable gate array with 9,152 logic cells (1,430 slices) in speed grade -3. It provides 106 user I/O, 16 DSP48A1 slices, 576 kbit of block RAM, a hardened memory controller and a 1.2 V core supply. The CPG196 option is a 196-ball CSBGA package rated for the industrial junction range of -40 \u00b0C to 100 \u00b0C. It remains in demand for maintaining existing industrial control, interface bridging, display driving and communication designs.',
    img: '/assets/images/xc6slx9-3cpg196i-tfbga-196.jpg',
    alt: 'A 196-ball CSBGA package, the package used for the XC6SLX9-3CPG196I',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'CSBGA-196 (CPG196)'],
      ['Number of balls', '196'],
      ['Logic cells', '9,152 (1,430 slices)'],
      ['Speed grade', '-3'],
      ['Core supply voltage', '1.2 V'],
      ['Embedded block RAM', '576 kbit'],
      ['DSP slices', '16 DSP48A1'],
      ['User I/O', '106'],
      ['Operating temperature', '-40 \u00b0C to 100 \u00b0C (junction)'],
      ['RoHS compliance', 'Compliant'],
    ],
    about: 'The XC6SLX9-3CPG196I is an AMD Spartan-6 LX9 FPGA delivered in a 196-ball CSBGA package. It offers 9,152 logic cells (1,430 slices), 106 user I/O, 16 DSP48A1 slices and 576 kbit of block RAM, with a hardened memory controller and a 1.2 V core supply, while a 1.0 V low-power option also exists in the family. The part is speed grade -3 and rated for the industrial junction temperature range of -40 \u00b0C to 100 \u00b0C. It is commonly used for industrial control, interface bridging, display driving and communication equipment, and for maintaining legacy or volume production designs.',
    standards: [
      'AMD/Xilinx DS162 Spartan-6 FPGA Data Sheet, v3.1.1',
      'RoHS compliant',
      'Pb-free (lead-free) package',
      'JEDEC package standards',
      'ESD protection to the JESD22 series',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Spartan-6 LX9 with 9,152 logic cells (1,430 slices)',
      'Speed grade -3',
      '196-ball CSBGA (CPG196) package',
      '106 user I/O and 16 DSP48A1 slices',
      '576 kbit of block RAM',
      'Hardened memory controller',
      '1.2 V core supply, with a 1.0 V low-power option in the family',
      'Industrial grade, -40 \u00b0C to 100 \u00b0C junction',
    ],
    applications: [
      'Industrial control',
      'Interface bridging',
      'Display driving',
      'Communication equipment',
      'Legacy project and volume production maintenance',
    ],
    faq: [
      {
        q: 'What is the XC6SLX9-3CPG196I used for?',
        a: 'It is used for industrial control, interface bridging, display driving and communication equipment, and for maintaining legacy designs and volume production boards that already use the Spartan-6 LX9.',
      },
      {
        q: 'What do buyers check before ordering an XC6SLX9-3CPG196I?',
        a: 'Buyers confirm that a new design is acceptable, because Spartan-6 is at end of life and is not recommended for new projects, and they verify that this CSBGA-196 version is not a direct replacement for the TQG144 package. They also plan for the external SPI Flash the family requires, confirm the industrial temperature rating, and check genuine-manufacturer sourcing, since refurbished and reclaimed older FPGAs are a known risk, together with price and stock origin.',
      },
      {
        q: 'How does YIXINOU check an XC6SLX9-3CPG196I before it ships?',
        a: 'Incoming CSBGA-196 parts are screened for ball condition, package integrity and marking. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'XC6SLX9-3TQG144I': {
    mpn: 'XC6SLX9-3TQG144I',
    brand: 'AMD',
    title: 'Spartan-6 LX9 FPGA, 9,152 logic cells, speed grade -3, TQFP-144, industrial',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Field Programmable Gate Arrays (FPGAs)',
    categoryHref: '/all-products',
    summary: 'The XC6SLX9-3TQG144I is an AMD Spartan-6 LX9 FPGA with 9,152 logic cells (1,430 slices) in speed grade -3. It provides 102 user I/O, 16 DSP48A1 multiply-accumulate slices, 576 kbit of block RAM, a hardened memory controller, two clock management units and a 1.2 V core supply. The TQG144 option is a 144-pin TQFP package rated for the industrial junction range of -40 \u00b0C to 100 \u00b0C. Typical uses include industrial control, interface conversion and bridging, display driving, communication glue logic, and teaching or legacy maintenance work.',
    img: '/assets/images/xc6slx9-3tqg144i-lqfp-144.jpg',
    alt: 'A 144-pin TQFP package, the package used for the XC6SLX9-3TQG144I',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'TQFP-144 (TQG144)'],
      ['Number of pins', '144'],
      ['Logic cells', '9,152 (1,430 slices)'],
      ['Speed grade', '-3'],
      ['Core supply voltage', '1.2 V'],
      ['Embedded block RAM', '576 kbit'],
      ['DSP slices', '16 DSP48A1'],
      ['User I/O', '102'],
      ['Operating temperature', '-40 \u00b0C to 100 \u00b0C (junction)'],
      ['RoHS compliance', 'Compliant'],
    ],
    about: 'The XC6SLX9-3TQG144I is an AMD Spartan-6 LX9 FPGA in a 144-pin TQFP package, the low-cost, easy-to-inspect option within the family. It contains 9,152 logic cells (1,430 slices), 102 user I/O, 16 DSP48A1 slices, 576 kbit of block RAM, a hardened memory controller and two clock management units, and it runs from a 1.2 V core supply. It is speed grade -3 with an industrial junction temperature range of -40 \u00b0C to 100 \u00b0C. It suits industrial control, interface conversion and bridging, display driving, communication glue logic, and teaching and legacy project maintenance.',
    standards: [
      'AMD/Xilinx DS162 Spartan-6 FPGA Data Sheet, v3.1.1',
      'RoHS compliant',
      'Pb-free (lead-free) package',
      'JEDEC package standards',
      'ESD protection to the JESD22 series',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Spartan-6 LX9 with 9,152 logic cells (1,430 slices)',
      'Speed grade -3',
      '144-pin TQFP (TQG144) package',
      '102 user I/O and 16 DSP48A1 slices',
      '576 kbit of block RAM',
      'Hardened memory controller',
      'Two clock management units',
      'Industrial grade, -40 \u00b0C to 100 \u00b0C junction',
    ],
    applications: [
      'Industrial control',
      'Interface conversion and bridging',
      'Display driving',
      'Communication glue logic',
      'Teaching and legacy project maintenance',
    ],
    faq: [
      {
        q: 'What is the XC6SLX9-3TQG144I used for?',
        a: 'It is used for industrial control, interface conversion and bridging, display driving and communication glue logic, and it is also common in teaching and in maintenance of existing designs.',
      },
      {
        q: 'What do buyers check before ordering an XC6SLX9-3TQG144I?',
        a: 'Buyers assess long-term supply because Spartan-6 has entered end of life, and they evaluate replacements such as Spartan-7 or Artix-7. They also plan for the external SPI Flash configuration device, note the package difference between TQFP-144 and CPG196, confirm the industrial temperature rating, and check genuine-manufacturer sourcing, since refurbished older FPGAs are common, together with price and stock age.',
      },
      {
        q: 'How does YIXINOU check an XC6SLX9-3TQG144I before it ships?',
        a: 'The TQFP-144 devices are examined for lead finish, coplanarity and marking when they arrive. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'XC7A100T-2CSG324I': {
    mpn: 'XC7A100T-2CSG324I',
    brand: 'AMD',
    title: 'Artix-7 XC7A100T FPGA, 101,440 logic cells, CSBGA-324, industrial',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Field Programmable Gate Arrays (FPGAs)',
    categoryHref: '/all-products',
    summary: 'The XC7A100T-2CSG324I is an AMD Artix-7 FPGA with 101,440 logic cells (15,850 slices) in speed grade -2. It offers 210 user I/O, 240 DSP48E1 slices, 4,860 kbit of block RAM, an XADC and a PCIe Gen2 hard block, running from a core supply of 0.95 V to 1.05 V. The CSG324 option is a 324-ball CSBGA package rated for the industrial junction range of -40 \u00b0C to 100 \u00b0C. It is aimed at industrial vision and image processing, communication baseband, medical imaging, test and measurement, and video codec designs.',
    img: '/assets/images/xc7a100t-2csg324i-bga-324.jpg',
    alt: 'A 324-ball CSBGA package, the package used for the XC7A100T-2CSG324I',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'CSBGA-324 (CSG324)'],
      ['Number of balls', '324'],
      ['Logic cells', '101,440 (15,850 slices)'],
      ['Speed grade', '-2'],
      ['Core supply voltage', '950 mV to 1.05 V'],
      ['Embedded block RAM', '4,860 kbit'],
      ['DSP slices', '240 DSP48E1'],
      ['User I/O', '210'],
      ['Operating temperature', '-40 \u00b0C to 100 \u00b0C (junction)'],
      ['RoHS compliance', 'Compliant'],
    ],
    about: 'The XC7A100T-2CSG324I is an AMD Artix-7 FPGA with 101,440 logic cells (15,850 slices), 210 user I/O, 240 DSP48E1 slices and 4,860 kbit of block RAM, plus an XADC and a PCIe Gen2 hard block. It is speed grade -2 and runs from a 0.95 V to 1.05 V core supply over an industrial junction temperature range of -40 \u00b0C to 100 \u00b0C. The CSG324 device is a 324-ball CSBGA package. Typical applications are industrial vision and image processing, communication baseband, medical imaging, test and measurement, and video encoding and decoding.',
    standards: [
      'AMD/Xilinx DS181 Artix-7 FPGA Data Sheet, v1.27.1',
      'RoHS compliant',
      'Pb-free (lead-free) package',
      'JEDEC package standards',
      'Aligned with the ISO 26262 functional safety standard framework',
      'ESD protection to the JESD22 series',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Artix-7 100T with 101,440 logic cells (15,850 slices)',
      'Speed grade -2',
      '324-ball CSBGA (CSG324) package',
      '210 user I/O and 240 DSP48E1 slices',
      '4,860 kbit of block RAM',
      'Integrated XADC',
      'PCIe Gen2 hard block',
      'Industrial grade, -40 \u00b0C to 100 \u00b0C junction',
    ],
    applications: [
      'Industrial vision and image processing',
      'Communication baseband',
      'Medical imaging',
      'Test and measurement',
      'Video encoding and decoding',
    ],
    faq: [
      {
        q: 'What is the XC7A100T-2CSG324I used for?',
        a: 'It is used for industrial vision and image processing, communication baseband, medical imaging, test and measurement, and video encoding and decoding.',
      },
      {
        q: 'What do buyers check before ordering an XC7A100T-2CSG324I?',
        a: 'Buyers check whether the I/O count and transceiver availability of the 324-ball CSG324 package meet the interface requirements, since the transceiver count is limited in this package, and they compare it with the FGG484 and FGG676 versions, which are different footprints. They also plan the configuration Flash and power design, confirm Vivado licensing, and review lead time, price and how genuine-manufacturer parts will be verified.',
      },
      {
        q: 'How does YIXINOU check an XC7A100T-2CSG324I before it ships?',
        a: 'Every CSBGA-324 shipment is checked against the incoming documentation and inspected for ball and marking quality. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'XC7A35T-2CSG325I': {
    mpn: 'XC7A35T-2CSG325I',
    brand: 'AMD',
    title: 'Artix-7 XC7A35T FPGA, 33,280 logic cells, CSBGA-325, industrial',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Field Programmable Gate Arrays (FPGAs)',
    categoryHref: '/all-products',
    summary: 'The XC7A35T-2CSG325I is an AMD Artix-7 FPGA with 33,280 logic cells (5,200 slices) in speed grade -2. It provides 150 user I/O, 90 DSP48E1 slices, 1,800 kbit of block RAM and an XADC, operating from a 0.95 V to 1.05 V core supply. The CSG325 option is a 325-ball CSBGA package rated for the industrial junction range of -40 \u00b0C to 100 \u00b0C. It is used in industrial control, embedded vision, communication equipment, and data acquisition and interface bridging.',
    img: '/assets/images/xc7a35t-2csg325i-bga-325.jpg',
    alt: 'A 325-ball CSBGA package, the package used for the XC7A35T-2CSG325I',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'CSBGA-325 (CSG325)'],
      ['Number of balls', '325'],
      ['Logic cells', '33,280 (5,200 slices)'],
      ['Speed grade', '-2'],
      ['Core supply voltage', '950 mV to 1.05 V'],
      ['Embedded block RAM', '1,800 kbit'],
      ['DSP slices', '90 DSP48E1'],
      ['User I/O', '150'],
      ['Operating temperature', '-40 \u00b0C to 100 \u00b0C (junction)'],
      ['RoHS compliance', 'Compliant'],
    ],
    about: 'The XC7A35T-2CSG325I is an AMD Artix-7 FPGA with 33,280 logic cells (5,200 slices), 150 user I/O, 90 DSP48E1 slices, 1,800 kbit of block RAM and an integrated XADC. It is speed grade -2 and runs from a 0.95 V to 1.05 V core supply over an industrial junction temperature range of -40 \u00b0C to 100 \u00b0C. The CSG325 device is a 325-ball CSBGA package, the same die as the FGG484 option but not pin compatible with it. Applications include industrial control, embedded vision, communication equipment, and data acquisition and interface bridging.',
    standards: [
      'AMD/Xilinx DS181 Artix-7 FPGA Data Sheet, v1.27.1',
      'RoHS compliant',
      'Pb-free (lead-free) package',
      'JEDEC package standards',
      'Aligned with the ISO 26262 functional safety standard framework',
      'ESD protection to the JESD22 series',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Artix-7 35T with 33,280 logic cells (5,200 slices)',
      'Speed grade -2',
      '325-ball CSBGA (CSG325) package',
      '150 user I/O and 90 DSP48E1 slices',
      '1,800 kbit of block RAM',
      'Integrated XADC',
      'Industrial grade, -40 \u00b0C to 100 \u00b0C junction',
    ],
    applications: [
      'Industrial control',
      'Embedded vision',
      'Communication equipment',
      'Data acquisition and interface bridging',
    ],
    faq: [
      {
        q: 'What is the XC7A35T-2CSG325I used for?',
        a: 'It is used for industrial control, embedded vision, communication equipment, and data acquisition and interface bridging.',
      },
      {
        q: 'What do buyers check before ordering an XC7A35T-2CSG325I?',
        a: 'Buyers confirm the PCB design first, because the CSG325 and FGG484 versions are not pin compatible, and they take care not to confuse the CPG236, CSG324 and CSG325 packages in the same family. They also plan the configuration Flash and power rails, confirm Vivado licensing, and review lead time, price and genuine-manufacturer verification.',
      },
      {
        q: 'How does YIXINOU check an XC7A35T-2CSG325I before it ships?',
        a: 'The CSBGA-325 parts are received with a package and marking check, and the lot record is matched to the supplier trace. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'XC7A35T-2FGG484I': {
    mpn: 'XC7A35T-2FGG484I',
    brand: 'AMD',
    title: 'Artix-7 XC7A35T FPGA, 33,280 logic cells, FBGA-484, industrial',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Field Programmable Gate Arrays (FPGAs)',
    categoryHref: '/all-products',
    summary: 'The XC7A35T-2FGG484I is an AMD Artix-7 FPGA with 33,280 logic cells (5,200 slices) in speed grade -2. It offers 250 user I/O, 90 DSP48E1 slices, 1,800 kbit of block RAM, an XADC and clock management units, running from a 0.95 V to 1.05 V core supply. The FGG484 option is a 484-ball FBGA package rated for the industrial junction range of -40 \u00b0C to 100 \u00b0C. It is used in industrial vision, video and image processing, communication equipment, medical instruments, and data acquisition and protocol conversion.',
    img: '/assets/images/xc7a35t-2fgg484i-fbga-484.jpg',
    alt: 'A 484-ball FBGA package, the package used for the XC7A35T-2FGG484I',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'FBGA-484 (FGG484)'],
      ['Number of balls', '484'],
      ['Logic cells', '33,280 (5,200 slices)'],
      ['Speed grade', '-2'],
      ['Core supply voltage', '950 mV to 1.05 V'],
      ['Embedded block RAM', '1,800 kbit'],
      ['DSP slices', '90 DSP48E1'],
      ['User I/O', '250'],
      ['Operating temperature', '-40 \u00b0C to 100 \u00b0C (junction)'],
      ['RoHS compliance', 'Compliant'],
    ],
    about: 'The XC7A35T-2FGG484I is an AMD Artix-7 FPGA in a 484-ball FBGA package, the higher-pin-count version of the 35T device with 250 user I/O instead of 150. It carries 33,280 logic cells (5,200 slices), 90 DSP48E1 slices, 1,800 kbit of block RAM, an XADC and clock management units. It is speed grade -2 and runs from a 0.95 V to 1.05 V core supply over an industrial junction temperature range of -40 \u00b0C to 100 \u00b0C. It suits industrial vision, video and image processing, communication equipment, medical instruments, and data acquisition and protocol conversion.',
    standards: [
      'AMD/Xilinx DS181 Artix-7 FPGA Data Sheet, v1.27.1',
      'RoHS compliant',
      'Pb-free (lead-free) package',
      'JEDEC package standards',
      'Aligned with the ISO 26262 functional safety standard framework, with the official safety manual',
      'ESD protection to the JESD22 series',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Artix-7 35T with 33,280 logic cells (5,200 slices)',
      'Speed grade -2',
      '484-ball FBGA (FGG484) package',
      '250 user I/O and 90 DSP48E1 slices',
      '1,800 kbit of block RAM',
      'Integrated XADC and clock management units',
      'Industrial grade, -40 \u00b0C to 100 \u00b0C junction',
    ],
    applications: [
      'Industrial vision',
      'Video and image processing',
      'Communication equipment',
      'Medical instruments',
      'Data acquisition and protocol conversion',
    ],
    faq: [
      {
        q: 'What is the XC7A35T-2FGG484I used for?',
        a: 'It is used for industrial vision, video and image processing, communication equipment, medical instruments, and data acquisition and protocol conversion.',
      },
      {
        q: 'What do buyers check before ordering an XC7A35T-2FGG484I?',
        a: 'Buyers compare the performance and price of the -1, -2 and -3 speed grades, and confirm the footprint, because packages other than FGG484 are not drop-in replacements. They also account for the external SPI Flash configuration device and the complex power scheme with several core and I/O rails, confirm Vivado licensing, and weigh price against the long Artix-7 lead times.',
      },
      {
        q: 'How does YIXINOU check an XC7A35T-2FGG484I before it ships?',
        a: 'The FBGA-484 devices are inspected for ball integrity and marking, and the lot is documented before dispatch. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'XC7Z030-2FBG484I': {
    mpn: 'XC7Z030-2FBG484I',
    brand: 'AMD',
    title: 'Zynq-7000 XC7Z030 SoC, dual-core Arm Cortex-A9 with Kintex-7 class logic, FBGA-484',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Field Programmable Gate Arrays (FPGAs)',
    categoryHref: '/all-products',
    summary: 'The XC7Z030-2FBG484I is an AMD Zynq-7000 SoC that combines a dual-core Arm Cortex-A9 processing system running at up to 1 GHz with Kintex-7 class programmable logic. It is supplied in a 484-ball FCBGA package with 130 user I/O and a 1 V operating supply. Interfaces include CAN, EBI/EMI, Ethernet, I2C, MMC, SD, SDIO, SPI, UART, USART and USB, and the industrial temperature range is -40 \u00b0C to 100 \u00b0C. It is used in industrial and motion control, machine vision, communication equipment, medical equipment and embedded high-performance computing.',
    img: '/assets/images/xc7z030-2fbg484i-fcbga-484.jpg',
    alt: 'A 484-ball FCBGA package, the package used for the XC7Z030-2FBG484I',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'FCBGA-484 (FBG484)'],
      ['Number of pins', '484'],
      ['Processing system', 'Dual-core Arm Cortex-A9, up to 1 GHz'],
      ['Programmable logic', 'Kintex-7 class'],
      ['Interfaces', 'CAN, EBI/EMI, Ethernet, I2C, MMC, SD, SDIO, SPI, UART, USART, USB'],
      ['User I/O', '130'],
      ['Maximum frequency', '800 MHz'],
      ['Operating supply voltage', '1 V'],
      ['Operating temperature', '-40 \u00b0C to 100 \u00b0C'],
      ['RoHS compliance', 'Compliant'],
    ],
    about: 'The XC7Z030-2FBG484I is an AMD Zynq-7000 SoC in a 484-ball FCBGA package. It pairs a dual-core Arm Cortex-A9 running at up to 1 GHz with Kintex-7 class programmable logic, with 130 user I/O and CAN, Ethernet, USB, SD and SDIO, I2C, SPI and UART connectivity. The device runs from a 1 V operating supply over an industrial temperature range of -40 \u00b0C to 100 \u00b0C. Logic resources and I/O counts are listed in DS190 and the XC7Z030 tables. It is used in industrial and motion control, machine vision, communication, medical equipment and embedded high-performance computing.',
    standards: [
      'AMD/Xilinx DS190 Zynq-7000 SoC Overview, v1.11.1',
      'RoHS compliant',
      'Aligned with the ISO 26262 functional safety standard framework',
      'REACH compliant',
      'Pb-free (lead-free) package',
      'ESD protection to the JESD22 series',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Dual-core Arm Cortex-A9 processing system up to 1 GHz',
      'Kintex-7 class programmable logic',
      '484-ball FCBGA (FBG484) package',
      '130 user I/O',
      'Ethernet, USB, CAN, SD and SDIO, I2C, SPI and UART interfaces',
      '1 V operating supply',
      'Industrial grade, -40 \u00b0C to 100 \u00b0C',
    ],
    applications: [
      'Industrial control and motion control',
      'Machine vision',
      'Communication equipment',
      'Medical equipment',
      'Embedded high-performance computing',
    ],
    faq: [
      {
        q: 'What is the XC7Z030-2FBG484I used for?',
        a: 'It is used for industrial control and motion control, machine vision, communication equipment, medical equipment and embedded high-performance computing where a processor and programmable logic are needed together.',
      },
      {
        q: 'What do buyers check before ordering an XC7Z030-2FBG484I?',
        a: 'Buyers weigh the XC7Z030 against the XC7Z020 and XC7Z035 to match device size with cost, and check whether the I/O count of the 484-ball package is sufficient. They also review the power and DDR3 design, confirm Vivado licensing, and consider lead time, price and genuine-manufacturer sourcing.',
      },
      {
        q: 'How does YIXINOU check an XC7Z030-2FBG484I before it ships?',
        a: 'The FCBGA-484 packages are inspected on arrival for ball and marking condition, with the lot matched to its supplier trace. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'XC7Z045-2FFG676I': {
    mpn: 'XC7Z045-2FFG676I',
    brand: 'AMD',
    title: 'Zynq-7000 XC7Z045 SoC, dual-core Arm Cortex-A9 with Kintex-7 class logic, FFG676',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Field Programmable Gate Arrays (FPGAs)',
    categoryHref: '/all-products',
    summary: 'The XC7Z045-2FFG676I is an AMD Zynq-7000 SoC combining a dual-core Arm Cortex-A9 processing system at up to 1 GHz with Kintex-7 class programmable logic. It comes in a 676-ball FCBGA package with 130 user I/O and a 1 V operating supply, and its speed grade is -2. Interfaces cover CAN, EBI/EMI, Ethernet, I2C, MMC, SD, SDIO, SPI, UART, USART and USB, with an industrial temperature range of -40 \u00b0C to 100 \u00b0C. Typical uses are industrial and machine vision, communication baseband, software-defined radio, medical imaging and video processing acceleration.',
    img: '/assets/images/xc7z045-2ffg676i-fcbga-676.jpg',
    alt: 'A 676-ball FCBGA package, the package used for the XC7Z045-2FFG676I',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'FCBGA-676 (FFG676)'],
      ['Number of pins', '676'],
      ['Processing system', 'Dual-core Arm Cortex-A9, up to 1 GHz'],
      ['Programmable logic', 'Kintex-7 class'],
      ['Interfaces', 'CAN, EBI/EMI, Ethernet, I2C, MMC, SD, SDIO, SPI, UART, USART, USB'],
      ['User I/O', '130'],
      ['Maximum frequency', '800 MHz'],
      ['Operating supply voltage', '1 V'],
      ['Operating temperature', '-40 \u00b0C to 100 \u00b0C'],
      ['RoHS compliance', 'Compliant'],
    ],
    about: 'The XC7Z045-2FFG676I is an AMD Zynq-7000 SoC in a 676-ball FCBGA package, speed grade -2. It combines a dual-core Arm Cortex-A9 running at up to 1 GHz with Kintex-7 class programmable logic, with 130 user I/O and CAN, Ethernet, USB, SD and SDIO, I2C, SPI and UART. The device operates from a 1 V supply over an industrial temperature range of -40 \u00b0C to 100 \u00b0C, with logic resources and I/O numbers listed in DS190 and the XC7Z045 product tables. It serves industrial and machine vision, communication baseband, software-defined radio, medical imaging and video processing acceleration.',
    standards: [
      'AMD/Xilinx DS190 Zynq-7000 SoC Overview, v1.11.1',
      'RoHS compliant',
      'Aligned with the ISO 26262 functional safety standard framework, with the official safety manual and FMEDA material',
      'REACH compliant',
      'Pb-free (lead-free) package',
      'ESD protection to the JESD22 series',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Dual-core Arm Cortex-A9 processing system up to 1 GHz',
      'Kintex-7 class programmable logic',
      '676-ball FCBGA (FFG676) package',
      'Speed grade -2',
      '130 user I/O',
      'Ethernet, USB, CAN, SD and SDIO, I2C, SPI and UART interfaces',
      'Industrial grade, -40 \u00b0C to 100 \u00b0C',
    ],
    applications: [
      'Industrial and machine vision',
      'Communication baseband',
      'Software-defined radio (SDR)',
      'Medical imaging',
      'Video processing acceleration',
    ],
    faq: [
      {
        q: 'What is the XC7Z045-2FFG676I used for?',
        a: 'It is used for industrial and machine vision, communication baseband, software-defined radio, medical imaging and video processing acceleration.',
      },
      {
        q: 'What do buyers check before ordering an XC7Z045-2FFG676I?',
        a: 'Buyers compare the performance and price of the -2 speed grade with the -1 and -3 options and confirm the footprint, because the FFG900 version, including XC7Z045-L2FFG900I, is not a direct replacement. They also review power sequencing and DDR3 routing, confirm Vivado tool licensing, and take account of long lead times, high prices and the need to verify genuine-manufacturer parts, since refurbished high-end FPGAs are a known risk.',
      },
      {
        q: 'How does YIXINOU check an XC7Z045-2FFG676I before it ships?',
        a: 'FFG676 parts are checked for ball condition, package integrity and marking before they leave stock. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'XC7Z045-L2FFG900I4390': {
    mpn: 'XC7Z045-L2FFG900I4390',
    brand: 'AMD',
    title: 'Zynq-7000 XC7Z045 SoC, dual-core Arm Cortex-A9 with Kintex-7 class logic, FFG900',
    category: 'Integrated Circuits (ICS)',
    categoryHref: '/all-products',
    summary: 'The XC7Z045-L2FFG900I is an AMD Zynq-7000 SoC with a dual-core Arm Cortex-A9 processing system running at up to 1 GHz and Kintex-7 class programmable logic. It is supplied in a 900-ball FBGA package in speed grade -2, shown by the L2 marking, in industrial grade. Detailed logic resources and I/O numbers are published in DS190 and the XC7Z045 product tables. It is aimed at industrial and machine vision, communication baseband, radar and software-defined radio, medical imaging, and video processing and AI acceleration. Buyers should note that the ordering string XC7Z045-L2FFG900I4390 is a concatenation and the valid ordering format is XC7Z045-2FFG900I.',
    img: '/assets/images/xc7z045-l2ffg900i4390-package.jpg',
    alt: 'A 900-ball FBGA package, the package used for the XC7Z045-L2FFG900I',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'FBGA-900 (FFG900)'],
      ['Number of balls', '900'],
      ['Processing system', 'Dual-core Arm Cortex-A9, up to 1 GHz'],
      ['Programmable logic', 'Kintex-7 class'],
      ['Speed grade', '-2 (L2)'],
      ['RoHS compliance', 'Compliant'],
      ['REACH compliance', 'Compliant'],
      ['Lead-free package', 'Yes (Pb-free)'],
      ['ESD protection', 'JESD22 series'],
      ['Valid ordering part number', 'XC7Z045-2FFG900I'],
    ],
    about: 'The XC7Z045-L2FFG900I is an AMD Zynq-7000 SoC in a 900-ball FBGA package. Its processing system is a dual-core Arm Cortex-A9 at up to 1 GHz with Kintex-7 class programmable logic. The L2 marking indicates speed grade -2 and the part is industrial grade, with logic resources and I/O counts in DS190 and the XC7Z045 product tables. It targets industrial vision, machine vision, communication baseband, radar and software-defined radio, medical imaging, and video processing and AI acceleration. The concatenated form of this part number is not valid; order as XC7Z045-2FFG900I.',
    standards: [
      'AMD/Xilinx DS190 Zynq-7000 SoC Overview, v1.11.1',
      'RoHS compliant',
      'Aligned with the ISO 26262 functional safety standard framework',
      'REACH compliant',
      'Pb-free (lead-free) package',
      'ESD protection to the JESD22 series',
      'The concatenated part number as written is not valid; order as XC7Z045-2FFG900I',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Dual-core Arm Cortex-A9 processing system up to 1 GHz',
      'Kintex-7 class programmable logic',
      '900-ball FBGA (FFG900) package',
      'Speed grade -2, shown by the L2 marking',
      'Industrial grade device',
      'Aligned with the ISO 26262 functional safety standard framework',
      'REACH compliant, Pb-free package',
    ],
    applications: [
      'Industrial vision',
      'Machine vision',
      'Communication baseband',
      'Radar and software-defined radio',
      'Medical imaging',
      'Video processing and AI acceleration',
    ],
    faq: [
      {
        q: 'What is the XC7Z045-L2FFG900I used for?',
        a: 'It is used for industrial vision, machine vision, communication baseband, radar and software-defined radio, medical imaging, and video processing and AI acceleration.',
      },
      {
        q: 'What do buyers check before ordering an XC7Z045-L2FFG900I?',
        a: 'Buyers must confirm the part number with the supplier before ordering, because the original string is a concatenation of XC7Z045 with another code and the valid ordering form is XC7Z045-2FFG900I. They also assess whether a device of this scale is really needed given its high cost, review PS-PL bandwidth and AXI design, the DDR3 interface and power-up sequencing, and confirm Vivado licensing and version, lead time and price, which fluctuate for Zynq-7000.',
      },
      {
        q: 'How does YIXINOU check an XC7Z045-L2FFG900I before it ships?',
        a: 'FFG900 orders are matched against the manufacturer documentation and checked for ball condition, package integrity and marking. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'STM32F767ZIT6': {
    mpn: 'STM32F767ZIT6',
    brand: 'STMicroelectronics',
    title: 'Arm Cortex-M7 32-bit MCU with FPU, 216 MHz, 2 MB Flash, LQFP-144',
    category: 'Integrated Circuits (ICS) / Integrated Circuits (ICs) / Embedded Processors and Controllers / Microcontrollers',
    categoryHref: '/all-products',
    summary: 'The STM32F767ZIT6 is an STMicroelectronics 32-bit microcontroller built on the Arm Cortex-M7 core running at 216 MHz, equivalent to 462 DMIPS. It integrates 2 MB of Flash and 512 + 16 + 4 kB of SRAM, with peripherals that include USB OTG HS/FS, an Ethernet MAC, an FMC external memory controller, LCD-TFT, DFSDM and a JPEG codec, plus three 12-bit ADCs and two DACs. The ZIT6 option is a 144-pin LQFP package supplied in trays, operating from 1.7 V to 3.6 V over -40 \u00b0C to 85 \u00b0C. It is used in industrial HMI and graphical interfaces, industrial gateways, image processing, medical devices, audio processing and industrial automation.',
    img: '/assets/images/stm32f767zit6-lqfp-144.jpg',
    alt: 'A 144-pin LQFP package, the package used for the STM32F767ZIT6',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Package / case', 'LQFP-144 (Z)'],
      ['Number of pins', '144'],
      ['Core', 'Arm Cortex-M7 32-bit'],
      ['Maximum frequency', '216 MHz (462 DMIPS)'],
      ['Flash memory', '2 MB'],
      ['SRAM', '512 + 16 + 4 kB'],
      ['Supply voltage', '1.7 V to 3.6 V'],
      ['Interfaces', 'CAN, EBI/EMI, Ethernet, I2C, IrDA, LIN, SPI, UART, USART, USB'],
      ['Operating temperature', '-40 \u00b0C to 85 \u00b0C'],
      ['RoHS compliance', 'Compliant'],
    ],
    about: 'The STM32F767ZIT6 is an STMicroelectronics 32-bit microcontroller with an Arm Cortex-M7 core at 216 MHz, delivering 462 DMIPS. It provides 2 MB of Flash and 512 + 16 + 4 kB of SRAM plus USB OTG HS/FS, an Ethernet MAC, an FMC external memory controller, LCD-TFT, DFSDM and a JPEG codec, plus three 12-bit ADCs and two DACs. It is supplied in a 144-pin LQFP package in trays and runs from 1.7 V to 3.6 V over -40 \u00b0C to 85 \u00b0C. Applications include industrial HMI and graphical interfaces, industrial gateways, image processing, medical devices, audio processing and industrial automation.',
    standards: [
      'STMicroelectronics DS11532 Rev 9 (STM32F765xx / 767xx / 768Ax / 769xx)',
      'RoHS compliant',
      'ECOPACK2 environmentally friendly package, lead-free and compliant with RoHS and REACH',
      'ESD protection to JESD22-A114 (HBM) and JESD22-C101 (CDM)',
      'Package thermal characteristics per JESD51',
      'Electromagnetic compatibility per IEC 61000-4-x and IEC 61967',
      'IEC 60335-1 / IEC 60335-2 household appliance safety standards apply',
      'ISO 7816-3 smart card interface',
      'ESD-sensitive device \u2014 handle under ESD-protected conditions',
    ],
    features: [
      'Arm Cortex-M7 core at 216 MHz (462 DMIPS)',
      '2 MB of Flash and 512 + 16 + 4 kB of SRAM',
      '144-pin LQFP (Z) package, tray supplied',
      'USB OTG HS/FS and an Ethernet MAC',
      'FMC external memory controller and LCD-TFT controller',
      'Three 12-bit ADCs and two DACs, plus DFSDM',
      'JPEG codec, CAN, I2C, SPI, UART/USART and LIN interfaces',
      'Supply range 1.7 V to 3.6 V, -40 \u00b0C to 85 \u00b0C',
    ],
    applications: [
      'Industrial HMI and graphical interfaces',
      'Industrial gateways',
      'Image processing',
      'Medical devices',
      'Audio processing',
      'Industrial automation',
    ],
    faq: [
      {
        q: 'What is the STM32F767ZIT6 used for?',
        a: 'It is used for industrial HMI and graphical interfaces, industrial gateways, image processing, medical devices, audio processing and industrial automation.',
      },
      {
        q: 'What do buyers check before ordering a STM32F767ZIT6?',
        a: 'Buyers compare it with the STM32H743, which has a higher clock and more RAM, and they confirm the pin count, because the ZIT6 144-pin version differs from the VIT6 100-pin and IIT6 176-pin parts. They also plan FMC timing for external SDRAM, check the temperature grade, verify genuine-manufacturer parts, and review supply and price.',
      },
      {
        q: 'How does YIXINOU check a STM32F767ZIT6 before it ships?',
        a: 'Each LQFP-144 lot is checked for lead finish, coplanarity and marking against the order before shipping. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory.',
      },
    ],
  },
  'H9JKNNNFB3AECR-N6H': {
    mpn: 'H9JKNNNFB3AECR-N6H',
    brand: 'SK hynix',
    title: 'LPDDR3 SDRAM 12Gb x32, 1866 Mbps',
    category: 'Integrated Circuits (ICS) / Memory / DRAM (LPDDR3)',
    categoryHref: '/all-products',
    summary: 'The H9JKNNNFB3AECR-N6H is a 12 Gb LPDDR3 SDRAM from SK hynix in a 178-ball FBGA package, organised x32 and rated at 1866 Mbps. It runs from a 1.2 V core supply with 1.8 V input/output, and is specified from -30 \u00b0C to +85 \u00b0C. Check the part number carefully: some catalogue listings transpose two characters and show it as H9JKNNNFB3AE-CRN6H, while H9JKNNNFB3AECR-N6H is the correct order.',
    img: '/assets/images/h9jknnnfb3aecr-n6h-fbga-178.jpg',
    alt: 'A 178-ball FBGA package, the package used for the H9JKNNNFB3AECR-N6H LPDDR3 SDRAM',
    imageNote: 'Photograph of this part. Lot marking and date code vary by shipment \u2014 ask us for a photograph of the actual lot.',
    specs: [
      ['Memory size', '12 Gb (1.5 GB)'],
      ['Data bus width', 'x32'],
      ['Memory technology', 'LPDDR3 SDRAM'],
      ['Data rate', '1866 Mbps'],
      ['Supply voltage', '1.2 V core / 1.8 V I/O'],
      ['Package', '178-ball FBGA'],
      ['Mount', 'Surface mount'],
      ['Operating temperature', '-30 \u00b0C to +85 \u00b0C'],
      ['Series', 'H9J'],
      ['Standard', 'JEDEC JESD209-3'],
    ],
    about: 'LPDDR3 remains the memory of choice where a design needs low power and a low pin count rather than the newest generation: this 12 Gb x32 device is typical of flagship phones and tablets where the RAM is stacked with the processor, and of head-mounted and edge devices running on-device inference. The 178-ball FBGA footprint is designed for package-on-package assembly, so the memory and the applications processor are mounted as one component. Because the die is widely counterfeited, the reliable approach is to buy from a supplier who can evidence the lot and the packaging plant, and to confirm that the capacity and data rate appear on the SoC vendor DDR support list.',
    standards: ['JEDEC JESD209-3 (LPDDR3 SDRAM)', 'RoHS compliant'],
    features: [
      '12 Gb density organised x32',
      'LPDDR3 SDRAM at 1866 Mbps',
      '1.2 V core supply with 1.8 V input/output',
      '178-ball FBGA for package-on-package assembly',
      '-30 \u00b0C to +85 \u00b0C operating range',
      'Suited to low-power mobile and edge designs',
      'H9J series',
    ],
    applications: [
      'Flagship smartphones',
      'Tablets',
      'AR and VR headsets',
      'Edge devices running on-device AI inference',
      'High-compute portable equipment',
    ],
    faq: [
      {
        q: 'What is the H9JKNNNFB3AECR-N6H used for?',
        a: 'It provides the main working memory in low-power mobile and edge hardware: flagship phones, tablets, AR and VR headsets, and portable devices that run inference locally instead of in the cloud. Its 178-ball FBGA package is built for package-on-package assembly, so it is normally mounted directly on top of the applications processor.',
      },
      {
        q: 'What do buyers check before ordering an H9JKNNNFB3AECR-N6H?',
        a: 'The part number itself is the first check, because some catalogue listings show it with two characters transposed as H9JKNNNFB3AE-CRN6H and that form will not resolve at the manufacturer. Buyers then confirm that the 12 Gb capacity and 1866 Mbps rate appear on the SoC vendor DDR support list, that the package-on-package stacking process is compatible, and that the material is original die rather than white-label or downgraded stock, which is common in this family. Lot, packaging plant and reliability documentation are worth requesting before committing to volume.',
      },
      {
        q: 'How does YIXINOU check an H9JKNNNFB3AECR-N6H before it ships?',
        a: 'For the 178-ball FBGA we check ball coplanarity and body condition, verify the laser marking and date code against the supplier documents, and confirm the dry-pack condition that a BGA requires. Laboratory analysis \u2014 X-ray, XRF, decapsulation, solderability and electrical testing \u2014 is carried out by our partner laboratories; YIXINOU does not operate its own testing laboratory. Memory dies attract counterfeits, so ask us and we will state exactly what was verified on your lot.',
      },
    ],
  },
};

/*
 * Long-form copy per locale.
 *
 * The page bodies live here rather than in the UI dictionary because they are
 * structured (arrays of steps, cards and FAQs) and would be unreadable as flat keys.
 * ConfigProvider merges the entry for the active locale over the English defaults, so a
 * component is unaware of where its copy came from.
 *
 * Adding a language means adding an entry here plus its UI dictionary block in i18n.jsx.
 * A locale with no entry simply falls back to English.
 */
export const LOCALE_COPY = {
  de: {
    nav: [
      {
        label: 'Start',
        href: '/',
        active: true,
      },
      {
        label: 'Über uns',
        href: '/about-us',
      },
      {
        label: 'Produkte',
        href: '/all-products',
        children: [
          {
            label: 'Integrierte Schaltungen (ICs)',
            href: '/all-products?category=Integrated Circuits (ICS)',
          },
          {
            label: 'Transistoren',
            href: '/all-products?category=Transistors',
          },
          {
            label: 'Steckverbinder',
            href: '/all-products?category=Connector',
          },
          {
            label: 'Sonstige',
            href: '/all-products?category=Others',
          },
          {
            label: 'Module',
            href: '/all-products?category=Module',
          },
          {
            label: 'Kondensatoren',
            href: '/all-products?category=Capacitors',
          },
          {
            label: 'Widerstände',
            href: '/all-products?category=Resistor',
          },
          {
            label: 'Sensoren',
            href: '/all-products?category=Sensor',
          },
          {
            label: 'Schalter',
            href: '/all-products?category=Switch',
          },
          {
            label: 'LED',
            href: '/all-products?category=LED',
          },
        ],
      },
      {
        label: 'Branchen',
        href: '/industries',
        mega: true,
        children: [
          {
            slug: 'aerospace',
            icon: 'rocket',
            title: 'Luft- und Raumfahrt',
            href: '/industries/aerospace',
            desc: 'Komponenten für Avionik, Flugsteuerung und Bodengeräte, einschließlich abgekündigter und schwer beschaffbarer Typen.',
            items: [
              'Avionik-, Flugsteuerungs- und Instrumentenplatinen',
              'Abgekündigte Typen, Last-Time-Buy und obsoletes Material',
              'Steckverbinder, Relais, Oszillatoren und passive Bauelemente',
            ],
          },
          {
            slug: 'automotive',
            icon: 'car',
            title: 'Automobilindustrie',
            href: '/industries/automotive',
            desc: 'Komponenten für ADAS, Infotainment, Beleuchtung, Karosserieelektronik und die Antriebsstromsysteme von Elektrofahrzeugen.',
            items: [
              'Komponenten für ADAS, Sensorik und Kameras',
              'Teile für Infotainment, Displays und Audio',
              'Teile für Beleuchtung, Karosserieelektronik und Power-Management',
            ],
          },
          {
            slug: 'consumer-electronics',
            icon: 'monitor',
            title: 'Unterhaltungselektronik',
            href: '/industries/consumer-electronics',
            desc: 'Komponenten für Telefone, Wearables, Audio, Smart Home und Kleingeräte, bei denen Kosten und Lieferzeit den Auftrag entscheiden.',
            items: [
              'Display-, Touch- und Kamerakomponenten',
              'ICs für Power-Management und Ladetechnik',
              'Funk-, Audio- und passive Bauelemente',
            ],
          },
          {
            slug: 'contract-manufacturing',
            icon: 'factory',
            title: 'Auftragsfertigung',
            href: '/industries/contract-manufacturing',
            desc: 'Unterstützung bei Bandstillstand und Serienbedarf für EMS-Dienstleister und Auftragsfertiger, kalkuliert auf Basis Ihrer Stückliste.',
            items: [
              'Stücklisten-Kalkulation und Komplettaufträge',
              'Notfallbeschaffung bei Bandstillstand und Engpässen',
              'Prüfung von Zweitquellen und Bestandsausgleich',
            ],
          },
          {
            slug: 'energy',
            icon: 'zap',
            title: 'Energie',
            href: '/industries/energy',
            desc: 'Komponenten für Solar-, Speicher-, Netz- und Leistungsumsetzungstechnik.',
            items: [
              'Wechselrichter und Teile für die Leistungsumsetzung',
              'Gate-Treiber, IGBTs und Leistungsmodule',
              'Steuerungs-, Überwachungs- und Magnetkomponenten',
            ],
          },
          {
            slug: 'enterprise-computing',
            icon: 'server',
            title: 'Unternehmens-IT & Server',
            href: '/industries/enterprise-computing',
            desc: 'Komponenten für Server, Speichersysteme, Netzwerkgeräte und Rechenzentrums-Hardware.',
            items: [
              'Server-, Speicher- und Interface-Controller',
              'Netzteile und Spannungsregler',
              'Kühlung, Steckverbinder und Verkabelung',
            ],
          },
          {
            slug: 'gaming',
            icon: 'gamepad',
            title: 'Gaming',
            href: '/industries/gaming',
            desc: 'Komponenten für Gaming-Hardware, Unterhaltungs-, Lotterie- und Kassensysteme.',
            items: [
              'Display- und Controller-Teile',
              'Strom-, Interface- und Beleuchtungskomponenten',
              'Langlebige Ersatzteile für Bestandsgeräte',
            ],
          },
          {
            slug: 'healthcare',
            icon: 'heart-pulse',
            title: 'Medizintechnik',
            href: '/industries/healthcare',
            desc: 'Komponenten für Patientenmonitoring, diagnostische Bildgebung und Laborgeräte, bei denen Rückverfolgbarkeit entscheidend ist.',
            items: [
              'Platinen für Monitoring und Diagnostik',
              'Sensoren und Bauteile zur Signalaufbereitung',
              'Stromversorgung, Isolation und abgekündigte Typen',
            ],
          },
          {
            slug: 'industrial-automation',
            icon: 'cog',
            title: 'Industrieautomation',
            href: '/industries/industrial-automation',
            desc: 'Komponenten für Robotik, Antriebe, SPS, Sensorik und Leistungselektronik in der Produktion.',
            items: [
              'Teile für SPS, Antriebs- und Motion-Control-Technik',
              'Sensoren und Interface-ICs',
              'Leistungselektronik, Relais und Klemmen',
            ],
          },
          {
            slug: 'personal-computing',
            icon: 'keyboard',
            title: 'PC & Peripherie',
            href: '/industries/personal-computing',
            desc: 'Komponenten für Notebooks, Desktops, Peripheriegeräte und deren Zulieferkette.',
            items: [
              'ICs für Power-Management und Ladetechnik',
              'Interface-, USB- und Display-Controller',
              'Alte Typen für Reparatur und Service',
            ],
          },
          {
            slug: 'semiconductor-manufacturing',
            icon: 'cpu',
            title: 'Halbleiterfertigung',
            href: '/industries/semiconductor-manufacturing',
            desc: 'Unterstützungskomponenten und Ersatzteile für Fertigung, Test und Packaging.',
            items: [
              'Interface-Teile für Test und Handler',
              'Netzteile und Steuerungselektronik',
              'Sensorik, Bewegungskomponenten und Ersatzteile für Altgeräte',
            ],
          },
          {
            slug: 'telecom-networking',
            icon: 'network',
            title: 'Telekommunikation & Netzwerke',
            href: '/industries/telecom-networking',
            desc: 'Komponenten für Basisstationen, Router, Switches, optische Übertragung und Zugangsnetze.',
            items: [
              'HF-, optische und Interface-Komponenten',
              'Teile für Stromversorgung und Schaltungsschutz',
              'Filter, Steckverbinder und Line-Card-Komponenten',
            ],
          },
        ],
      },
      {
        label: 'Qualität',
        href: '/quality',
      },
      {
        label: 'Blog',
        href: '/blogs800',
        children: [
          {
            label: 'Brancheninfos',
            href: '/blogs800',
          },
          {
            label: 'Unternehmensnews',
            href: '/blogs800',
          },
        ],
      },
      {
        label: 'Kontakt',
        href: '/Contact',
      },
    ],
    categories: [
      {
        img: '/assets/images/cat-ics.jpg',
        label: 'Integrierte Schaltungen (ICs)',
        href: '/all-products?category=Integrated Circuits (ICS)',
      },
      {
        img: '/assets/images/cat-transistors.jpg',
        label: 'Transistoren',
        href: '/all-products?category=Transistors',
      },
      {
        img: '/assets/images/cat-connector.jpg',
        label: 'Steckverbinder',
        href: '/all-products?category=Connector',
      },
      {
        img: '/assets/images/cat-others.jpg',
        label: 'Sonstige',
        href: '/all-products?category=Others',
      },
    ],
    pageBanners: {
      '/about-us': {
        title: 'Seit acht Jahren Elektronikkomponenten aus Shenzhen',
        sub: 'Die Shenzhen Yixinou Electronic Co., Ltd. liefert ICs, Transistoren, Steckverbinder, Kondensatoren und Module an Kunden auf fünf Kontinenten – jede Bestellung wird vor dem Versand geprüft.',
        cta: {
          label: 'Sprechen Sie mit unserem Team',
          href: '/Contact',
        },
        micro: 'Wareneingangsprüfung bei jeder Bestellung · Laboranalysen über unsere Partnerlabore',
      },
      '/industries': {
        title: 'Ein Komponentenlieferant für zwölf Branchen',
        sub: 'Von der Luft- und Raumfahrt bis zur Automobilindustrie, von der Medizintechnik bis zur Telekommunikation – wir beschaffen die Bauteile, auf denen Ihre Branche basiert, prüfen sie bei Wareneingang und kalkulieren auf Basis Ihrer Stückliste.',
        cta: {
          label: 'Fragen zu Ihrer Branche',
          href: '/Contact',
        },
        micro: '12 Branchen · 10 Produktkategorien · Kunden auf fünf Kontinenten',
      },
      '/all-products': {
        title: 'ICs, Transistoren, Steckverbinder, Kondensatoren und mehr',
        sub: 'Senden Sie uns Ihre Stückliste – wir kalkulieren die gesamte Position, nicht ein Bauteil nach dem anderen. Die Wareneingangsprüfung ist bei jeder Bestellung inklusive.',
        cta: {
          label: 'Kostenloses Angebot anfordern',
          href: '/Contact',
        },
        micro: 'Stücklisten- und Komplettaufträge · Notfallbeschaffung bei Bandstillstand · Export auf fünf Kontinente',
      },
      '/': {
        title: 'Elektronische Komponenten aus Shenzhen',
        sub: 'Senden Sie uns Ihre Stückliste — wir kalkulieren die ganze Position, nicht nur ein Bauteil. Die Wareneingangsprüfung ist bei jeder Bestellung inklusive.',
        cta: {
          label: 'Angebot anfordern',
          href: '/Contact',
        },
        micro: 'Stücklisten und One-Stop-Bestellungen · Line-Down-Beschaffung · Export in fünf Kontinente',
      },
      '/quality': {
        title: 'Qualität und Prüfung',
        sub: 'Wareneingangsprüfung, Sichtprüfung sowie Verpackungs- und Kennzeichnungskontrolle in Shenzhen. Laboranalysen führen unsere Partnerlabore durch.',
        cta: {
          label: 'Prüfumfang besprechen',
          href: '/Contact',
        },
        micro: 'Prüfung bei jeder Bestellung',
      },
      '/blogs800': {
        title: 'Blog und Marktinformationen',
        sub: 'Beiträge zu Bauteilversorgung, Qualitätssicherung und Marktlage.',
        micro: 'Fachbeiträge für Einkauf und Qualität',
      },
      '/Contact': {
        title: 'Kontakt',
        sub: 'Senden Sie uns Ihre Stückliste oder Ihre Anfrage — wir melden uns mit Verfügbarkeit, Preis und Lieferzeit.',
        cta: {
          label: 'Stückliste senden',
          href: '/Contact',
        },
        micro: 'Antwort in der Regel am selben Werktag',
      },
      '/privacy': {
        title: 'Datenschutzerklärung',
        sub: 'Wie wir personenbezogene Daten auf dieser Website verarbeiten und welche Rechte Sie haben.',
      },
    },
    industriesPage: {
      eyebrow: 'Branchen',
      title: 'Branchen, die wir bedienen',
      lead: 'Wir liefern Elektronikkomponenten an Hersteller, Auftragsfertiger und Händler in zwölf Branchen. Jede Bestellung wird vor dem Versand geprüft, und jedes Bauteil, das eine interne Analyse erfordert, geht an unsere Partnerlabore.',
      menuDesc: 'Wir erbringen Leistungen und bauen Partnerschaften mit einer Vielzahl von Unternehmen aus den unterschiedlichsten Branchen auf.',
      ctaLabel: 'Alle Branchen ansehen',
      ctaHref: '/industries',
      items: [
        {
          slug: 'aerospace',
          icon: 'rocket',
          title: 'Luft- und Raumfahrt',
          href: '/industries/aerospace',
          desc: 'Komponenten für Avionik, Flugsteuerung und Bodengeräte, einschließlich abgekündigter und schwer beschaffbarer Typen.',
          items: [
            'Avionik-, Flugsteuerungs- und Instrumentenplatinen',
            'Abgekündigte Typen, Last-Time-Buy und obsoletes Material',
            'Steckverbinder, Relais, Oszillatoren und passive Bauelemente',
          ],
        },
        {
          slug: 'automotive',
          icon: 'car',
          title: 'Automobilindustrie',
          href: '/industries/automotive',
          desc: 'Komponenten für ADAS, Infotainment, Beleuchtung, Karosserieelektronik und die Antriebsstromsysteme von Elektrofahrzeugen.',
          items: [
            'Komponenten für ADAS, Sensorik und Kameras',
            'Teile für Infotainment, Displays und Audio',
            'Teile für Beleuchtung, Karosserieelektronik und Power-Management',
          ],
        },
        {
          slug: 'consumer-electronics',
          icon: 'monitor',
          title: 'Unterhaltungselektronik',
          href: '/industries/consumer-electronics',
          desc: 'Komponenten für Telefone, Wearables, Audio, Smart Home und Kleingeräte, bei denen Kosten und Lieferzeit den Auftrag entscheiden.',
          items: [
            'Display-, Touch- und Kamerakomponenten',
            'ICs für Power-Management und Ladetechnik',
            'Funk-, Audio- und passive Bauelemente',
          ],
        },
        {
          slug: 'contract-manufacturing',
          icon: 'factory',
          title: 'Auftragsfertigung',
          href: '/industries/contract-manufacturing',
          desc: 'Unterstützung bei Bandstillstand und Serienbedarf für EMS-Dienstleister und Auftragsfertiger, kalkuliert auf Basis Ihrer Stückliste.',
          items: [
            'Stücklisten-Kalkulation und Komplettaufträge',
            'Notfallbeschaffung bei Bandstillstand und Engpässen',
            'Prüfung von Zweitquellen und Bestandsausgleich',
          ],
        },
        {
          slug: 'energy',
          icon: 'zap',
          title: 'Energie',
          href: '/industries/energy',
          desc: 'Komponenten für Solar-, Speicher-, Netz- und Leistungsumsetzungstechnik.',
          items: [
            'Wechselrichter und Teile für die Leistungsumsetzung',
            'Gate-Treiber, IGBTs und Leistungsmodule',
            'Steuerungs-, Überwachungs- und Magnetkomponenten',
          ],
        },
        {
          slug: 'enterprise-computing',
          icon: 'server',
          title: 'Unternehmens-IT & Server',
          href: '/industries/enterprise-computing',
          desc: 'Komponenten für Server, Speichersysteme, Netzwerkgeräte und Rechenzentrums-Hardware.',
          items: [
            'Server-, Speicher- und Interface-Controller',
            'Netzteile und Spannungsregler',
            'Kühlung, Steckverbinder und Verkabelung',
          ],
        },
        {
          slug: 'gaming',
          icon: 'gamepad',
          title: 'Gaming',
          href: '/industries/gaming',
          desc: 'Komponenten für Gaming-Hardware, Unterhaltungs-, Lotterie- und Kassensysteme.',
          items: [
            'Display- und Controller-Teile',
            'Strom-, Interface- und Beleuchtungskomponenten',
            'Langlebige Ersatzteile für Bestandsgeräte',
          ],
        },
        {
          slug: 'healthcare',
          icon: 'heart-pulse',
          title: 'Medizintechnik',
          href: '/industries/healthcare',
          desc: 'Komponenten für Patientenmonitoring, diagnostische Bildgebung und Laborgeräte, bei denen Rückverfolgbarkeit entscheidend ist.',
          items: [
            'Platinen für Monitoring und Diagnostik',
            'Sensoren und Bauteile zur Signalaufbereitung',
            'Stromversorgung, Isolation und abgekündigte Typen',
          ],
        },
        {
          slug: 'industrial-automation',
          icon: 'cog',
          title: 'Industrieautomation',
          href: '/industries/industrial-automation',
          desc: 'Komponenten für Robotik, Antriebe, SPS, Sensorik und Leistungselektronik in der Produktion.',
          items: [
            'Teile für SPS, Antriebs- und Motion-Control-Technik',
            'Sensoren und Interface-ICs',
            'Leistungselektronik, Relais und Klemmen',
          ],
        },
        {
          slug: 'personal-computing',
          icon: 'keyboard',
          title: 'PC & Peripherie',
          href: '/industries/personal-computing',
          desc: 'Komponenten für Notebooks, Desktops, Peripheriegeräte und deren Zulieferkette.',
          items: [
            'ICs für Power-Management und Ladetechnik',
            'Interface-, USB- und Display-Controller',
            'Alte Typen für Reparatur und Service',
          ],
        },
        {
          slug: 'semiconductor-manufacturing',
          icon: 'cpu',
          title: 'Halbleiterfertigung',
          href: '/industries/semiconductor-manufacturing',
          desc: 'Unterstützungskomponenten und Ersatzteile für Fertigung, Test und Packaging.',
          items: [
            'Interface-Teile für Test und Handler',
            'Netzteile und Steuerungselektronik',
            'Sensorik, Bewegungskomponenten und Ersatzteile für Altgeräte',
          ],
        },
        {
          slug: 'telecom-networking',
          icon: 'network',
          title: 'Telekommunikation & Netzwerke',
          href: '/industries/telecom-networking',
          desc: 'Komponenten für Basisstationen, Router, Switches, optische Übertragung und Zugangsnetze.',
          items: [
            'HF-, optische und Interface-Komponenten',
            'Teile für Stromversorgung und Schaltungsschutz',
            'Filter, Steckverbinder und Line-Card-Komponenten',
          ],
        },
      ],
    },
    quality: {
      hero: {
        eyebrow: 'Qualität',
        title: 'Jede Bestellung wird vor dem Versand geprüft',
        lead: 'YIXINOU liefert ICs, Transistoren, Steckverbinder, Kondensatoren, Widerstände, Sensoren, Schalter, LEDs und Module an Einkäufer, die sich eine schlechte Charge nicht leisten können. Alle Bauteile werden bei Eingang in unserem Werk in Shenzhen geprüft, und alles, was eine interne Analyse erfordert, geht an unsere Partnerlabore.',
        points: [
          'Wareneingangsprüfung bei jeder Bestellung, die wir erhalten',
          'Externe Sichtprüfung unter dem digitalen Mikroskop',
          'Interne Analyse und elektrische Prüfung durch unsere Partnerlabore',
          'Ein Prüfprotokoll für die Chargen, die wir versenden',
        ],
        ctaLabel: 'Kontakt zu unserem Qualitätsteam',
        ctaHref: '/Contact',
        img: '/assets/images/quality-hero-inspection.jpg',
        alt: 'Ein YIXINOU-Prüfer bedient an seinem Arbeitsplatz ein digitales Inspektionsmikroskop; das vergrößerte Bauteil ist auf dem Bildschirm neben ihm zu sehen',
      },
      checks: {
        eyebrow: 'Was wir prüfen',
        title: 'Vier Prüfschritte bei jeder Bestellung',
        items: [
          {
            icon: 'sampling',
            title: 'Abgestimmte Stichprobe',
            text: 'Wir stimmen den Stichprobenplan vorab mit Ihnen ab und passen ihn an das Bauteil, die Menge und Ihre Annahmekriterien an.',
          },
          {
            icon: 'visual',
            title: 'Sichtprüfung',
            text: 'Externe Kontrolle unter dem digitalen Mikroskop auf beschädigte, ummarkierte oder falsche Bauteile, ergänzt durch Anschlussprüfung, Kratztest, Acetontest und Prüfung der Markierungsbeständigkeit.',
          },
          {
            icon: 'records',
            title: 'Prüfprotokolle',
            text: 'Für jede Lieferung bewahren wir Prüfergebnis, Fotos sowie Chargen- und Datumscodes auf, sodass nachvollziehbar bleibt, was geprüft wurde.',
          },
          {
            icon: 'reporting',
            title: 'Bericht in Ihrem Format',
            text: 'Teilen Sie uns mit, welche Inhalte Ihr Bericht enthalten muss; wir legen die Ergebnisse Ihrer Lieferung bei.',
          },
        ],
      },
      process: {
        eyebrow: 'Unser Prozess',
        title: 'Unser Qualitätsprozess',
        statement: 'Praxistaugliche Prüftechnik für jede Bestellung, die wir bearbeiten — und ein Partnerlabor, sobald ein Bauteil eine tiefergehende Analyse benötigt.',
        note: 'Die Schritte 1 bis 3 erfolgen in unserem eigenen Werk in Shenzhen. Die Schritte 4 und 5 werden von unseren Partnerlaboren durchgeführt — YIXINOU betreibt selbst kein Prüflabor und sagt das offen, damit Sie genau wissen, wer Ihre Bauteile prüft.',
        steps: [
          {
            title: 'Fotodokumentation und Prüfung',
            text: [
              'Wir zählen Ihre Bauteile, ordnen sie nach Teilenummer und Seriennummer und fotografieren sie im Zustand bei Eingang.',
              'Wir erfassen Menge und Ursprungsland und vergeben für jede Charge einen eigenen Chargen- und Datumscode.',
            ],
            img: '/assets/images/quality-step-1-photography.jpg',
            alt: 'Rollen, Trays und Antistatikbeutel mit elektronischen Bauteilen, in beschrifteten Reihen auf der Sortierfläche im YIXINOU-Werk ausgelegt',
            inhouse: true,
          },
          {
            title: 'Barcode-Scan und Abgleich',
            text: [
              'Eine zweite Kontrolle bestätigt exakte Mengen und Spezifikationen im Abgleich mit Ihrer Bestellung.',
              'Etiketten werden in unsere Aufzeichnungen eingescannt, sodass jedes Bauteil bis zur Herkunftscharge rückverfolgbar bleibt.',
            ],
            img: '/assets/images/quality-step-2-barcode.jpg',
            alt: 'Illustration: Ein Handscanner liest das Etikett eines verschlossenen Antistatikbeutels über einer Werkbank',
            inhouse: true,
            illustrative: true,
          },
          {
            title: 'Sichtprüfung',
            text: [
              'Unsere Prüfer untersuchen die Bauteile äußerlich unter einem digitalen Inspektionsmikroskop.',
              'Wir prüfen auf beschädigte, ummarkierte oder falsche Bauteile und führen Anschlussprüfung, Kratztest, Acetontest sowie Prüfung der Markierungsbeständigkeit durch.',
            ],
            img: '/assets/images/quality-step-3-visual.jpg',
            alt: 'Ein YIXINOU-Prüfer positioniert ein Bauteil unter einem digitalen Inspektionsmikroskop; die vergrößerte Bauteiloberfläche ist auf dem Monitor im Hintergrund zu sehen',
            inhouse: true,
          },
          {
            title: 'Laboranalyse und Prüfung',
            text: [
              'Bauteile, die eine interne Analyse erfordern, gehen an unsere Partnerlabore; dort führen deren Ingenieure weiterführende Untersuchungen mit Röntgenprüfung, Röntgenfluoreszenzanalyse (XRF) und hochauflösender Mikroskopie durch.',
              'Ihre Labore nehmen außerdem thermische und chemische Dekapsulation vor, um die Echtheit eines Bauteils zu bestätigen, ergänzt durch Lötbarkeitsprüfungen, die belegen, dass Anschlüsse oder Kontaktflächen zuverlässig lötbar sind.',
            ],
            img: '/assets/images/quality-step-4-laboratory.jpg',
            alt: 'Illustration: Röntgenprüfkammer, XRF-Analysator und Inspektionsmikroskop auf einer Werkbank im Partnerlabor, daneben ein Tray mit Bauteilproben',
            inhouse: false,
            illustrative: true,
          },
          {
            title: 'Elektrische Prüfung',
            text: [
              'Die elektrische Leistung wird in unseren Partnerlaboren gegen die Spezifikation des Datenblatts gemessen.',
              'Deren Ingenieure nutzen Kurvenschreiber (Curve Tracer), Funktionstests oder die Messung von Induktivität, Kapazität und Widerstand (LCR), um aktive und passive Bauteile zu charakterisieren.',
            ],
            img: '/assets/images/quality-step-5-electrical.jpg',
            alt: 'Illustration: Kurvenschreiber und LCR-Prüfplatz mit einem in einer Testfassung gehaltenen Bauteil und Messkurven auf dem Bildschirm',
            inhouse: false,
            illustrative: true,
          },
        ],
      },
      midCta: {
        title: 'Sagen Sie uns, welche Kriterien Ihre Bauteile erfüllen müssen',
        text: 'Senden Sie uns Ihre Annahmekriterien — Stichprobenumfang, erforderliche Tests und Berichtsformat — und wir bestätigen Ihnen genau, wie wir Ihre Bestellung prüfen, bevor sie bei Ihnen eintrifft.',
        ctaLabel: 'Anforderungen senden',
        ctaHref: '/Contact',
      },
      standard: {
        eyebrow: 'Warum YIXINOU',
        title: 'Exzellenz ist unser Standard',
        blocks: [
          {
            eyebrow: 'Qualifizierung',
            title: 'Lieferanten, hinter denen wir stehen',
            text: 'Wir kaufen bei Lieferanten, die wir qualifiziert haben, und behalten diejenigen, die überzeugen. Lieferanten mit gemeldeten Qualitätsproblemen werden eingeschränkt oder von unserer Liste gestrichen. Lässt sich die Historie eines Bauteils nicht verifizieren, sagen wir Ihnen das, anstatt es als gesichert zu versenden.',
            img: '/assets/images/quality-standard-vendors.jpg',
            alt: 'Hochregal mit palettierten elektronischen Bauteilen im YIXINOU-Lager',
          },
          {
            eyebrow: 'Rückverfolgbarkeit',
            title: 'Ein Protokoll für jede Charge',
            text: 'Jede Lieferung wird mit Prüfergebnis, Fotos sowie Chargen- und Datumscodes erfasst. Wenn Sie wissen möchten, was bei einer bestimmten Charge geprüft wurde, rufen wir das Protokoll heraus und senden es Ihnen zu.',
            img: '/assets/images/quality-standard-records.jpg',
            alt: 'YIXINOU-Mitarbeiter an ihren Arbeitsplätzen bei der Pflege von Prüf- und Versandunterlagen',
          },
        ],
      },
      stats: {
        eyebrow: 'In Zahlen',
        title: 'Ihr Vorteil mit YIXINOU',
        items: [
          {
            value: '8+',
            label: 'Jahre in der Bauteilbranche',
          },
          {
            value: '10',
            label: 'Gelieferte Produktkategorien',
          },
          {
            value: '20+',
            label: 'Partner weltweit',
          },
          {
            value: '5',
            label: 'Kontinente, in die wir liefern',
          },
        ],
      },
      services: {
        eyebrow: 'Qualitätsservices',
        title: 'Maßstäbe für Qualität',
        items: [
          {
            icon: 'process',
            title: 'Wareneingangsprüfung',
            text: 'Sehen Sie die fünf Prüfschritte für Ihre Bauteile und wo jeder davon erfolgt.',
            href: '/quality#quality-process',
          },
          {
            icon: 'report',
            title: 'Prüfberichte',
            text: 'Fordern Sie Ergebnisse, Fotos und Chargenprotokolle für Ihre Lieferung an, im Format, das Ihr Team benötigt.',
            href: '/Contact',
          },
          {
            icon: 'shield',
            title: 'Lieferantenqualifizierung',
            text: 'Wie wir unsere Lieferanten prüfen und wie wir vorgehen, wenn einer davon die Erwartungen nicht erfüllt.',
            href: '/quality#quality-standard',
          },
          {
            icon: 'testing',
            title: 'Bauteiltests',
            text: 'Organisieren Sie Röntgenprüfung, XRF, Dekapsulation, Lötbarkeits- oder elektrische Prüfungen über unsere Partnerlabore.',
            href: '/Contact',
          },
          {
            icon: 'team',
            title: 'Qualitätsteam',
            text: 'Lernen Sie die Prüfer kennen, die Ihre Bauteile kontrollieren und Tests in Ihrem Auftrag koordinieren.',
            href: '/about-us',
          },
          {
            icon: 'award',
            title: 'Zertifizierungen',
            text: 'Sehen Sie die Zertifizierungen und branchenübergreifenden Mitgliedschaften, die unsere Qualitätsservices belegen.',
            href: '/about-us',
          },
        ],
      },
      faq: {
        eyebrow: 'Häufige Fragen',
        title: 'Fragen, die uns Einkäufer zur Qualität stellen',
        items: [
          {
            q: 'Prüfen Sie Bauteile im eigenen Haus?',
            a: 'Teilweise. Wareneingangsprüfung, Fotodokumentation, Barcode-Abgleich und die externe Sichtprüfung unter dem digitalen Mikroskop führen wir in unserem Werk in Shenzhen durch. Die interne Analyse — Röntgenprüfung, XRF, Dekapsulation, Lötbarkeits- und elektrische Prüfung — erfolgt durch unsere Partnerlabore.',
          },
          {
            q: 'Wer führt Ihre Laborprüfungen durch?',
            a: 'Unsere Partnerlabore. YIXINOU betreibt selbst kein Prüflabor und sagt das offen, damit Sie genau wissen, wer Ihre Bauteile prüft.',
          },
          {
            q: 'Erhalte ich mit meiner Bestellung einen Prüfbericht?',
            a: 'Ja. Teilen Sie uns mit, welche Inhalte Ihr Bericht enthalten muss; wir legen Ergebnisse, Fotos und Chargenprotokolle Ihrer Lieferung bei.',
          },
          {
            q: 'Was passiert, wenn Sie ein Problem feststellen?',
            a: 'Wir stoppen die Charge und melden uns mit dem Ergebnis und den dazugehörigen Nachweisen bei Ihnen, statt sie zu versenden und darauf zu hoffen, dass sie Ihre Eingangsprüfung besteht.',
          },
          {
            q: 'Wie viel meiner Bestellung prüfen Sie?',
            a: 'Wir stimmen den Stichprobenplan vorab mit Ihnen ab. Größere Mengen, gemischte Chargen und nicht verifizierte Quellen werden intensiver geprüft.',
          },
        ],
      },
      closing: {
        title: 'Qualitätskontrolle',
        text: 'Jedes Bauteil geprüft. Sehen Sie, was verfügbar ist.',
        primary: {
          label: 'Kontakt',
          href: '/Contact',
        },
        secondary: {
          label: 'Alle Produkte entdecken',
          href: '/all-products',
        },
      },
    },
    about: {
      text: [
        'Die Shenzhen Yixinou Electronic Co., Ltd. ist ein Anbieter elektronischer Bauelemente mit Sitz im Stadtbezirk Futian in Shenzhen, China. Wir kaufen, prüfen und versenden die Bauteile, die unsere Kunden für eine laufende Produktion benötigen — von der einzelnen Rolle bis zur kompletten Stückliste.',
        'Die meisten Kunden wenden sich an uns, wenn in einer Fertigungslinie ein Bauteil fehlt, eine Stückliste schnell kalkuliert werden muss oder eine Charge vor dem Produktionseinsatz geprüft werden soll. Genau dafür sind wir aufgestellt: Wir klären, was tatsächlich verfügbar ist, prüfen die eingehende Ware und sagen Ihnen offen, wenn sich ein Bauteil nicht verifizieren lässt.',
        'Wir liefern ICs, Transistoren, Steckverbinder, Kondensatoren, Widerstände, Sensoren, Schalter, LEDs und Module. Unsere Bauelemente werden in der Unterhaltungselektronik, im IoT, in der New-Energy-Branche, in der Kommunikationstechnik, in der Industrie und in der Automobiltechnik eingesetzt. Wir versenden an Kunden in Asien, Europa, Afrika und Amerika.',
      ],
      factory: [
        {
          img: '/assets/images/team-group.jpg',
          alt: 'Das Team von YIXINOU gemeinsam im Büro in Shenzhen',
        },
        {
          img: '/assets/images/gallery-01.jpg',
          alt: 'Bauteilrollen und Trays, ausgelegt zum Sortieren',
        },
        {
          img: '/assets/images/gallery-02.jpg',
          alt: 'Warenausgangsbereich vor dem Versand',
        },
        {
          img: '/assets/images/gallery-03.jpg',
          alt: 'Lagergang am Standort Shenzhen',
        },
        {
          img: '/assets/images/gallery-04.jpg',
          alt: 'Mitarbeiter an der SMD-Fertigungslinie',
        },
        {
          img: '/assets/images/gallery-05.jpg',
          alt: 'Präzisionsbestückung an der SMD-Fertigungslinie',
        },
        {
          img: '/assets/images/gallery-06.jpg',
          alt: 'Regale für die Bauteillagerung im Lager',
        },
        {
          img: '/assets/images/gallery-07.jpg',
          alt: 'Verpackte Aufträge, etikettiert und versandbereit',
        },
      ],
    },
    aboutPage: {
      hero: {
        eyebrow: 'Unsere Geschichte',
        title: 'Seit acht Jahren beschaffen wir die Bauteile, auf die Ihre Produktion setzt',
        statement: 'Die Shenzhen Yixinou Electronic Co., Ltd. ist ein unabhängiger Distributor für elektronische Bauelemente. Von Shenzhen aus liefern wir ICs, Transistoren, Steckverbinder, Kondensatoren, Widerstände, Sensoren, Schalter, LEDs und Module an Kunden auf fünf Kontinenten.',
        ctaLabel: 'Sprechen Sie mit uns',
        ctaHref: '/Contact',
        img: '/assets/images/about-hero.jpg',
        alt: 'Das Team von YIXINOU an den Arbeitsplätzen im Vertriebsbüro in Shenzhen',
      },
      cards: [
        {
          icon: 'sourcing',
          title: 'Bauteilbeschaffung',
          text: 'Wir beschaffen ICs, Transistoren, Steckverbinder, Kondensatoren, Widerstände, Sensoren, Schalter, LEDs und Module nach Ihrer Stückliste.',
        },
        {
          icon: 'bom',
          title: 'Stücklisten und Komplettaufträge',
          text: 'Senden Sie uns eine Stückliste, und wir kalkulieren die gesamte Position statt einzelner Bauteile.',
        },
        {
          icon: 'inspection',
          title: 'Wareneingangsprüfung',
          text: 'Jede Bestellung wird bei Eingang an unserem Standort in Shenzhen geprüft, bevor sie für Sie verpackt wird.',
        },
        {
          icon: 'export',
          title: 'Export und Logistik',
          text: 'Dokumentation, Verpackung und Versand an Kunden auf fünf Kontinenten.',
        },
      ],
      facts: {
        eyebrow: 'Auf einen Blick',
        title: 'YIXINOU auf einen Blick',
        items: [
          {
            value: '8+',
            label: 'Jahre im Bauelementegeschäft',
          },
          {
            value: '10',
            label: 'Gelieferte Produktkategorien',
          },
          {
            value: '5',
            label: 'Kontinente, in die wir liefern',
          },
          {
            value: 'Shenzhen',
            label: 'Sitz und Lager',
          },
        ],
      },
      values: {
        eyebrow: 'Unsere Werte',
        title: 'Das treibt uns an.',
        items: [
          {
            title: 'Genauigkeit zuerst',
            text: 'Wir sagen Ihnen lieber, dass sich ein Bauteil nicht verifizieren lässt, als es zu versenden und Sie erst bei Ihrer Wareneingangsprüfung damit zu konfrontieren.',
          },
          {
            title: 'Rückverfolgbarkeit',
            text: 'Chargen, Date Codes und Prüfprotokolle werden dokumentiert, sodass wir Ihnen auf die Frage, was geprüft wurde, konkret antworten können.',
          },
          {
            title: 'Klare Antworten',
            text: 'Dazu gehört auch, wer Ihre Bauteile testet: Die Laboranalysen führen unsere Partnerlabore durch, und das sagen wir offen.',
          },
          {
            title: 'Reaktionsschnelligkeit',
            text: 'Angebote und Bestandsprüfungen erhalten Sie so schnell, wie wir sie bearbeiten können.',
          },
          {
            title: 'Beziehungen vor Aufträgen',
            text: 'Uns ist ein Kunde über Jahre lieber als ein einzelner Auftrag.',
          },
          {
            title: 'Ständige Verbesserung',
            text: 'Jede Reklamation wird erfasst und ausgewertet und verändert unsere Beschaffungs- und Prüfprozesse.',
          },
        ],
      },
      team: {
        eyebrow: 'Unser Team',
        title: 'Ihre Ansprechpartner',
        lead: 'Ein Team betreut Ihre Anfrage, Ihr Angebot und Ihre Prüfprotokolle, sodass Sie nicht von Schreibtisch zu Schreibtisch weitergereicht werden.',
      },
      video: {
        eyebrow: 'Ein genauerer Blick',
        title: 'Ein Blick in unseren Betrieb in Shenzhen',
        text: 'Gedreht an unserem Standort — die Arbeitsplätze, der Prüfplatz und die Bauteile, mit denen wir täglich arbeiten.',
      },
      related: {
        eyebrow: 'Über uns',
        title: 'Mehr über uns.',
        items: [
          {
            title: 'Qualitätsprozess',
            text: 'Die fünf Prüfungen, die wir an Ihren Bauteilen durchführen, und wo jede davon stattfindet.',
            href: '/quality',
          },
          {
            title: 'Alle Produkte',
            text: 'ICs, Transistoren, Steckverbinder, Kondensatoren, Widerstände, Sensoren, Schalter, LEDs und Module.',
            href: '/all-products',
          },
          {
            title: 'Blog',
            text: 'Brancheninformationen und Unternehmensnachrichten aus dem Bauelementemarkt.',
            href: '/blogs800',
          },
          {
            title: 'Kontakt',
            text: 'Senden Sie uns Ihre Stückliste oder Ihre Anfrage, und wir melden uns bei Ihnen.',
            href: '/Contact',
          },
        ],
      },
    },
  },
  // Locales added after German ship as modules so this file stops growing with each language.
  // Both are checked against the English structure before wiring in.
  fr: frCopy,
  es: esCopy,
  ar: arCopy,
  ru: ruCopy,
  ja: jaCopy,
  ko: koCopy,
  zh: zhCopy,
  bg: bgPack.copy,
  hr: hrPack.copy,
  cs: csPack.copy,
  da: daPack.copy,
  nl: nlPack.copy,
};
